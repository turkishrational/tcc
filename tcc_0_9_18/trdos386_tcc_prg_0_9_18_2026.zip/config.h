/* Automatically modified for Windows 32-bit Console Compilation */
#define TCC_VERSION "0.9.18"
#define GCC_MAJOR 3
#define HOST_I386 1

/* Windows PE Hedef ve S�r�c� Z�rhlar� */
#define TCC_TARGET_I386 1
#define TCC_TARGET_PE 1
#define CONFIG_WIN32 1
#define _WIN32 1

/* Varsay�lan Arama Yollar� (Windows Klas�r D�zeni) */
#define CONFIG_TCC_PREFIX "C:/TDM-GCC-32/tinycc"
#define CONFIG_TCC_LIBDIR "C:/TDM-GCC-32/tinycc/lib"
#define CONFIG_TCC_INCDIR "C:/TDM-GCC-32/tinycc/include"
