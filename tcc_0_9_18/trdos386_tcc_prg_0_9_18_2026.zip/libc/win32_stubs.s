.intel_syntax noprefix
.global _system
.global system
.global ___p__environ
.global _GetProcAddress@8
.global _LoadLibraryA@4
.global _FreeLibrary@4
.global _VirtualProtect@16
.global _SetUnhandledExceptionFilter@4
.global _SearchPathA@24

/* TCC El S�k��ma / TRDOS LIBC Standart K�pr� Giri�leri */
.global _fopen
.global fopen
.global _fclose
.global fclose

/* Initial Versiyon Eksik Sembol Giri�leri */
.global _ungetc
.global ungetc
.global _puts
.global puts

.text

_system:
system:
    mov eax, -1       /* TRDOS alt�nda s�re� tetikleme kapal� */
    ret

___p__environ:
    xor eax, eax
    ret

/* =========================================================================
   1. SAF ASSEMBLER _fopen �N�ASI (+3 LIBC FD ZIRHI)
   ========================================================================= */
_fopen:
fopen:
    push ebp
    mov ebp, esp
    push ebx
    push ecx

    mov eax, [ebp + 12] /* Mode dizesinin adresi ("r", "w") */
    mov ebx, [ebp + 8]  /* Filename dizesinin adresi */

    cmp byte ptr [eax], 114 /* 'r' karakteri mi? (ASCII 114) */
    je .L_open_read
    cmp byte ptr [eax], 119 /* 'w' karakteri mi? (ASCII 119) */
    je .L_open_write

.L_bad_mode:
    xor eax, eax        /* Hata veya ge�ersiz mod: Return NULL (0) */
    jmp .L_fopen_done

.L_open_read:
    /* Saf TRDOS sys_open (EAX=5) �a�r�s� */
    /* EBX = filename, ECX = 0 (open for read) */
    xor ecx, ecx
    mov eax, 5
    int 0x40
    jc .L_bad_mode

    add eax, 3          /* Kernel FD (0-9) -> LIBC FD (3-12) z�rh� */
    jmp .L_fopen_done

.L_open_write:
    /* Saf TRDOS sys_creat (EAX=8) �a�r�s� */
    /* EBX = filename, ECX = 0 (ordinary file) */
    xor ecx, ecx
    mov eax, 8
    int 0x40
    jc .L_bad_mode

    add eax, 3          /* Kernel FD (0-9) -> LIBC FD (3-12) z�rh� */

.L_fopen_done:
    pop ecx
    pop ebx
    pop ebp
    ret

/* =========================================================================
   2. SAF ASSEMBLER _fclose �N�ASI (-3 LIBC FD RECOVERY)
   ========================================================================= */
_fclose:
fclose:
    push ebp
    mov ebp, esp
    push ebx

    mov ebx, [ebp + 8]  /* TCC'den gelen LIBC FD de�erini al (3-12 aras�) */
    
    /* E�er gelen FD 3'ten k���kse (0, 1, 2 yani stdio), kapat�lamaz! */
    cmp ebx, 3
    jl .L_close_success /* G�venle atla, i�lem yapma */

    sub ebx, 3          /* LIBC FD -> Tekrar kernel uyumlu 0-based index (0-9) */

    /* Saf TRDOS sys_close (EAX=6) �a�r�s� */
    mov eax, 6
    int 0x40
    jc .L_close_err

.L_close_success:
    xor eax, eax        /* Ba�ar�l�: Return 0 */
    jmp .L_fclose_done

.L_close_err:
    mov eax, -1         /* Hata: Return -1 */

.L_fclose_done:
    pop ebx
    pop ebp
    ret

/* =========================================================================
   3. ungetc MANTIK K�PR�S� (Bypass/Sim�lasyon Z�rh�)
   ========================================================================= */
/* arg1: int c [ebp+8], arg2: FILE *stream [ebp+12] */
// _ungetc:
// ungetc:
//    push ebp
//    mov ebp, esp
//    mov eax, [ebp + 8]   /* Geri itilmek istenen karakteri EAX'e al */
//    /* Not: Initial TCC, ungetc sonras�nda karakteri hemen okuyacak bir */
//    /* i� tampon i�aret�isine sahiptir. Buradan karakteri g�venle geri d�n�yoruz. */
//    pop ebp
//    ret

/* =========================================================================
   4. puts MANTIK K�PR�S� (Yerle�ik _write ve _strlen Ba�lant�s�)
   ========================================================================= */
_puts:
puts:
    push ebp
    mov ebp, esp
    push ebx

    mov ebx, [ebp + 8]   /* ebx = ekrana bas�lacak dizge adresi */
    test ebx, ebx
    jz .L_puts_done

    /* �nce karakter uzunlu�unu yerle�ik _strlen ile bulal�m */
    push ebx
    .extern _strlen
    call _strlen
    add esp, 4           /* eax = karakter say�s� */
    test eax, eax
    jz .L_puts_lf

    /* Yerle�ik _write(fd, buf, count) fonksiyonunu �a��r�yoruz */
    push eax             /* Arg 3: count */
    push ebx             /* Arg 2: buffer pointer */
    push 1               /* Arg 1: stdout FD = 1 */
    .extern _write
    call _write
    add esp, 12

.L_puts_lf:
    /* C standard� gere�i puts sonuna yeni sat�r (\n) ekler */
    mov eax, offset local_lf_char
    push 1
    push eax
    push 1
    call _write
    add esp, 12

.L_puts_done:
    xor eax, eax
    pop ebx
    pop ebp
    ret

_GetProcAddress@8:
_LoadLibraryA@4:
_FreeLibrary@4:
_VirtualProtect@16:
_SetUnhandledExceptionFilter@4:
_SearchPathA@24:
    xor eax, eax
    ret

/* 28/6/2026 - Google AI */
/* =========================================================================
   ?? TCC 0.9.18 S�R�M� N�HA� ENJEKS�YON H�CRELER�
   ========================================================================= */
.global ___mingw_dlfcn
.global __mingw_dlfcn
.global __ftime
.global _ftime

.text

/* MinGW Dinamik Y�kleyici Taklidi (TRDOS statik ba� ko�turdu�u i�in bo�a d���r�yoruz) */
___mingw_dlfcn:
__mingw_dlfcn:
    xor eax, eax       /* Ba�ar�s�z veya n�tr d�n�� de�eri (0) */
    ret

/* ftime Zamanlay�c� Taklidi */
/* arg1: struct timeb *tp [ebp+8] */
__ftime:
_ftime:
    push ebp
    mov ebp, esp
    mov eax, [ebp + 8]  /* Y���ndan gelen timeb struct adresini al */
    test eax, eax
    jz .L_ftime_done
    
    /* TRDOS 386 zaman kesmesi eklenene kadar yap�y� g�venli s�f�rlarla dolduruyoruz */
    mov dword ptr [eax], 0       /* time_t time = 0 */
    mov word ptr [eax + 4], 0    /* unsigned short millitm = 0 */
    mov word ptr [eax + 6], 0    /* short timezone = 0 */
    mov word ptr [eax + 8], 0    /* short dstflag = 0 */

.L_ftime_done:
    xor eax, eax
    pop ebp
    ret


local_lf_char: .byte 10  /* LF */
