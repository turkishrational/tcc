.intel_syntax noprefix
.global ___main
.global _stricmp
.global _strlwr

.text

/* 10/08/2026 */
.balign 4          /* Fonksiyonun 4-byte sınırında başlamasını garantiler */

___main:
    ret

.balign 4

_stricmp:
    xor eax, eax
    ret

.balign 4

_strlwr:
    mov eax, [esp + 4]
    ret

