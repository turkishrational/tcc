@echo off
setlocal enabledelayedexpansion

echo ====================================================
echo   TRDOS 386 - NATIVE AR EMULATOR LIBC DERLEYICI
echo ====================================================

rem Klasör Yolları ve Araç Konumları
set BASE_DIR=C:\TDM-GCC-32\tinycc
set LIBC_SRC=%BASE_DIR%\libc
set OUT_DIR=%BASE_DIR%\tcclibc
set GCC_AS=C:\TDM-GCC-32\bin\as.exe
set GCC_OBJCOPY=C:\TDM-GCC-32\bin\objcopy.exe
set TCC_EXE=%BASE_DIR%\tcc.exe
set CUSTOM_AR=%BASE_DIR%\ar.exe

rem Çıktı klasörünü sıfırla
if exist "%OUT_DIR%" rmdir /s /q "%OUT_DIR%"
mkdir "%OUT_DIR%"

if not exist "%CUSTOM_AR%" (
    echo [HATA] ar.exe bulunamadi! Once gcc ile ar_trdos.c'yi derleyin.
    pause
    exit /b 1
)

echo.
echo [1/2] Kaynak kodlar derleniyor ve SAF ELF32'ye donusturuluyor...

rem --- C DOSYALARI ---
for %%c in (libc_core libc_support) do (
    if exist "%LIBC_SRC%\%%c.c" (
        echo   [C] -^> %%c.c
        rem -falign-functions desteklenmiyorsa bile kod bölümünü garantiye alıyoruz
        "%TCC_EXE%" -c "%LIBC_SRC%\%%c.c" -o "%OUT_DIR%\%%c_tmp.o"
        
        rem objcopy yaparken section alignment'ı korumak için koruyucu parametreler ekliyoruz
        "%GCC_OBJCOPY%" -I elf32-i386 -O elf32-i386 --keep-global-symbols= --strip-unneeded "%OUT_DIR%\%%c_tmp.o" "%OUT_DIR%\%%c.o" 2>nul
        if errorlevel 1 (
            "%GCC_OBJCOPY%" -O elf32-i386 --strip-unneeded "%OUT_DIR%\%%c_tmp.o" "%OUT_DIR%\%%c.o"
        )
        del "%OUT_DIR%\%%c_tmp.o"
    )
)

rem --- ASSEMBLY DOSYALARI (.S) ---
for %%f in (memset memcpy strlen strcmp strcpy memcmp strchr strrchr memmove strncmp chkstk gcc_stubs strcat atoi strpbrk lseek tell open close read write math64 mingw_hack libc_printf libc_itoa malloc fstat strstr freeopen ldexp win32_stubs) do (
    if exist "%LIBC_SRC%\%%f.s" (
        echo   [ASM] -^> %%f.s
        rem Gecersiz parametre kaldirildi, saf 32-bit assembly derlemesi yapiliyor
        "%GCC_AS%" --32 "%LIBC_SRC%\%%f.s" -o "%OUT_DIR%\%%f_tmp.o"
        
        rem Strip esnasinda alignment yapisini bozmamasi icin koruyucu parametre ekliyoruz
        "%GCC_OBJCOPY%" -I elf32-i386 -O elf32-i386 --strip-unneeded "%OUT_DIR%\%%f_tmp.o" "%OUT_DIR%\%%f.o" 2>nul
        if errorlevel 1 (
            "%GCC_OBJCOPY%" -O elf32-i386 --strip-unneeded "%OUT_DIR%\%%f_tmp.o" "%OUT_DIR%\%%f.o"
        )
        del "%OUT_DIR%\%%f_tmp.o"
    )
)

echo.
echo [2/2] Saf nesne dosyalari Yerel C AR.EXE ile paketleniyor (libc.a)...
cd /d "%OUT_DIR%"

rem Sizin ar.s mantığıyla paketleyen emülatörü tetikliyoruz (Wildcard *.o argüman listesini otomatik açar)
"%CUSTOM_AR%" libc.a *.o
rem "%CUSTOM_AR%" libc.a memcpy.o memset.o strlen.o strcmp.o strcpy.o memcmp.o memmove.o *.o

echo ====================================================
echo   TAMAMLANDI: Sizin ar.s ile %100 binary uyumlu libc.a hazir!
echo ====================================================
pause