; =======================================================================
; TRDOS 386 - NATIVE LIBC (NASM ELF32 FORMAT)
; File: chkstk.asm (Converted from chkstk.s)
; Date: 11/08/2026 - Developer: Erdogan Tan & Google AI
; =======================================================================

global ___chkstk_ms
global __chkstk

section .text
align 4

__chkstk:
___chkstk_ms:
    push ecx
    push eax
    cmp eax, 4096
    lea ecx, [esp + 12]
    jb .L_chkstk_less

.L_chkstk_loop:
    sub ecx, 4096
    test [ecx], eax
    sub eax, 4096
    cmp eax, 4096
    jae .L_chkstk_loop

.L_chkstk_less:
    sub ecx, eax
    test [ecx], eax
    pop eax
    pop ecx
    ret
