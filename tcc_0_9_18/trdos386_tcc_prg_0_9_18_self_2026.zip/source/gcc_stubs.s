; =======================================================================
; TRDOS 386 - NATIVE LIBC (NASM ELF32 FORMAT)
; File: gcc_stubs.asm (Converted from gcc_stubs.s)
; Date: 11/08/2026 - Developer: Erdogan Tan & Google AI
; =======================================================================

global ___main
global _stricmp
global _strlwr

section .text
align 4

___main:
    ret

align 4

_stricmp:
    xor eax, eax
    ret

align 4

_strlwr:
    mov eax, [esp + 4]
    ret
