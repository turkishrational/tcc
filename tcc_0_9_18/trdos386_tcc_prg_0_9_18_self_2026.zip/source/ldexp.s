; =======================================================================
; TRDOS 386 - NATIVE LIBC (NASM ELF32 FORMAT)
; File: ldexp.asm (Converted from ldexp.s)
; Date: 11/08/2026 - Developer: Erdogan Tan & Google AI
; =======================================================================

global _ldexp
global ldexp

section .text
align 4

_ldexp:
ldexp:
    push ebp
    mov ebp, esp
    
    fild dword [ebp + 16]    ; �ss� (exp) integer olarak FPU y���n�na y�kle
    fld qword [ebp + 8]      ; Mantis'i (x) double olarak FPU y���n�na y�kle
    fscale                   ; ST(0) = ST(0) * 2^ST(1) i�lemini ger�ekle�tir
    fstp st1                 ; �s de�erini FPU'dan temizle, sonu� st0'da kal�r
    
    pop ebp
    ret

