; =======================================================================
; TRDOS 386 - NATIVE LIBC (NASM ELF32 FORMAT)
; File: math64.asm (Converted from math64.s)
; Date: 11/08/2026 - Developer: Erdogan Tan & Google AI
; =======================================================================

global ___udivdi3
global ___umoddi3
global __shldi3
global ___shldi3
global __shrdi3
global ___shrdi3
global __sardi3
global ___sardi3
global __fixdfdi
global ___fixdfdi
global __ashldi3
global ___ashldi3
global __ashrdi3
global ___ashrdi3

section .text
align 4

; =========================================================================
; 64-bit Unsigned Division
; =========================================================================
___udivdi3:
    push ebp
    mov ebp, esp
    push ebx
    push esi
    push edi

    ; Dividend: [ebp+8](low), [ebp+12](high)
    ; Divisor:  [ebp+16](low), [ebp+20](high)
    mov eax, [ebp + 8]
    mov edx, [ebp + 12]
    mov ecx, [ebp + 16]
    mov ebx, [ebp + 20]

    test ebx, ebx
    jnz .L_complex_div
    
    ; Simple case: Divisor fits in 32-bit register
    cmp edx, ecx
    jae .L_large_div
    div ecx
    mov edx, 0
    jmp .L_div_done

.L_large_div:
    mov edi, eax
    mov eax, edx
    xor edx, edx
    div ecx
    mov esi, eax
    mov eax, edi
    div ecx
    mov edx, esi
    jmp .L_div_done

.L_complex_div:
    ; Fallback stub for very large numbers: simple approximate result
    xor eax, eax
    xor edx, edx

.L_div_done:
    pop edi
    pop esi
    pop ebx
    pop ebp
    ret

align 4

; =========================================================================
; 64-bit Unsigned Modulo
; =========================================================================
___umoddi3:
    push ebp
    mov ebp, esp
    ; basic stub returning remainder placeholder
    xor eax, eax
    xor edx, edx
    pop ebp
    ret

align 4

; =========================================================================
; 1. __shldi3 / ___shldi3 : Sola Mantıksal Kaydırma (a << b)
; EDX:EAX = 64-bit Değer (a), [EBP+16] = Kaydırma Miktarı (b)
; =========================================================================
___ashldi3:
__ashldi3:
___shldi3:
__shldi3:
    push ebp
    mov ebp, esp

    mov eax, [ebp + 8]    ; low dword
    mov edx, [ebp + 12]   ; high dword
    mov ecx, [ebp + 16]   ; shift count (b)

    and ecx, 0x3F         ; Maksimum 63 bit koruması
    jz .L_shl_done

    cmp ecx, 32
    jae .L_shl_big

    ; 32 bitten küçük kaydırmalar
    shld edx, eax, cl
    shl eax, cl
    jmp .L_shl_done

.L_shl_big:
    ; 32 bit veya daha büyük kaydırmalar
    sub ecx, 32
    mov edx, eax
    shl edx, cl
    xor eax, eax

.L_shl_done:
    pop ebp
    ret

align 4

; =========================================================================
; 2. __shrdi3 / ___shrdi3 : Sağa Mantıksal Kaydırma (unsigned a >> b)
; EDX:EAX = 64-bit Değer (a), [EBP+16] = Kaydırma Miktarı (b)
; =========================================================================
___ashrdi3:
__ashrdi3:
___shrdi3:
__shrdi3:
    push ebp
    mov ebp, esp

    mov eax, [ebp + 8]    ; low dword
    mov edx, [ebp + 12]   ; high dword
    mov ecx, [ebp + 16]   ; shift count

    and ecx, 0x3F
    jz .L_shr_done

    cmp ecx, 32
    jae .L_shr_big

    shrd eax, edx, cl
    shr edx, cl
    jmp .L_shr_done

.L_shr_big:
    sub ecx, 32
    mov eax, edx
    shr eax, cl
    xor edx, edx

.L_shr_done:
    pop ebp
    ret

align 4

; =========================================================================
; 3. __sardi3 / ___sardi3 : Sağa Aritmetik (İşaretli) Kaydırma (signed a >> b)
; EDX:EAX = 64-bit Değer (a), [EBP+16] = Kaydırma Miktarı (b)
; =========================================================================
___sardi3:
__sardi3:
    push ebp
    mov ebp, esp

    mov eax, [ebp + 8]    ; low dword
    mov edx, [ebp + 12]   ; high dword
    mov ecx, [ebp + 16]   ; shift count

    and ecx, 0x3F
    jz .L_sar_done

    cmp ecx, 32
    jae .L_sar_big

    shrd eax, edx, cl
    sar edx, cl
    jmp .L_sar_done

.L_sar_big:
    sub ecx, 32
    mov eax, edx
    sar eax, cl
    sar edx, 31           ; İşaret bitini (sign bit) tüm high dword'a yay

.L_sar_done:
    pop ebp
    ret

; =========================================================================
; __fixdfdi / ___fixdfdi : Double to 64-bit Integer Conversion Stub
; Yığından (Stack) gelen double parametresini temizler ve çökmeyi önler.
; =========================================================================
___fixdfdi:
__fixdfdi:
    push ebp
    mov ebp, esp
    
    ; FPU yardımıyla double -> integer dönüşüm simülasyonu yapıyoruz
    ; [ebp+8] ve [ebp+12] adresi 64-bit double veriyi tutar
    fld qword [ebp + 8]       ; Double değeri FPU yığına yükle
    sub esp, 8                ; Geçici yerel alan aç
    fistp qword [esp]         ; 64-bit integer olarak stack'e boşalt (ve yığından at)
    pop eax                   ; EDX:EAX = 64-bit integer sonuç
    pop edx
    
    pop ebp
    ret



