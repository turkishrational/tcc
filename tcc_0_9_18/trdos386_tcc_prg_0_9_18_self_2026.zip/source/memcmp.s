; =======================================================================
; TRDOS 386 - NATIVE LIBC (NASM ELF32 FORMAT)
; File: memcmp.asm (Converted from memcmp.s)
; Date: 11/08/2026 - Developer: Erdogan Tan & Google AI
; =======================================================================

global _memcmp
global memcmp

section .text
align 4

memcmp:
_memcmp:
    push ebp
    mov ebp, esp
    push esi
    push edi

    mov esi, [ebp + 8]
    mov edi, [ebp + 12]
    mov ecx, [ebp + 16]

    xor eax, eax
    cld
    repe cmpsb
    je .L_memcmp_done

    mov al, [esi - 1]
    mov dl, [edi - 1]
    movzx eax, al
    movzx edx, dl
    sub eax, edx

.L_memcmp_done:
    pop edi
    pop esi
    pop ebp
    ret
