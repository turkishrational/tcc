; =======================================================================
; TRDOS 386 - NATIVE LIBC (NASM ELF32 FORMAT)
; File: memmove.asm (Converted from memmove.s)
; Date: 11/08/2026 - Developer: Erdogan Tan & Google AI
; =======================================================================

global _memmove
global memmove

section .text
align 4

memmove:
_memmove:
    push ebp
    mov ebp, esp
    push edi
    push esi

    mov edi, [ebp + 8]
    mov esi, [ebp + 12]
    mov ecx, [ebp + 16]

    cmp edi, esi
    jbe .L_move_forward
    
    lea edi, [edi + ecx - 1]
    lea esi, [esi + ecx - 1]
    std
    rep movsb
    cld
    jmp .L_move_done

.L_move_forward:
    cld
    rep movsb

.L_move_done:
    mov eax, [ebp + 8]
    pop esi
    pop edi
    pop ebp
    ret
