; =======================================================================
; TRDOS 386 - NATIVE LIBC (NASM ELF32 FORMAT)
; File: strcpy.asm (Converted from strcpy.s)
; Date: 11/08/2026 - Developer: Erdogan Tan & Google AI
; =======================================================================

global _strcpy
global strcpy

section .text
align 4

strcpy:
_strcpy:
    push ebp
    mov ebp, esp
    push edi
    push esi

    mov edi, [ebp + 8]
    mov esi, [ebp + 12]

.L_strcpy_loop:
    mov al, [esi]
    mov [edi], al
    cmp al, 0
    je .L_strcpy_done
    inc esi
    inc edi
    jmp .L_strcpy_loop

.L_strcpy_done:
    mov eax, [ebp + 8]
    pop esi
    pop edi
    pop ebp
    ret
