; =======================================================================
; TRDOS 386 - NATIVE LIBC (NASM ELF32 FORMAT)
; File: strlen.asm (Converted from strlen.s)
; Date: 11/08/2026 - Developer: Erdogan Tan & Google AI
; =======================================================================

global _strlen
global strlen

section .text
align 4

strlen:
_strlen:
    push ebp
    mov ebp, esp
    push edi

    mov edi, [ebp + 8]
    xor eax, eax          ; sub eax, eax yerine daha efektif olan xor kullanıldı

.L_strlen_loop:
    cmp byte [edi], 0
    je .L_strlen_done
    inc edi
    inc eax
    jmp .L_strlen_loop

.L_strlen_done:
    pop edi
    pop ebp
    ret
