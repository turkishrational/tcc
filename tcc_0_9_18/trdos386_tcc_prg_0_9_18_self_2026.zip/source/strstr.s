; =======================================================================
; TRDOS 386 - NATIVE LIBC (NASM ELF32 FORMAT)
; File: strstr.asm (Converted from strstr.s)
; Date: 11/08/2026 - Developer: Erdogan Tan & Google AI
; =======================================================================

global _strstr
global strstr

section .text
align 4

_strstr:
strstr:
    push ebp
    mov ebp, esp
    push edi
    push esi
    push ebx

    mov edi, [ebp + 8]    ; edi = haystack (ana metin)
    mov esi, [ebp + 12]   ; esi = needle (aranan kelime)

    ; Aranan kelime bo� mu? (\0)
    mov al, [esi]
    cmp al, 0
    jnz .L_main_loop
    mov eax, edi          ; Bo� dize ise do�rudan haystack adresini d�n
    jmp .L_done

.L_main_loop:
    mov al, [edi]
    cmp al, 0
    jz .L_null            ; Ana metin bittiyse ve bulunamad�ysa NULL (0) d�n

    ; �� kar��la�t�rma d�ng�s� ba�lang�c�
    mov ebx, edi          ; ebx = ge�ici haystack taray�c�
    mov edx, esi          ; edx = ge�ici needle taray�c�

.L_compare:
    mov cl, [edx]
    cmp cl, 0
    jz .L_match           ; Aranan kelimenin sonuna (\0) ula�t�ysak BA�ARILI!
    
    mov ch, [ebx]
    cmp cl, ch
    jne .L_next           ; Karakterler e�le�miyorsa ana d�ng�de bir sa�a kayd�r
    
    inc ebx
    inc edx
    jmp .L_compare

.L_next:
    inc edi               ; Haystack i�aret�isini bir karakter ilerlet
    jmp .L_main_loop

.L_match:
    mov eax, edi          ; E�le�menin ba�lad��� ana adresi eax'e y�kle
    jmp .L_done

.L_null:
    xor eax, eax          ; Bulunamad�, NULL (0) d�nd�r

.L_done:
    pop ebx
    pop esi
    pop edi
    pop ebp
    ret

