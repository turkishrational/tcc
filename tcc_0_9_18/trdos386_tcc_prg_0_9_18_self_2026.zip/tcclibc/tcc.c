/*
 *  TCC - Tiny C Compiler
 * 
 *  Copyright (c) 2001-2004 Fabrice Bellard
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

/* 13/08/2026 */
/* 12/08/2026 */
/* 11/08/2026 */
/* 10/08/2026 */
/* 09/08/2026 - TCC.PRG 0.9.24 self-compiling */
/* 07/08/2026 */
/* 06/08/2026 */
/* 05/08/2026 */
/* 04/08/2026 */
/* 03/08/2026 */
/* 02/08/2026 */
/* 01/08/2026 - TCC.PRG 0.9.24 */
/* 31/07/2026 */
/* 30/07/2026 */
/* 29/07/2026 */
/* 28/07/2026 - TCC.PRG 0.9.23 */
/* 24/07/2026 - TCC.PRG 0.9.18 */
/* 23/07/2026 */
/* 22/07/2026 */

/* 09/07/2026 */
/* 08/07/2026 - Google AI */ 

#define _GNU_SOURCE
#include "config.h"

/* 09/08/2026 - TCC.PRG 0.9.24 self-compiling */ 
// #include <stdlib.h>
// #include <stdio.h>
// #include <stdarg.h>
// #include <string.h>
// #include <errno.h>
// #include <math.h>
// #include <unistd.h>
// #include <fcntl.h>
// #include <setjmp.h>
// #include <time.h>
// #include <sys/time.h>

/* 09/08/2026 - Google AI */
#include "tcctrdos.h"

#include "elf.h"
// #include "stab.h"

/* =========================================================================
   GOOGLE AI & ERDOGAN TAN - FLAT PRINTF RE-ROUTE & MACRO OVERRIDE SHIELD
   =========================================================================
   Override and neutralize all hidden printf/vprintf macros leaking from 
   TDM-GCC/MinGW header files. Forcefully re-route them directly to our 
   stable, thread-safe global 'trdos_print' assembly bridge in libc. */
#undef printf
#undef vprintf

/* Prototype the native TRDOS runtime print engine */
extern int trdos_print(const char *format, ...);
#define printf trdos_print

/* Re-route fputs and fprintf directly to the native TRDOS print engine 
   to bypass legacy stdout/stderr buffering artifacts completely. */
#undef fprintf
#define fprintf(stream, fmt, ...) printf(fmt, ##__VA_ARGS__)
#undef fputs
#define fputs(str, stream) printf("%s", str)
/* ========================================================================= */

#include "libtcc.h"

/* =========================================================================
   GOOGLE AI & ERDOGAN TAN - TCC 0.9.18 PURE 32-BIT POINTER PROTOTYPE SHIELD
   =========================================================================
   Enforce explicit 32-bit pointer return types to prevent TDM-GCC-32 from 
   truncating addresses into 16-bit integers, effectively guarding against 
   the notorious 0Dh General Protection Fault (GPF) at runtime address 255CCh. */
extern void *malloc(unsigned int size);
extern void *realloc(void *ptr, unsigned int size);
extern void *memcpy(void *dest, const void *src, unsigned int n);
extern int strcmp(const char *s1, const char *s2);
extern unsigned int strlen(const char *s);

struct TCCState; /* Forward declaration of core compiler context */
int tcc_add_file(struct TCCState *s, const char *filename);
int tcc_add_library(struct TCCState *s, const char *libraryname);
/* ========================================================================= */

/* Enforcement of the default Native 32-bit x86 architecture target */
#ifndef TCC_TARGET_I386
#define TCC_TARGET_I386
#endif

/* Include raw architecture-specific assembler support */
#define CONFIG_TCC_ASM

/* Explicit library search path for crt0.o and core TRDOS objects */
#define CONFIG_TCC_CRT_PREFIX "lib"  /* 23/07/2026 */

#define INCLUDE_STACK_SIZE  32
#define IFDEF_STACK_SIZE    64
// #define VSTACK_SIZE      64
/* 03/08/2026 - TCC 0.9.24 */
#define VSTACK_SIZE         256
#define STRING_MAX_SIZE     1024

// #define TOK_HASH_SIZE    2048 /* Must be a power of two */
/* 03/08/2026 - TCC 0.9.24 */
#define TOK_HASH_SIZE       8192
#define TOK_ALLOC_INCR      512  /* Must be a power of two */
/* 07/08/2026 */
// #define TOK_ALLOC_INCR   256
// #define TOK_STR_ALLOC_INCR_BITS 6
// #define TOK_STR_ALLOC_INCR (1 << TOK_STR_ALLOC_INCR_BITS)
#define TOK_MAX_SIZE        4    /* Token max size in int units when stored in string */

/* Core token symbol management architecture */
typedef struct TokenSym {
    struct TokenSym *hash_next;
    struct Sym *sym_define;      /* Direct pointer to define descriptors */
    struct Sym *sym_label;       /* Direct pointer to label descriptors */
    struct Sym *sym_struct;      /* Direct pointer to structure definitions */
    struct Sym *sym_identifier;  /* Direct pointer to identifier symbol */
    int tok;                     /* Associated unique token number */
    int len;
    char str[1];
} TokenSym;

typedef struct CString {
    int size;                    /* Active string size in bytes */
    void *data;                  /* Castable pointer to either 'char *' or 'int *' */
    int size_allocated;
    void *data_allocated;        /* Tracks dynamic lifetime if malloced */
} CString;

/* Absolute native type definitions */
typedef struct CType {
    int t;
    struct Sym *ref;
} CType;

/* Execution engine constant value mapping */
typedef union CValue {
    long double ld;
    double d;
    float f;
    int i;
    unsigned int ui;
    unsigned int ul;             /* Absolute 32-bit flat memory address */
    long long ll;
    unsigned long long ull;
    struct CString *cstr;
    void *ptr;
    int tab[1];
} CValue;

/* Value configuration mapping on evaluation stack */
typedef struct SValue {
    CType type;                  /* Data token type */
    unsigned short r;            /* Base register tracking + internal operational flags */
    unsigned short r2;           /* Auxiliary register mapping for 64-bit 'long long' operations */
    CValue c;                    /* Literal constant values */
    struct Sym *sym;             /* Associated compiler symbol references */
} SValue;

/* Flat lexical symbol management structure */
typedef struct Sym {
    int v;                       /* Symbol signature token identifier */
    int r;                       /* Assigned physical hardware processor register */
    int c;                       /* Contextual storage assignment or boundary offset */
    CType type;                  /* Associated explicit compiler type */
    struct Sym *next;            /* Forward link in sequential relational tracking */
    struct Sym *prev;            /* Backward context link on compilation stack */
    struct Sym *prev_tok;        /* Chain link resolving conflicts for identical tokens */
} Sym;

/* Section abstraction markers */
#define SHF_PRIVATE 0x80000000   /* Guard flag preventing section leakage during binary emission */

/* Absolute definition of an executable/object binary section */
typedef struct Section {
    unsigned long data_offset;    /* Current active data offset in memory */
    unsigned char *data;          /* Raw section data buffer pointer */
    unsigned long data_allocated; /* Tracked memory buffer limit for realloc() */
    int sh_name;                  /* ELF section name identifier string offset */
    int sh_num;                   /* ELF section sequential index number */
    int sh_type;                  /* ELF section semantic type */
    int sh_flags;                 /* ELF section operational permission flags */
    int sh_info;                  /* ELF section extra info attribute */
    int sh_addralign;             /* ELF section memory boundary alignment constraint */
    int sh_entsize;               /* ELF entry size specification */
    unsigned long sh_size;        /* Total finalized section size during file emission */
    unsigned long sh_addr;        /* Runtime memory address mapping for target relocation */
    unsigned long sh_offset;      /* Virtual storage file offset mapping */
    int nb_hashed_syms;           /* Tracked metrics to optimize hash table scaling */
    struct Section *link;         /* Link descriptor targeting another section */
    struct Section *reloc;        /* Relocation tracking metadata table cross-link */
    struct Section *hash;         /* Associated direct lookup symbol hash table */
    struct Section *next;         /* Pointer to the next section descriptor in layout */
    /* 01/08/2026 */
    char name[16];
    /* 31/07/2026 - TCC 0.9.18 (0.9.23 Modified) */ 
    // char name[64];             /* Literal human-readable section name identifier */
    /* 28/07/2026 - TCC 0.9.20-0.9.27 */
    // char name[1];              /* section name */
} Section;

/* GNU C Compiler attribute translation mapping */
typedef struct AttributeDef {
    int aligned;                  /* Requested hardware memory alignment boundary */
    int packed;   /* 28/07/2026 - TCC 0.9.23 */
    Section *section;             /* Target custom memory storage destination section */
    unsigned char func_call;      /* Assigned function calling convention (Defaults to FUNC_CDECL) */
} AttributeDef;

#define SYM_STRUCT     0x40000000 /* Symbol namespace mask for struct/union/enum definitions */
#define SYM_FIELD      0x20000000 /* Symbol namespace mask for composite structure fields */
// #define SYM_FIRST_ANOM (1 << (31 - VT_STRUCT_SHIFT))
/* 30/07/2026 - TCC 0.9.24 - tcc.c */
#define SYM_FIRST_ANOM 0x10000000 /* Base token allocator offset for anonymous symbols */

/* Stored inside the 'Sym.c' metadata field */
#define FUNC_NEW       1          /* Modern ANSI-compliant function prototype descriptor */
#define FUNC_OLD       2          /* Legacy K&R style function prototype descriptor */
#define FUNC_ELLIPSIS  3          /* Variadic ANSI function prototype including ellipsis (...) */

/* Stored inside the 'Sym.r' execution field */
#define FUNC_CDECL     0          /* Standard C calling convention (Default stack cleanup by caller) */
#define FUNC_STDCALL   1          /* Win32 WinAPI compatibility Pascal calling convention (Unused) */

/* 28/07/2026 - TCC 0.9.23 */
#define FUNC_FASTCALL1 2 /* first param in %eax */
#define FUNC_FASTCALL2 3 /* first parameters in %eax, %edx */
#define FUNC_FASTCALL3 4 /* first parameter in %eax, %edx, %ecx */
/* 03/08/2026 */
/* 30/07/2026 - TCC 0.9.24 - tcc.c */
#define FUNC_FASTCALLW 5 /* first parameter in %ecx, %edx */

/* Configuration assigned to the 'Sym.t' macro expansion processor */
#define MACRO_OBJ      0          /* Standard object-like macro constant expansion block */
#define MACRO_FUNC     1          /* Functional parametrizable macro expansion block */

/* Parameter track mappings for 'Sym.r' label resolution */
#define LABEL_DEFINED  0          /* Target code block label has been successfully resolved */
#define LABEL_FORWARD  1          /* Forward-declared destination label awaiting binding resolution */
#define LABEL_DECLARED 2          /* Declared compilation tracking label that remains unreferenced */

/* Grammatical parsing declaration modes */
#define TYPE_ABSTRACT  1          /* Isolated type descriptor structure evaluated without a live variable */
#define TYPE_DIRECT    2          /* Standard variable definition including explicit typing */

#define IO_BUF_SIZE 8192          /* Optimized low-level input-output disk block layout size */

/* Low-level system track state representation for an open source target file */
typedef struct BufferedFile {
    uint8_t *buf_ptr;             /* Active operational memory pointer within stream window */
    uint8_t *buf_end;             /* Dynamic boundary end pointer marking current frame data block */
    int fd;                       /* Native TRDOS file descriptor tracking integer */
    int line_num;                 /* Current active sequential execution line counter metrics */
    int ifndef_macro;             /* Target tracking symbol identifier for single-inclusion guards */
    int ifndef_macro_saved;       /* Temporary state tracking register for preprocessor guards */
    int *ifdef_stack_ptr;         /* State evaluation tracking pointer recording active ifdef depth */
    char inc_type;                /* Context token tracking inclusion type ('<' or '"') */
    // char inc_filename[512];    /* Raw verbatim source path string typed by developer */
    // char filename[1024];       /* Final resolved canonical storage workspace file path */
    /* 29/07/2026 */
    char inc_filename[256];
    char filename[256]; 
    unsigned char buffer[IO_BUF_SIZE + 1]; /* Extended hardware frame layout containing CH_EOB padding */
} BufferedFile;

#define CH_EOB   '\\'             /* End-of-Buffer escape token representation flag */
#define CH_EOF   (-1)             /* End-of-File hard execution binary signal */

/* Save state snapshot data engine designed to record and re-evaluate source streams */
typedef struct ParseState {
    int *macro_ptr;               /* Active text layout macro processing frame position pointer */
    int line_num;                 /* Tracked line number context */
    int tok;                      /* Evaluated unique token id snapshot target */
    CValue tokc;                  /* Extracted lexical context metadata token value state */
} ParseState;

/* Record descriptor designed to dynamically hold sequential linear code string components */
typedef struct TokenString {
    int *str;                     /* Internal memory allocation containing raw token sequence arrays */
    int len;                      /* Active length count of tokens inside storage */
    int allocated_len;            /* Total capacity size boundaries before resizing hooks */
    int last_line_num;            /* Last known line boundary index parameter metadata */
} TokenString;

/* Inclusion caching record descriptor avoiding redundant filesystem overhead reads */
typedef struct CachedInclude {
    int ifndef_macro;             /* Associated guard macro definition register index */
    char type;                    /* Specific token qualifier identification marker matching file scope */
    char filename[1];             /* Extensible continuous layout tracking the literal path string */
} CachedInclude;

/* Core Global Lexical Parser Context States */
static struct BufferedFile *file; /* Dynamic file object currently under parsing */
static int ch, tok;               /* Read character cache and current lexical evaluation token */
static CValue tokc;               /* Current literal value assigned to active lexical token */
static CString tokcstr;           /* Active continuous character string builder container context */

static int tok_flags;             /* Special analytical state modifiers tracking position context */
#define TOK_FLAG_BOL   0x0001     /* Token occupies absolute Beginning-Of-Line layout location */
#define TOK_FLAG_BOF   0x0002     /* Token occupies absolute Beginning-Of-File layout location */
#define TOK_FLAG_ENDIF 0x0004     /* Lexical block processing completed successfully matching ifdef */
/* 03/08/2026 - TCC 0.9.24 */
#define TOK_FLAG_EOF   0x0008 /* end of file */

static int *macro_ptr, *macro_ptr_allocated;
static int *unget_saved_macro_ptr;
static int unget_saved_buffer[TOK_MAX_SIZE + 1];
static int unget_buffer_enabled;
static int parse_flags;
#define PARSE_FLAG_PREPROCESS 0x0001 /* Enforce standard source preprocessor execution tracking */
#define PARSE_FLAG_TOK_NUM    0x0002 /* Interpret character sequences as raw native numbers directly */
#define PARSE_FLAG_LINEFEED   0x0004 /* Capture carriage break signals returning them as standard tokens */
/* 28/07/2026 - TCC 0.9.23 */
#define PARSE_FLAG_ASM_COMMENTS 0x0008 /* '#' can be used for line comment */

/* Core structural section endpoints mapped globally within memory architecture */
static Section *text_section, *data_section, *bss_section; 
static Section *cur_text_section; /* Target structural window code execution engine active mapping */

/* 29/07/2026 - TCC 0.9.23 */
#ifdef CONFIG_TCC_ASM
static Section *last_text_section; /* to handle .previous asm directive */
#endif

/* Core global lookup tables linking symbols to memory segments */
static Section *symtab_section, *strtab_section;

/* Compilation workspace layout descriptors capturing debug traces */
static Section *stab_section, *stabstr_section;

/* Compilation Metric Layout Tracking Indexes:
   loc : Active local scope offset track register
   ind : Direct emission memory machine code output offset track register
   rsym: Target tracking symbol index evaluating operational returns
   anon_sym: Tracker register counting unique anonymous layout structures
*/
static int rsym, anon_sym, ind, loc;

static int const_wanted;          /* Truth criteria determining compile-time validation evaluation */
static int nocode_wanted;         /* Suppress hardware binary optimization instruction emission blocks */
static int global_expr;           /* Force compound tracking symbols directly inside permanent scopes */
static CType func_vt;             /* Track and assert standard operational return data definitions */
static int func_vc;
static int last_line_num, last_ind, func_ind; /* Analytical metric tracking variables */
static int tok_ident;
static TokenSym **table_ident;
static TokenSym *hash_ident[TOK_HASH_SIZE];
static char token_buf[STRING_MAX_SIZE + 1];
static char *funcname;
static Sym *global_stack, *local_stack;
static Sym *define_stack;
static Sym *global_label_stack, *local_label_stack;

/* 29/07/2026 - TCC 0.9.23 */
/* symbol allocator */
#define SYM_POOL_NB (8192 / sizeof(Sym))
static Sym *sym_free_first;

static SValue vstack[VSTACK_SIZE], *vtop;
/* Predefined core compiler type descriptors */
static CType char_pointer_type, func_old_type, int_type;
/* Fast lookup table determining valid identifier and numeric character scopes: true if isid(c) || isnum(c) */
static unsigned char isidnum_table[256];

/* 03/08/2026 */
/* Compile with native debug symbol infrastructure support */
// static int do_debug = 0;

static int total_lines;
static int total_bytes;

/* Enable standard GNU C compiler semantic language extensions */
static int gnu_ext = 1;

/* Enable native Tiny C specific compiler optimization extensions */
static int tcc_ext = 1;

/* 03/08/2026 */
/* 08/07/2026 - Google AI */
// int do_bounds_check = 0;
// Section *lbounds_section = NULL;

/* Core global pointer tracking active compiler state instance context */
static struct TCCState *tcc_state;

/* Base installation filesystem directory path routing internal include directories */
static const char *tcc_lib_path = ".";  /* 09/07/2026 */

/* Master global state container tracking compilation session metrics */
struct TCCState {
    int output_type;              /* Selected emission file format target mode (OBJ or EXE) */
 
    BufferedFile **include_stack_ptr;
    int *ifdef_stack_ptr;

    /* Preprocessor continuous filesystem include search parameters */
    char **include_paths;
    int nb_include_paths;
    char **sysinclude_paths;
    int nb_sysinclude_paths;
    CachedInclude **cached_includes;
    int nb_cached_includes;

    char **library_paths;
    int nb_library_paths;

    /* Low-level storage containing structural binary sections memory maps */
    Section **sections;
    int nb_sections;              /* Total count of registered memory allocation segments */

    /* If true, standard compiler system headers are completely bypassed */
    int nostdinc;
    /* 28/07/2026 - TCC 0.9.23 (Modified) */
    int nostdlib;                 /* if true, no standard libraries are added */

    /* 29/07/2026 */
    int nocommon; /* if true, do not use common symbols for .bss data */

    /* 29/07/2026 */
    /* If true, enforces absolute pure static compilation linking modes */
    // int static_link;

    /* Runtime compilation error interception mechanisms */
    /* 29/07/2026 */    
    // void *error_opaque;
    // void (*error_func)(void *opaque, const char *msg);
    // int error_set_jmp_enabled;
    // jmp_buf error_jmp_buf;
    int nb_errors;

    /* 29/07/2026 */

    /* C language options */
    int char_is_unsigned;
    int leading_underscore;

    /* warning switches */
    int warn_write_strings;
    int warn_unsupported;
    int warn_error;

    /* 28/07/2026 - TCC 0.9.23 (Modified) */
    int warn_none;

    /* 29/07/2026 */
    int warn_implicit_function_declaration;

    /* Embedded architecture-specific inline assembler label stack descriptor */
    Sym *asm_labels;

    /* Core physical static array structures recording stack track offsets */
    BufferedFile *include_stack[INCLUDE_STACK_SIZE];
    int ifdef_stack[IFDEF_STACK_SIZE];
};

/* The current value state registers configuration markers: */
#define VT_VALMASK   0x00ff
#define VT_CONST     0x00f0  /* Literal constant in evaluation cache (must be first non-register value) */
#define VT_LLOCAL    0x00f1  /* Lvalue descriptor, tracked variable offset on hardware stack */
#define VT_LOCAL     0x00f2  /* Evaluated variable storage location offset on stack */
#define VT_CMP       0x00f3  /* Temporary value stored directly inside hardware processor flags */
#define VT_JMP       0x00f4  /* Direct jump target routing resolution on truth evaluation (even) */
#define VT_JMPI      0x00f5  /* Direct jump target routing resolution on false evaluation (odd) */
#define VT_LVAL      0x0100  /* Memory reference address identifier acts as an active lvalue */
#define VT_SYM       0x0200  /* Lexical symbol reference address offset tracking multiplication marker */
#define VT_MUSTCAST  0x0400  /* Type conversion enforcement flag (used for char/short promotions in 32-bit registers) */
#define VT_LVAL_BYTE     0x1000  /* Lvalue references a single byte data boundary layout */
#define VT_LVAL_SHORT    0x2000  /* Lvalue references a 16-bit short integer data boundary layout */
#define VT_LVAL_UNSIGNED 0x4000  /* Lvalue references an unsigned data type memory block */
#define VT_LVAL_TYPE     (VT_LVAL_BYTE | VT_LVAL_SHORT | VT_LVAL_UNSIGNED)

#define VT_INT        0  /* Native 32-bit signed integer type */
#define VT_BYTE       1  /* Native 8-bit signed byte integer type */
#define VT_SHORT      2  /* Native 16-bit signed short integer type */
#define VT_VOID       3  /* Void storage completion structure representation type */
#define VT_PTR        4  /* Explicit memory address reference pointer memory layout pointer */
#define VT_ENUM       5  /* Enumerated list variable constraint descriptor structure */
#define VT_FUNC       6  /* Executable routine function signature entry mapping type */
#define VT_STRUCT     7  /* Composite memory record structural layout specification (struct/union) */
#define VT_FLOAT      8  /* Single-precision IEEE-754 hardware floating-point layout configuration */
#define VT_DOUBLE     9  /* Double-precision IEEE-754 hardware floating-point layout configuration */
#define VT_LDOUBLE   10  /* Extended-precision long double hardware floating-point layout configuration */
#define VT_BOOL      11  /* ISO C99 compliant strict true/false boolean storage configuration */
#define VT_LLONG     12  /* 64-bit extended composite signed integer data structure type */
#define VT_LONG      13  /* Legacy syntax tracker alias (evaluated and converted during parsing phase) */
#define VT_BTYPE      0x000f /* Logical isolation filter masking the core basic runtime types */
#define VT_UNSIGNED   0x0010  /* Modifier marking the type boundaries as positive unsigned memory data */
#define VT_ARRAY      0x0020  /* Contiguous array structure memory layout modifier (implicitly enforces VT_PTR) */
#define VT_BITFIELD   0x0040  /* Special structure internal boundary bitfield allocation track modifier */

/* 28/07/2026 - TCC 0.9.23 */
#define VT_CONSTANT   0x0800  /* const modifier */
#define VT_VOLATILE   0x1000  /* volatile modifier */
#define VT_SIGNED     0x2000  /* signed type */

/* Variable allocation persistence storage classes */
#define VT_EXTERN  0x00000080  /* External reference symbol linkage configuration marker */
#define VT_STATIC  0x00000100  /* Scope-restricted persistent internal storage visibility class */
#define VT_TYPEDEF 0x00000200  /* Alias definition mapper overriding structural type descriptors */
#define VT_INLINE  0x00000400  /* Inline expansion recommendation hint compiler optimization marker */

/* Core compilation language primitive type maps */
// #define VT_STRUCT_SHIFT 12 /* Hardware namespace isolation shift parameter for structure/enum records */
/* 06/08/2026 */
#define VT_STRUCT_SHIFT 16    /* shift for bitfield shift values */

/* Bitmask filters extracting layout specifics */
#define VT_STORAGE (VT_EXTERN | VT_STATIC | VT_TYPEDEF | VT_INLINE)
#define VT_TYPE    (~(VT_STORAGE))

/* Lexical Analyzer Logical Validation Token Assignments */

/* Warning: The layout configuration of the following conditional tokens directly impacts i386 asm emission */
#define TOK_ULT 0x92
#define TOK_UGE 0x93
#define TOK_EQ  0x94
#define TOK_NE  0x95
#define TOK_ULE 0x96
#define TOK_UGT 0x97
#define TOK_LT  0x9c
#define TOK_GE  0x9d
#define TOK_LE  0x9e
#define TOK_GT  0x9f

#define TOK_LAND  0xa0
#define TOK_LOR   0xa1

#define TOK_DEC   0xa2
#define TOK_MID   0xa3 /* Boundary tracking utility converting inc/dec markers to void expressions */
#define TOK_INC   0xa4
#define TOK_UDIV  0xb0 /* Mathematical unsigned integer division hardware processor configuration */
#define TOK_UMOD  0xb1 /* Mathematical unsigned integer modulo hardware processor configuration */
#define TOK_PDIV  0xb2 /* Hardware memory pointer scale division boundary validation shortcut */
#define TOK_CINT   0xb3 /* Integer literal configuration parsed data tracking address token */
#define TOK_CCHAR 0xb4 /* Character literal configuration parsed data tracking address token */
#define TOK_STR   0xb5 /* String literal baseline pointer memory token captured inside tokc storage */
#define TOK_TWOSHARPS 0xb6 /* Preprocessor string concatenation compilation instruction operator token (##) */
#define TOK_LCHAR    0xb7
#define TOK_LSTR     0xb8
#define TOK_CFLOAT   0xb9 /* Single-precision floating point constant validation metadata block */
#define TOK_LINENUM  0xba /* Preprocessor sequential tracking index validation indicator token */
#define TOK_CDOUBLE  0xc0 /* Double-precision floating point constant validation metadata block */
#define TOK_CLDOUBLE 0xc1 /* Extended long double floating point constant validation metadata block */
#define TOK_UMULL    0xc2 /* Mathematical unsigned 32-bit x 32-bit to 64-bit precision multiplication */
#define TOK_ADDC1    0xc3 /* Low-level processor mathematical addition enabling hardware carry generation flags */
#define TOK_ADDC2    0xc4 /* Low-level processor mathematical addition enforcing historical carry evaluation flags */
#define TOK_SUBC1    0xc5 /* Low-level processor mathematical subtraction enabling hardware borrow generation flags */
#define TOK_SUBC2    0xc6 /* Low-level processor mathematical subtraction enforcing historical borrow evaluation flags */
#define TOK_CUINT    0xc8 /* Unsigned integer literal data tracking validation token configuration */
#define TOK_CLLONG   0xc9 /* 64-bit long long numeric constant evaluation parsing tracking token */
#define TOK_CULLONG  0xca /* 64-bit unsigned long long numeric constant evaluation parsing tracking token */
#define TOK_ARROW    0xcb
#define TOK_DOTS     0xcc /* Variadic parameter indicator validation ellipsis token (...) */
#define TOK_SHR      0xcd /* Logically isolated bitwise unsigned shift right execution token */
#define TOK_PPNUM    0xce /* Raw preprocessor digit sequence evaluation string token */

#define TOK_SHL   0x01 /* Bitwise shift left data execution token instruction descriptor */
#define TOK_SAR   0x02 /* Bitwise signed arithmetic shift right data execution token instruction descriptor */
  
/* Self-referencing shorthand assignment expression token modifiers (Base Operator masked with 0x80) */
#define TOK_A_MOD 0xa5
#define TOK_A_AND 0xa6
#define TOK_A_MUL 0xaa
#define TOK_A_ADD 0xab
#define TOK_A_SUB 0xad
#define TOK_A_DIV 0xaf
#define TOK_A_XOR 0xde
#define TOK_A_OR  0xfc
#define TOK_A_SHL 0x81
#define TOK_A_SAR 0x82

/* 29/07/2026 - TCC 0.9.23 */
#ifndef offsetof
#define offsetof(type, field) ((size_t) &((type *)0)->field)
#endif

#ifndef countof
#define countof(tab) (sizeof(tab) / sizeof((tab)[0]))
#endif

/* WARNING: The exact internal storage layout string map indexes token definitions sequentially */
static char tok_two_chars[] = "<=\236>=\235!=\225&&\240||\241++\244--\242==\224<<\1>>\2+=\253-=\255*=\252/=\257%=\245&=\246^=\336|=\374->\313..\250##\266";

#define TOK_EOF       (-1)  /* Terminal End-Of-File parsing pipeline signal code */
#define TOK_LINEFEED  10    /* Standard control signal carriage feed break point */

/* The fundamental base boundary offset. All identifiers and literal strings evaluate above this limit */
#define TOK_IDENT 256

/* Core structural formatting macros translating inline human-readable architecture opcodes to token configurations */
#define DEF_ASM(x) DEF(TOK_ASM_ ## x, #x)

#define DEF_BWL(x) \
 DEF(TOK_ASM_ ## x ## b, #x "b") \
 DEF(TOK_ASM_ ## x ## w, #x "w") \
 DEF(TOK_ASM_ ## x ## l, #x "l") \
 DEF(TOK_ASM_ ## x, #x)

#define DEF_WL(x) \
 DEF(TOK_ASM_ ## x ## w, #x "w") \
 DEF(TOK_ASM_ ## x ## l, #x "l") \
 DEF(TOK_ASM_ ## x, #x)

#define DEF_FP1(x) \
 DEF(TOK_ASM_ ## f ## x ## s, "f" #x "s") \
 DEF(TOK_ASM_ ## fi ## x ## l, "fi" #x "l") \
 DEF(TOK_ASM_ ## f ## x ## l, "f" #x "l") \
 DEF(TOK_ASM_ ## fi ## x ## s, "fi" #x "s")

#define DEF_FP(x) \
 DEF(TOK_ASM_ ## f ## x, "f" #x ) \
 DEF(TOK_ASM_ ## f ## x ## p, "f" #x "p") \
 DEF_FP1(x)

#define DEF_ASMTEST(x) \
 DEF_ASM(x ## o) \
 DEF_ASM(x ## no) \
 DEF_ASM(x ## b) \
 DEF_ASM(x ## c) \
 DEF_ASM(x ## nae) \
 DEF_ASM(x ## nb) \
 DEF_ASM(x ## nc) \
 DEF_ASM(x ## ae) \
 DEF_ASM(x ## e) \
 DEF_ASM(x ## z) \
 DEF_ASM(x ## ne) \
 DEF_ASM(x ## nz) \
 DEF_ASM(x ## be) \
 DEF_ASM(x ## na) \
 DEF_ASM(x ## nbe) \
 DEF_ASM(x ## a) \
 DEF_ASM(x ## s) \
 DEF_ASM(x ## ns) \
 DEF_ASM(x ## p) \
 DEF_ASM(x ## pe) \
 DEF_ASM(x ## np) \
 DEF_ASM(x ## po) \
 DEF_ASM(x ## l) \
 DEF_ASM(x ## nge) \
 DEF_ASM(x ## nl) \
 DEF_ASM(x ## ge) \
 DEF_ASM(x ## le) \
 DEF_ASM(x ## ng) \
 DEF_ASM(x ## nle) \
 DEF_ASM(x ## g)

#define TOK_ASM_int TOK_INT

/* 09/08/2026 */
#ifndef NULL
#define NULL ((void *)0)
#endif

enum tcc_token {
    TOK_LAST = TOK_IDENT - 1,
#define DEF(id, str) id,
#include "tcctok.h"
#undef DEF
};

static const char tcc_keywords[] =
#define DEF(id, str) str "\0"
#include "tcctok.h"
#undef DEF
;

#define TOK_UIDENT TOK_DEFINE

/* 29/07/2026 */
#undef exit
void trdos_sys_exit(int exitcode);
#define exit trdos_sys_exit
/* ....... */

/* =========================================================================
   GOOGLE AI & ERDOGAN TAN - THE UNIFICATION VICTORY (SNPRINTF OVERRIDE)
   =========================================================================
   Neutralize standard/MinGW snprintf macros completely to prevent core stack 
   corruption. Forcefully bind all thread-safe continuous string formatting 
   directly to our native 'trdos_snprintf' bridge located inside libc. */
#undef snprintf
#undef _snprintf

/* Native snprintf translation bridge defined inside TRDOS 386 libc_printf_bridge.s */
extern int trdos_snprintf(char *str, unsigned int size, const char *format, ...);

#define snprintf trdos_snprintf
#define _snprintf trdos_snprintf

/* 13/08/2026 */
/* Standard ISOC99 mathematical float conversion configurations */
// extern float strtof (const char *__nptr, char **__endptr);
// extern long double strtold (const char *__nptr, char **__endptr);

/* Core internal compiler continuous string utility wrappers */
static char *pstrcpy(char *buf, int buf_size, const char *s);
static char *pstrcat(char *buf, int buf_size, const char *s);

/* Lexical Parser Pipeline Token Advancement Functions */
static void next(void);
static void next_nomacro(void);
static void parse_expr_type(CType *type);
static void expr_type(CType *type);
static void unary_type(CType *type);
static void block(int *bsym, int *csym, int *case_sym, int *def_sym, 
                  int case_reg, int is_expr);
static int expr_const(void);
static void expr_eq(void);
static void gexpr(void);
/* 29/07/2026 - TCC 0.9.23 */
static void gen_inline_functions(void);
static void decl(int l);
static void decl_initializer(CType *type, Section *sec, unsigned long c, 
                             int first, int size_only);
static void decl_initializer_alloc(CType *type, AttributeDef *ad, int r, 
                                   int has_init, int v, int scope);

/* Backend X86 Machine Code Code-Generator Engine Functions */
int gv(int rc);
void gv2(int rc1, int rc2);
void move_reg(int r, int s);
void save_regs(int n);
void save_reg(int r);
void vpop(void);
void vswap(void);
void vdup(void);
int get_reg(int rc);

/* 03/08/2026 - TCC 0.9.24 */
struct macro_level {
    struct macro_level *prev;
    int *p;
};

// static void macro_subst(TokenString *tok_str,
//                      Sym **nested_list, const int *macro_str);
/* 03/08/2026 - TCC 0.9.24 */
static void macro_subst(TokenString *tok_str, Sym **nested_list,
                        const int *macro_str, struct macro_level **can_read_stream);
/* 03/08/2026 */
// int save_reg_forced(int r);

void gen_op(int op);
void force_charshort_cast(int t);
static void gen_cast(CType *type);
void vstore(void);
static Sym *sym_find(int v);
static Sym *sym_push(int v, CType *type, int r, int c);

/* Compilation Semantic Type Boundary Handling Engines */
static int type_size(CType *type, int *a);
static inline CType *pointed_type(CType *type);
static int pointed_size(CType *type);
static int lvalue_type(int t);
static int parse_btype(CType *type, AttributeDef *ad);
static void type_decl(CType *type, AttributeDef *ad, int *v, int td);
/* 03/08/2026 */
static int is_compatible_types(CType *type1, CType *type2);
static int is_compatible_parameter_types(CType *type1, CType *type2);

/* Error Logging and Diagnostic Framework */
void error(const char *fmt, ...);
void vpushi(int v);
/* 28/07/2026 - TCC 0.9.23 */
void vrott(int n);
void vset(CType *type, int r, int v);
void type_to_str(char *buf, int buf_size,
                 CType *type, const char *varstr);
char *get_tok_str(int v, CValue *cv);
static Sym *get_sym_ref(CType *type, Section *sec,
                        unsigned long offset, unsigned long size);
static Sym *external_global_sym(int v, CType *type, int r);

/* Flat ELF/PRG Structured Section Generation Routines */
static void section_realloc(Section *sec, unsigned long new_size);
static void *section_ptr_add(Section *sec, unsigned long size);
static void put_extern_sym(Sym *sym, Section *section,
                           unsigned long value, unsigned long size);
static void greloc(Section *s, Sym *sym, unsigned long addr, int type);
static int put_elf_str(Section *s, const char *sym);
static int put_elf_sym(Section *s,
                       unsigned long value, unsigned long size,
                       int info, int other, int shndx, const char *name);
static int add_elf_sym(Section *s, unsigned long value, unsigned long size,
                       int info, int sh_num, const char *name);
static void put_elf_reloc(Section *symtab, Section *s, unsigned long offset,
                          int type, int symbol);

/* 03/08/2026 */
/* Technical Debug Tracking Traces Emission Engines (STABS) */
// static void put_stabs(const char *str, int type, int other, int desc,
//                      unsigned long value);
// static void put_stabs_r(const char *str, int type, int other, int desc,
//                        unsigned long value, Section *sec, int sym_index);
// static void put_stabn(int type, int other, int desc, int value);
// static void put_stabd(int type, int other, int desc);

/* Native Core Filesystem Ingestion Engines */
#define AFF_PRINT_ERROR 0x0001 /* Print explicit diagnostics if target source file is missing */
// #define AFF_REFERENCED_DLL 0x0002 /* load a referenced dll from another dll */
/* 02/08/2026 */
#define AFF_PREPROCESS  0x0004 /* preprocess file */

static int tcc_add_file_internal(TCCState *s, const char *filename, int flags);

/* 29/07/2026 - TCC 0.9.23 */

#ifdef CONFIG_TCC_ASM

typedef struct ExprValue {
    uint32_t v;
    Sym *sym;
} ExprValue;

#define MAX_ASM_OPERANDS 30

typedef struct ASMOperand {
    int id; /* GCC 3 optional identifier (0 if number only supported) */
    char *constraint;
    char asm_str[16]; /* computed asm string for operand */
    SValue *vt; /* C value of the expression */
    int ref_index; /* if >= 0, gives reference to a output constraint */
    int input_index; /* if >= 0, gives reference to an input constraint */
    int priority; /* priority, used to assign registers */
    int reg; /* if >= 0, register number used for this operand */
    int is_llong; /* true if double register value */
    int is_memory; /* true if memory operand */
    int is_rw;     /* for '+' modifier */
} ASMOperand;

static void asm_expr(TCCState *s1, ExprValue *pe);
static int asm_int_expr(TCCState *s1);
static int find_constraint(ASMOperand *operands, int nb_operands, 
                           const char *name, const char **pp);

static int tcc_assemble(TCCState *s1, int do_preprocess);

#endif

/* ...... */

static void asm_instr(void);
/* 29/07/2026 - TCC 0.9.23 */
static void asm_global_instr(void);

static inline int is_float(int t) { int bt; bt = t & VT_BTYPE; return bt == VT_LDOUBLE || bt == VT_DOUBLE || bt == VT_FLOAT; }
#ifdef TCC_TARGET_I386
#include "i386-gen.c"
#endif

/* Standard IEEE-754 floating point verification to bypass non-standard math library dependency artifacts */
int ieee_finite(double d)
{
    int *p = (int *)&d;
    return ((unsigned)((p[1] | 0x800fffff) + 1)) >> 31;
}

/* Copy a source string safely and enforce strict truncation limitations */
static char *pstrcpy(char *buf, int buf_size, const char *s)
{
    char *q, *q_end;
    int c;

    if (buf_size > 0) {
        q = buf;
        q_end = buf + buf_size - 1;
        while (q < q_end) {
            c = *s++;
            if (c == '\0')
                break;
            *q++ = c;
        }
        *q = '\0';
    }
    return buf;
}

/* Concatenate a source string safely and enforce strict truncation limitations */
static char *pstrcat(char *buf, int buf_size, const char *s)
{
    int len;
    len = strlen(buf);
    if (len < buf_size) 
        pstrcpy(buf + len, buf_size - len, s);
    return buf;
}

/* 24/07/2026 - Google AI */
/* =========================================================================
   TRDOS 386 - TCC_FREE SAFE PURE RET ALIAS ANCHOR (25/07/2026)
   ========================================================================= */
extern void trdos_free(void *ptr);

/* Absolute minimal heap allocation wrappers tailored for TRDOS 386 native workspace */
static inline void tcc_free(void *ptr)
{
    // free(ptr);
    /* 24/07/2026 */
    trdos_free(ptr);
}

static void *tcc_malloc(unsigned long size)
{
    void *ptr;
    ptr = malloc(size);
    if (!ptr && size)
        error("memory full");
    return ptr;
}

static void *tcc_mallocz(unsigned long size)
{
    void *ptr;
    ptr = tcc_malloc(size);
    memset(ptr, 0, size);
    return ptr;
}

/* 09/08/2026 - TCC.PRG 0.9.24 Self-compiling */
// static inline void *tcc_realloc(void *ptr, unsigned long size)
// {
//    void *ptr1;
//    // ptr1 = realloc(ptr, size);
//    /* 09/08/2026 */
//    ptr1 = trdos_realloc(ptr, size);
//    return ptr1;
// }

static char *tcc_strdup(const char *str)
{
    char *ptr;
    ptr = tcc_malloc(strlen(str) + 1);
    strcpy(ptr, str);
    return ptr;
}

// #define free(p) use_tcc_free(p)
// #define malloc(s) use_tcc_malloc(s)
// #define realloc(p, s) use_tcc_realloc(p, s)

/* 17/07/2026 */
#define free(p) tcc_free(p)
#define malloc(s) tcc_malloc(s)
/* 09/08/2026 - TCC.PRG 0.9.24 Self-compiling */
// #define realloc(p, s) tcc_realloc(p, s)

/* Dynamic sequence manager expanding target array structures at power-of-two operational thresholds */
static void dynarray_add(void ***ptab, int *nb_ptr, void *data)
{
    int nb, nb_alloc;
    void **pp;
    
    nb = *nb_ptr;
    pp = *ptab;
    
    if ((nb & (nb - 1)) == 0) {
        if (!nb)
            nb_alloc = 1;
        else
            nb_alloc = nb * 2;
        pp = tcc_realloc(pp, nb_alloc * sizeof(void *));
        if (!pp)
            error("memory full");
        *ptab = pp;
    }
    pp[nb++] = data;
    *nb_ptr = nb;
}

/* 29/07/2026 - TCC 0.9.23 */
static inline void sym_free(Sym *sym)
{
    sym->next = sym_free_first;
    sym_free_first = sym;
}

/* Create and initialize a new structured binary layout section */
Section *new_section(TCCState *s1, const char *name, int sh_type, int sh_flags)
{
    Section *sec;

    sec = tcc_mallocz(sizeof(Section));
    pstrcpy(sec->name, sizeof(sec->name), name);
    sec->sh_type = sh_type;
    sec->sh_flags = sh_flags;
    
    switch(sh_type) {
    case SHT_HASH:
    case SHT_REL:
    case SHT_DYNSYM:
    case SHT_SYMTAB:
    case SHT_DYNAMIC:
        sec->sh_addralign = 4;
        break;
    case SHT_STRTAB:
        sec->sh_addralign = 1;
        break;
    default:
        sec->sh_addralign = 32; /* Default conservative alignment for code/data segments */
        break;
    }

    /* Only register section globally if it is not flagged as private internal storage */
    if (!(sh_flags & SHF_PRIVATE)) {
        sec->sh_num = s1->nb_sections;
        dynarray_add((void ***)&s1->sections, &s1->nb_sections, sec);
    }
    return sec;
}

/* Purge section memory block frames from heap */
static void free_section(Section *s)
{
    tcc_free(s->data);
    tcc_free(s);
}

/* Reallocate section memory block dynamically and wipe new memory window to zero */
static void section_realloc(Section *sec, unsigned long new_size)
{
    unsigned long size;
    unsigned char *data;
    
    size = sec->data_allocated;
    if (size == 0)
        size = 1;
    while (size < new_size)
        size = size * 2;
        
    data = tcc_realloc(sec->data, size);
    if (!data)
        error("memory full");
        
    memset(data + sec->data_allocated, 0, size - sec->data_allocated);
    sec->data = data;
    sec->data_allocated = size;
}

/* Reserve at least 'size' bytes in target section beginning from current data offset */
static void *section_ptr_add(Section *sec, unsigned long size)
{
    unsigned long offset, offset1;

    offset = sec->data_offset;
    offset1 = offset + size;
    if (offset1 > sec->data_allocated)
        section_realloc(sec, offset1);
    sec->data_offset = offset1;
    return sec->data + offset;
}

/* Flat Segment Alignment Engine: Locate an existing section or construct a new PROGBITS allocator */
Section *find_section(TCCState *s1, const char *name)
{
    Section *sec;
    int i;
    for(i = 1; i < s1->nb_sections; i++) {
        sec = s1->sections[i];
        if (!strcmp(name, sec->name)) 
            return sec;
    }
    /* Default newly discovered target sections directly as standard allocatable PROGBITS */
    return new_section(s1, name, SHT_PROGBITS, SHF_ALLOC);
}

/* 29/07/2026 - TCC 0.9.23 */
#define SECTION_ABS ((void *)1)

/* Update structural symbol index properties mapping them to low-level target section definitions */
static void put_extern_sym2(Sym *sym, Section *section, 
                            unsigned long value, unsigned long size,
                            int can_add_underscore)
{
    int sym_type, sym_bind, sh_num, info;
    Elf32_Sym *esym;
    const char *name;
    // char buf1[256];  /* 29/07/2026 - TCC 0.9.23 */

    /* 29/07/2026 - TCC 0.9.23 */
    if (section == NULL)
        sh_num = SHN_UNDEF;
    else if (section == SECTION_ABS) 
        sh_num = SHN_ABS;
    else
        sh_num = section->sh_num;

    if (!sym->c) {
        if ((sym->type.t & VT_BTYPE) == VT_FUNC)
            sym_type = STT_FUNC;
        else
            sym_type = STT_OBJECT;

        if (sym->type.t & VT_STATIC)
            sym_bind = STB_LOCAL;
        else
            sym_bind = STB_GLOBAL;

        name = get_tok_str(sym->v, NULL);

        /* 29/07/2026 - TCC 0.9.23 (Modified) */
        if (tcc_state->leading_underscore && can_add_underscore) {
            char buf1[256]; /* 29/07/2026 */
            buf1[0] = '_';
            pstrcpy(buf1 + 1, sizeof(buf1) - 1, name);
            name = buf1;
        }

        info = ELF32_ST_INFO(sym_bind, sym_type);
        sym->c = add_elf_sym(symtab_section, value, size, info, sh_num, name);
    } else {
        esym = &((Elf32_Sym *)symtab_section->data)[sym->c];
        esym->st_value = value;
        esym->st_size = size;
        esym->st_shndx = sh_num;
    }
}

/* 29/07/2026 - TCC 0.9.23 */
static void put_extern_sym(Sym *sym, Section *section, 
                           unsigned long value, unsigned long size)
{
    put_extern_sym2(sym, section, value, size, 1);
}

/* Enject a new active relocation entry pointing to symbol identifier within structural section s */
static void greloc(Section *s, Sym *sym, unsigned long offset, int type)
{
    if (!sym->c) 
        put_extern_sym(sym, NULL, 0, 0);
    /* Bind verified ELF structural relocation metadata parameters straight to output table */
    put_elf_reloc(symtab_section, s, offset, type, sym->c);
}

/* Fast lexical evaluation helper checking for valid alphabetic or underscore identifier tokens */
static inline int isid(int c)
{
    return (c >= 'a' && c <= 'z') ||
        (c >= 'A' && c <= 'Z') ||
        c == '_';
}

/* Fast lexical evaluation helper checking for valid base-10 digit sequences */
static inline int isnum(int c)
{
    return c >= '0' && c <= '9';
}

/* Fast lexical evaluation helper checking for valid octal sequences */
static inline int isoct(int c)
{
    return c >= '0' && c <= '7';
}

/* Translate lowercase alphabetic token identifiers directly to uppercase equivalents */
static inline int toup(int c)
{
    if (c >= 'a' && c <= 'z')
        return c - 'a' + 'A';
    else
        return c;
}

/* 03/08/2026 */
/* Variadic sequential formatting buffer expansion utility wrapper */
// static void strcat_vprintf(char *buf, int buf_size, const char *fmt, va_list ap)
// {
//    int len;
//    len = strlen(buf);
//    vsnprintf(buf + len, buf_size - len, fmt, ap);
// }

/* 03/08/2026 */
/* Standard sequential formatting string expansion bridge targeting strcat_vprintf */
// static void strcat_printf(char *buf, int buf_size, const char *fmt, ...)
// {
//    va_list ap;
//    va_start(ap, fmt);
//    strcat_vprintf(buf, buf_size, fmt, ap);
//    va_end(ap);
// }

/* Internal detailed diagnostics generator tracking structural preprocessor include file trace stacks */
/* 29/07/2026 */
/* 20/07/2026 - Google AI */
/* =========================================================================
   TRDOS 386 FLAT BELLEK UYUMLU DOĞRUDAN DIAGNOSTIC MOTORU
   ========================================================================= */
// void error1_flat(TCCState *s1, const char *fmt, void *arg1, void *arg2, void *arg3)
/* 29/07/2026 - TCC 0.9.23 (Modified) */
void error1_flat(TCCState *s1, int is_warning, const char *fmt, void *arg1, void *arg2, void *arg3)
{
    BufferedFile **f;

    /* 1. Include yığın izleme mekanizması */
    if (file && s1) {
        for(f = s1->include_stack; f < s1->include_stack_ptr; f++) {
            if (*f && (*f)->filename) {
                printf("In file included from %s:%d:\n", (*f)->filename, (*f)->line_num);
            }
        }
        /* 2. Dosya adı ve satır numarası basımı */
        if (file->filename) {
            if (file->line_num > 0) {
                printf("%s:%d: ", file->filename, file->line_num);
            } else {
                printf("%s: ", file->filename);
            }
        }
    } else {
        printf("tcc: ");
    }

    // printf("error: ");
    /* 29/07/2026 - TCC 0.9.23 (Modified) */
    if (is_warning) {
       printf("warning: ");
    } else {
       printf("error: ");
    }

    /* 3. Kararsız vprintf yerine standart printf ile güvenli formatlama */
    printf(fmt, arg1, arg2, arg3);
    printf("\n");

    // if (s1) s1->nb_errors++;
    /* 29/07/2026 - TCC 0.9.23 (Modified) */
    if (s1) {
        if (!is_warning || s1->warn_error)
            s1->nb_errors++;
    }
}

/* 29/07/2026 */
/* 20/07/2026 - Google AI */
/* =========================================================================
   GOOGLE AI & ERDOGAN TAN - CRITICAL FATAL EVACUATION SHIELD
   ========================================================================= */
void error(const char *fmt, ...)
{
    TCCState *s1 = tcc_state;
    void **args = (void **)&fmt;

    printf("\n-> [TCC FATAL ERROR]: ");

    /* va_list kullanılmaz! Stack üzerindeki argümanlar sıralı olarak yakalanır */
    // error1_flat(s1, fmt, args[1], args[2], args[3]);
    /* 29/07/2026 - TCC 0.9.23 (Modified) */
    error1_flat(s1, 0, fmt, args[1], args[2], args[3]);

    printf("-> [TRDOS SHIELD]: Terminating via sys_exit(1).\n");

    /* 09/08/2026 */
    /* Fatal enforcement trap: Trigger hardware system exit interrupt call */
    // __asm__ (
    //    "movl $1, %%ebx\n\t"           /* Exit parameter payload: 1 (Error) */
    //    "movl $1, %%eax\n\t"           /* TRDOS kernel service index: sys_exit */
    //    "int $0x40"                   /* Vector directly into Ring 0 */
    // );
   
    /* 31/07/2026 */
    exit(1);	 /* trdos_sys_exit(int exit_code) */
}

/* 29/07/2026 */
/* 20/07/2026 - Google AI */
/* =========================================================================
   GOOGLE AI & ERDOGAN TAN - NON-ABORTING DIAGNOSTIC INTERCEPTOR
   =========================================================================
   Artık error1'i çağırarak dosya adı ve satır numarasını görünür kılar. */
void error_noabort(const char *fmt, ...)
{
    TCCState *s1 = tcc_state;
    void **args = (void **)&fmt;

    printf("\n-> [TCC WARNING/ERROR]: ");

    /* va_list kullanılmaz! Stack üzerindeki argümanlar sıralı olarak yakalanır */
    // error1_flat(s1, fmt, args[1], args[2], args[3]);
    /* 29/07/2026 - TCC 0.9.23 (Modified) */
    error1_flat(s1, 0, fmt, args[1], args[2], args[3]);

    printf("\n");
}

/* Raise strict structural token expectation failures */
void expect(const char *msg)
{
    error("%s expected", msg);
}

/* 29/07/2026 */
/* 28/07/2026 - TCC.PRG 0.9.23 */
/* 20/07/2026 - TCC.PRG 0.9.18 */
/* Capture standard grammar deviations sending localized traces to the tracker engine */
void warning(const char *fmt, ...)
{
    TCCState *s1 = tcc_state;

    /* 28/07/2026 - TCC 0.9.23 ( Modified) */
    if (s1->warn_none)
       return;

    void **args = (void **)&fmt;
    /* va_list kullanılmaz! Stack üzerindeki argümanlar sıralı olarak yakalanır */
    // error1_flat(s1, fmt, args[1], args[2], args[3]);
    /* 29/07/2026 - TCC 0.9.23 (Modified) */
    error1_flat(s1, 1, fmt, args[1], args[2], args[3]);
}

/* Enforce validation for expected language punctuation markers advancing on match */
void skip(int c)
{
    if (tok != c)
        error("'%c' expected", c);
    next();
}

/* Assert statement parameter eligibility validating register structures contain clear Lvalue properties */
static void test_lvalue(void)
{
    if (!(vtop->r & VT_LVAL))
        expect("lvalue");
}

/* Allocate a completely new unique identifier token slot within the global dictionary */
static TokenSym *tok_alloc_new(TokenSym **pts, const char *str, int len)
{
    TokenSym *ts, **ptable;
    int i;

    if (tok_ident >= SYM_FIRST_ANOM) 
        error("memory full");

    /* Expand global token tracker sequence table if current boundaries are breached */
    i = tok_ident - TOK_IDENT;
    if ((i % TOK_ALLOC_INCR) == 0) {
        ptable = tcc_realloc(table_ident, (i + TOK_ALLOC_INCR) * sizeof(TokenSym *));
        if (!ptable)
            error("memory full");
        table_ident = ptable;
    }

    /* Allocate continuous storage space matching the literal symbol string length */
    ts = tcc_malloc(sizeof(TokenSym) + len);
    table_ident[i] = ts;
    ts->tok = tok_ident++;
    ts->sym_define = NULL;
    ts->sym_label = NULL;
    ts->sym_struct = NULL;
    ts->sym_identifier = NULL;
    ts->len = len;
    ts->hash_next = NULL;
    memcpy(ts->str, str, len);
    ts->str[len] = '\0';
    *pts = ts;
    return ts;
}

#define TOK_HASH_INIT 1
#define TOK_HASH_FUNC(h, c) ((h) * 263 + (c))

/* Query the identifier symbol hash chain or construct a new dictionary node on failure */
static TokenSym *tok_alloc(const char *str, int len)
{
    TokenSym *ts, **pts;
    int i;
    unsigned int h;
    
    h = TOK_HASH_INIT;
    for(i = 0; i < len; i++)
        h = TOK_HASH_FUNC(h, ((unsigned char *)str)[i]);
    h &= (TOK_HASH_SIZE - 1);

    pts = &hash_ident[h];
    for(;;) {
        ts = *pts;
        if (!ts)
            break;
        if (ts->len == len && !memcmp(ts->str, str, len))
            return ts;
        pts = &(ts->hash_next);
    }
    return tok_alloc_new(pts, str, len);
}

/* Dynamic Continuous String (CString) Execution Engines */

/* Resize the dynamic literal character string container to fit newly requested layouts */
static void cstr_realloc(CString *cstr, int new_size)
{
    int size;
    void *data;

    size = cstr->size_allocated;
    if (size == 0)
        size = 8; /* Set conservative initial layout seed to prevent redundant resizing overhead */
    while (size < new_size)
        size = size * 2;
    data = tcc_realloc(cstr->data_allocated, size);
    if (!data)
        error("memory full");
    cstr->data_allocated = data;
    cstr->size_allocated = size;
    cstr->data = data;
}

/* Append a single byte token component straight into the target CString frame */
static void cstr_ccat(CString *cstr, int ch)
{
    int size;
    size = cstr->size + 1;
    if (size > cstr->size_allocated)
        cstr_realloc(cstr, size);
    ((unsigned char *)cstr->data)[size - 1] = ch;
    cstr->size = size;
}

/* Append a sequential null-terminated array of characters straight to the dynamic buffer */
static void cstr_cat(CString *cstr, const char *str)
{
    int c;
    for(;;) {
        c = *str;
        if (c == '\0')
            break;
        cstr_ccat(cstr, c);
        str++;
    }
}

/* Append a standard multi-byte wide character structure straight to the dynamic buffer frame */
static void cstr_wccat(CString *cstr, int ch)
{
    int size;
    size = cstr->size + sizeof(int);
    if (size > cstr->size_allocated)
        cstr_realloc(cstr, size);
    *(int *)(((unsigned char *)cstr->data) + size - sizeof(int)) = ch;
    cstr->size = size;
}

/* Initialize newly allocated CString memory maps */
static void cstr_new(CString *cstr)
{
    memset(cstr, 0, sizeof(CString));
}

/* Deallocate internal active buffer string pools resetting markers to zero */
static void cstr_free(CString *cstr)
{
    tcc_free(cstr->data_allocated);
    cstr_new(cstr);
}

#define cstr_reset(cstr) cstr_free(cstr)

/* 07/08/2026 */
/* Duplicate an existing character container memory layout block precisely */
static CString *cstr_dup(CString *cstr1)
{
   CString *cstr;
   int size;

   cstr = tcc_malloc(sizeof(CString));
   size = cstr1->size;
   cstr->size = size;
   cstr->size_allocated = size;
   cstr->data_allocated = tcc_malloc(size);
   cstr->data = cstr->data_allocated;
   memcpy(cstr->data_allocated, cstr1->data_allocated, size);
   return cstr;
}

/* Map raw binary characters into standardized source escape sequences */
static void add_char(CString *cstr, int c)
{
    if (c == '\'' || c == '\"' || c == '\\') {
        cstr_ccat(cstr, '\\');
    }
    if (c >= 32 && c <= 126) {
        cstr_ccat(cstr, c);
    } else {
        cstr_ccat(cstr, '\\');
        if (c == '\n') {
            cstr_ccat(cstr, 'n');
        } else {
            cstr_ccat(cstr, '0' + ((c >> 6) & 7));
            cstr_ccat(cstr, '0' + ((c >> 3) & 7));
            cstr_ccat(cstr, '0' + (c & 7));
        }
    }
}

/* 03/08/2026 - TCC 0.9.24 */

/* Translate active raw multi-precision internal tokens back to descriptive human-readable strings */
char *get_tok_str(int v, CValue *cv)
{
    static char buf[STRING_MAX_SIZE + 1];
    static CString cstr_buf;
    CString *cstr;
    unsigned char *q;
    char *p;
    int i, len;

    /* Assign a permanent static translation stack frame to expedite micro-token processing loops */
    cstr_reset(&cstr_buf);
    cstr_buf.data = buf;
    cstr_buf.size_allocated = sizeof(buf);
    p = buf;

    switch(v) {
    case TOK_CINT:
    case TOK_CUINT:
        sprintf(p, "%u", cv->ui);
        break;
    case TOK_CLLONG:
    case TOK_CULLONG:
        sprintf(p, "%Lu", cv->ull);
        break;
    case TOK_CCHAR:
    case TOK_LCHAR:
        cstr_ccat(&cstr_buf, '\'');
        add_char(&cstr_buf, cv->i);
        cstr_ccat(&cstr_buf, '\'');
        cstr_ccat(&cstr_buf, '\0');
        break;
    case TOK_PPNUM:
        cstr = cv->cstr;
        len = cstr->size - 1;
        for(i = 0; i < len; i++)
            add_char(&cstr_buf, ((unsigned char *)cstr->data)[i]);
        cstr_ccat(&cstr_buf, '\0');
        break;
    case TOK_STR:
    case TOK_LSTR:
        cstr = cv->cstr;
        cstr_ccat(&cstr_buf, '\"');
        if (v == TOK_STR) {
            len = cstr->size - 1;
            for(i = 0; i < len; i++)
                add_char(&cstr_buf, ((unsigned char *)cstr->data)[i]);
        } else {
            len = (cstr->size / sizeof(int)) - 1;
            for(i = 0; i < len; i++)
                add_char(&cstr_buf, ((int *)cstr->data)[i]);
        }
        cstr_ccat(&cstr_buf, '\"');
        cstr_ccat(&cstr_buf, '\0');
        break;
    case TOK_LT:
        v = '<';
        goto addv;
    case TOK_GT:
        v = '>';
        goto addv;
    /* 03/08/2026 - TCC 0.9.24 */
    case TOK_DOTS:
        return strcpy(p, "...");
    /* .... */ 
    case TOK_A_SHL:
        return strcpy(p, "<<=");
    case TOK_A_SAR:
        return strcpy(p, ">>=");
    default:
        if (v < TOK_IDENT) {
            /* Map operational tokens directly using our twin-character lookup registry layout */
            q = tok_two_chars;
            while (*q) {
                if (q[2] == v) {
                    *p++ = q[0];
                    *p++ = q[1];
                    *p = '\0';
                    return buf;
                }
                q += 3;
            }
        addv:
            *p++ = v;
            *p = '\0';
        } else if (v < tok_ident) {
            return table_ident[v - TOK_IDENT]->str;
        } else if (v >= SYM_FIRST_ANOM) {
            /* Apply custom descriptive labeling for dynamically identified anonymous tracking symbols */
            sprintf(p, "L.%u", v - SYM_FIRST_ANOM);
        } else {
            return NULL;
        }
        break;
    }
    return cstr_buf.data;
}

/* Push a new raw symbol entry directly onto the target stack without hashing operations */
static Sym *sym_push2(Sym **ps, int v, int t, int c)
{
    Sym *s;
    s = tcc_malloc(sizeof(Sym));
    s->v = v;
    s->type.t = t;
    s->c = c;
    s->next = NULL;
    
    /* Enqueue directly into the active lexical stack */
    s->prev = *ps;
    *ps = s;
    return s;
}

/* Query the target symbol stack backward beginning from the specified top node frame */
static Sym *sym_find2(Sym *s, int v)
{
    while (s) {
        if (s->v == v)
            return s;
        s = s->prev;
    }
    return NULL;
}

/* Perform a rapid lookup for registered structure, union, or enum descriptor symbols */
static inline Sym *struct_find(int v)
{
    v -= TOK_IDENT;
    if ((unsigned)v >= (unsigned)(tok_ident - TOK_IDENT))
        return NULL;
    return table_ident[v]->sym_struct;
}

/* Perform a rapid lookup for a standard active identifier symbol */
static inline Sym *sym_find(int v)
{
    v -= TOK_IDENT;
    if ((unsigned)v >= (unsigned)(tok_ident - TOK_IDENT))
        return NULL;
    return table_ident[v]->sym_identifier;
}

/* Push a contextual token symbol structure onto either the local or global evaluation stack */
static Sym *sym_push(int v, CType *type, int r, int c)
{
    Sym *s, **ps;
    TokenSym *ts;

    if (local_stack)
        ps = &local_stack;
    else
        ps = &global_stack;
        
    s = sym_push2(ps, v, type->t, c);
    s->type.ref = type->ref;
    s->r = r;
    
    /* Ignore field descriptors and anonymous tracking structures during lookup registration */
    if (!(v & SYM_FIELD) && (v & ~SYM_STRUCT) < SYM_FIRST_ANOM) {
        /* Record the symbol cross-reference directly into the global token array map */
        ts = table_ident[(v & ~SYM_STRUCT) - TOK_IDENT];
        if (v & SYM_STRUCT)
            ps = &ts->sym_struct;
        else
            ps = &ts->sym_identifier;
        s->prev_tok = *ps;
        *ps = s;
    }
    return s;
}

/* Push a persistent identifier entry directly into the permanent global stack space */
static Sym *global_identifier_push(int v, int t, int c)
{
    Sym *s, **ps;
    s = sym_push2(&global_stack, v, t, c);
    
    /* Filter out temporary anonymous symbols from global registration pipelines */
    if (v < SYM_FIRST_ANOM) {
        ps = &table_ident[v - TOK_IDENT]->sym_identifier;
        /* Route deep into the link chain to hook beneath the active local layer contexts */
        while (*ps != NULL)
            ps = &(*ps)->prev_tok;
        s->prev_tok = NULL;
        *ps = s;
    }
    return s;
}

/* Pop and dismantle scope symbol frames sequentially until the designated boundary is reached */
static void sym_pop(Sym **ptop, Sym *b)
{
    Sym *s, *ss, **ps;
    TokenSym *ts;
    int v;

    s = *ptop;
    while (s != b) {
        ss = s->prev;
        v = s->v;
        
        /* Unbind structural dictionary references linked inside the global token array map */
        if (!(v & SYM_FIELD) && (v & ~SYM_STRUCT) < SYM_FIRST_ANOM) {
            ts = table_ident[(v & ~SYM_STRUCT) - TOK_IDENT];
            if (v & SYM_STRUCT)
                ps = &ts->sym_struct;
            else
                ps = &ts->sym_identifier;
            *ps = s->prev_tok;
        }
        tcc_free(s);
        s = ss;
    }
    *ptop = b;
}

/* I/O Layer and Native Source Filesystem Ingestion Engines */

/* Open a target source file and allocate its continuous input stream workspace tracking buffer */
BufferedFile *tcc_open(TCCState *s1, const char *filename)
{
    int fd;
    BufferedFile *bf;

    fd = open(filename, O_RDONLY);
    if (fd < 0)
        return NULL;
        
    bf = tcc_malloc(sizeof(BufferedFile));
    if (!bf) {
        close(fd);
        return NULL;
    }
    
    bf->fd = fd;
    bf->buf_ptr = bf->buffer;
    bf->buf_end = bf->buffer;
    bf->buffer[0] = CH_EOB; /* Inject the End-of-Buffer guard symbol instantly */
    pstrcpy(bf->filename, sizeof(bf->filename), filename);
    bf->line_num = 1;
    bf->ifndef_macro = 0;
    bf->ifdef_stack_ptr = s1->ifdef_stack_ptr;
    
    return bf;
}

/* Deallocate target source file tracking frame and close native filesystem descriptors */
void tcc_close(BufferedFile *bf)
{
    total_lines += bf->line_num;
    close(bf->fd);
    tcc_free(bf);
}

/* Refill physical input device hardware buffer blocks and peek at downstream characters */
static int tcc_peekc_slow(BufferedFile *bf)
{
    int len;
    
    /* Trigger raw hardware device stream reads only when the buffer threshold is fully depleted */
    if (bf->buf_ptr >= bf->buf_end) {
        if (bf->fd != -1) {
            len = IO_BUF_SIZE;
            len = read(bf->fd, bf->buffer, len);
            if (len < 0)
                len = 0;
        } else {
            len = 0;
        }
        total_bytes += len;
        bf->buf_ptr = bf->buffer;
        bf->buf_end = bf->buffer + len;
        *bf->buf_end = CH_EOB;
    }
    
    if (bf->buf_ptr < bf->buf_end) {
        return bf->buf_ptr[0];
    } else {
        bf->buf_ptr = bf->buf_end;
        return CH_EOF;
    }
}

/* Process and resolve the dynamic evaluation framework at structural End-of-Block milestones */
static int handle_eob(void)
{
    return tcc_peekc_slow(file);
}

/* Advance memory pipeline pointer reading the next live character mapping out buffer limits */
static inline void inp(void)
{
    ch = *(++(file->buf_ptr));
    /* Intercept buffer boundary limitations re-routing directly into high-fidelity I/O refill loops */
    if (ch == CH_EOB)
        ch = handle_eob();
}

/* 03/08/2026 - TCC 0.9.24 */
/* handle '\[\r]\n' */
static int handle_stray_noerror(void)
{
    while (ch == '\\') {
        inp();
        if (ch == '\n') {
            file->line_num++;
            inp();
        } else if (ch == '\r') {
            inp();
            if (ch != '\n')
                goto fail;
            file->line_num++;
            inp();
        } else {
        fail:
            return 1;
        }
    }
    return 0;
}

/* Resolve multi-line escape constraints handling unexpected stray character occurrences */
static void handle_stray(void)
{
    // while (ch == '\\') {
    //    inp();
    //    if (ch == '\n') {
    //        file->line_num++;
    //        inp();
    //    } else if (ch == '\r') {
    //        inp();
    //        if (ch != '\n')
    //            goto fail;
    //        file->line_num++;
    //        inp();
    //    } else {
    //    fail:
    /* 03/08/2026 - TCC 0.9.24 */
    if (handle_stray_noerror())
          error("stray '\\' in program");
    //    }
    // }
}

/* Parse complex escaped strings tracking multi-line boundary conditions gracefully */
static int handle_stray1(uint8_t *p)
{
    int c;

    if (p >= file->buf_end) {
        file->buf_ptr = p;
        c = handle_eob();
        p = file->buf_ptr;
        if (c == '\\')
            goto parse_stray;
    } else {
    parse_stray:
        file->buf_ptr = p;
        ch = *p;
        handle_stray();
        p = file->buf_ptr;
        c = *p;
    }
    return c;
}

/* Shorthand parsing macro resolving rapid End-of-Buffer evaluation frames safely */
#define PEEKC_EOB(c, p)\
{\
    p++;\
    c = *p;\
    if (c == '\\') {\
        file->buf_ptr = p;\
        c = handle_eob();\
        p = file->buf_ptr;\
    }\
}

/* Shorthand parsing macro resolving intricate preprocessor multi-line stray character connections */
#define PEEKC(c, p)\
{\
    p++;\
    c = *p;\
    if (c == '\\') {\
        c = handle_stray1(p);\
        p = file->buf_ptr;\
    }\
}

/* Core compilation parser advancement mechanism supporting explicit multi-line slash connectors */
static void minp(void)
{
    inp();
    if (ch == '\\') 
        handle_stray();
}

/* Standard single-line C++ style comment identifier stripping engine */
/* 03/08/2026 - TCC 0.9.24 */
/* single line C++ comments */
static uint8_t *parse_line_comment(uint8_t *p)
{
    int c;

    p++;
    for(;;) {
        c = *p;
    redo:
        if (c == '\n' || c == CH_EOF) {
            break;
        } else if (c == '\\') {
            file->buf_ptr = p;
            c = handle_eob();
            p = file->buf_ptr;
            if (c == '\\') {
                PEEKC_EOB(c, p);
                if (c == '\n') {
                    file->line_num++;
                    PEEKC_EOB(c, p);
                } else if (c == '\r') {
                    PEEKC_EOB(c, p);
                    if (c == '\n') {
                        file->line_num++;
                        PEEKC_EOB(c, p);
                    }
                }
            } else {
                goto redo;
            }
        } else {
            p++;
        }
    }
    return p;
}

/* Standard multi-line block C style comment identifier stripping engine */
static uint8_t *parse_comment(uint8_t *p)
{
    int c;
    
    p++;
    for(;;) {
        /* High-speed lexical skipping loop optimizing linear character sweeps */
        for(;;) {
            c = *p;
            if (c == '\n' || c == '*' || c == '\\')
                break;
            p++;
            c = *p;
            if (c == '\n' || c == '*' || c == '\\')
                break;
            p++;
        }
        
        /* Process discovered boundary termination or escape milestone flags */
        if (c == '\n') {
            file->line_num++;
            p++;
        } else if (c == '*') {
            p++;
            for(;;) {
                c = *p;
                if (c == '*') {
                    p++;
                } else if (c == '/') {
                    goto end_of_comment;
                } else if (c == '\\') {
                    file->buf_ptr = p;
                    c = handle_eob();
                    p = file->buf_ptr;
                    if (c == '\\') {
                        /* Process and resolve potential multi-line escape backslash sequences */
                        while (c == '\\') {
                            PEEKC_EOB(c, p);
                            if (c == '\n') {
                                file->line_num++;
                                PEEKC_EOB(c, p);
                            } else if (c == '\r') {
                                PEEKC_EOB(c, p);
                                if (c == '\n') {
                                    file->line_num++;
                                    PEEKC_EOB(c, p);
                                }
                            } else {
                                goto after_star;
                            }
                        }
                    }
                } else {
                    break;
                }
            }
        after_star: ;
        } else {
            /* Handle potential stray indicators, end-of-block, or terminal end-of-file milestones */
            file->buf_ptr = p;
            c = handle_eob();
            p = file->buf_ptr;
            if (c == CH_EOF) {
                error("unexpected end of file in comment");
            } else if (c == '\\') {
                p++;
            }
        }
    }
    
end_of_comment:
    p++;
    return p;
}

#define cinp minp

/* Evaluate character tokens verifying non-newline whitespace qualifications */
static inline int is_space(int ch)
{
    return ch == ' ' || ch == '\t' || ch == '\v' || ch == '\f' || ch == '\r';
}

/* Consume continuous linear sequences of space character tokens rapidly */
static inline void skip_spaces(void)
{
    while (is_space(ch))
        cinp();
}

/* Parse a raw string structure continuously without interpreting active internal escape definitions */
static uint8_t *parse_pp_string(uint8_t *p, int sep, CString *str)
{
    int c;
    p++;
    for(;;) {
        c = *p;
        if (c == sep) {
            break;
        } else if (c == '\\') {
            file->buf_ptr = p;
            c = handle_eob();
            p = file->buf_ptr;
            if (c == CH_EOF) {
            unterminated_string:
                error("missing terminating %c character", sep);
            } else if (c == '\\') {
                /* Escape handling: Safely bypass standard line-continuation backslash patterns */
                PEEKC_EOB(c, p);
                if (c == '\n') {
                    file->line_num++;
                    p++;
                } else if (c == '\r') {
                    PEEKC_EOB(c, p);
                    if (c != '\n')
                        expect("'\n' after '\r'");
                    file->line_num++;
                    p++;
                } else if (c == CH_EOF) {
                    goto unterminated_string;
                } else {
                    if (str) {
                        cstr_ccat(str, '\\');
                        cstr_ccat(str, c);
                    }
                    p++;
                }
            }
        } else if (c == '\n') {
            file->line_num++;
            goto add_char;
        } else if (c == '\r') {
            PEEKC_EOB(c, p);
            if (c != '\n') {
                cstr_ccat(str, '\r');
            } else {
                file->line_num++;
                goto add_char;
            }
        } else {
        add_char:
            if (str)
                cstr_ccat(str, c);
            p++;
        }
    }
    p++;
    return p;
}

/* skip block of text until #else, #elif or #endif. skip also pairs of #if/#endif */
/* 03/08/2026 - TCC 0.9.24 */
/* Preprocessor Skip Engine: Traverse and ignore inactive code blocks until valid else/elif/endif triggers appear */
void preprocess_skip(void)
{
    // int a, start_of_line, c;
    /* 03/08/2026 */
    int a, start_of_line, c, in_warn_or_error;
    uint8_t *p;

    p = file->buf_ptr;
    a = 0;
redo_start:
    start_of_line = 1;
    in_warn_or_error = 0;

    for(;;) {
    redo_no_start:
        c = *p;
        switch(c) {
        case ' ':
        case '\t':
        case '\f':
        case '\v':
        case '\r':
            p++;
            goto redo_no_start;
        case '\n':
            start_of_line = 1;
            file->line_num++;
            p++;
            // goto redo_no_start;
            goto redo_start;	/* 03/08/2026 */
        case '\\':
            file->buf_ptr = p;
            c = handle_eob();
            if (c == CH_EOF) {
                expect("#endif");
            } else if (c == '\\') {
                ch = file->buf_ptr[0];
                // handle_stray();
                /* 03/08/2026 */
                handle_stray_noerror();
            }
            p = file->buf_ptr;
            goto redo_no_start;

        /* Safely cross literal string configurations without parsing deep expressions */
        case '\"':
        case '\'':
            /* 03/08/2026 */
            if (in_warn_or_error)
                goto _default;
            /* .... */
            p = parse_pp_string(p, c, NULL);
            break;
            
        /* Strip out dead comment configurations safely during preprocessor sweeping loops */
        case '/':
            /* 03/08/2026 */
            if (in_warn_or_error)
                goto _default;
            /* .... */
            file->buf_ptr = p;
            ch = *p;
            minp();
            p = file->buf_ptr;
            if (ch == '*') {
                p = parse_comment(p);
            } else if (ch == '/') {
                p = parse_line_comment(p);
            }
            break;

        case '#':
            p++;
            if (start_of_line) {
                file->buf_ptr = p;
                next_nomacro();
                p = file->buf_ptr;
                if (a == 0 && (tok == TOK_ELSE || tok == TOK_ELIF || tok == TOK_ENDIF))
                    goto the_end;
                if (tok == TOK_IF || tok == TOK_IFDEF || tok == TOK_IFNDEF)
                    a++;
                else if (tok == TOK_ENDIF)
                    a--;
                /* 03/08/2026 */
                else if( tok == TOK_ERROR || tok == TOK_WARNING)
                    in_warn_or_error = 1;
                /* ..... */
            }
            break;
_default:
        default:
            p++;
            break;
        }
        start_of_line = 0;
    }
    
the_end: ;
    file->buf_ptr = p;
}

/* ParseState Handling and Lexical Context Snapshots */

/* Save the current active analytical parsing state into the target snapshot structure */
void save_parse_state(ParseState *s)
{
    s->line_num = file->line_num;
    s->macro_ptr = macro_ptr;
    s->tok = tok;
    s->tokc = tokc;
}

/* Restore the continuous compiler execution path from the specified state snapshot structure */
void restore_parse_state(ParseState *s)
{
    file->line_num = s->line_num;
    macro_ptr = s->macro_ptr;
    tok = s->tok;
    tokc = s->tokc;
}

/* Return the quantity of secondary 32-bit integer slots required to cache extended token structures */
static inline int tok_ext_size(int t)
{
    switch(t) {
    case TOK_CINT:
    case TOK_CUINT:
    case TOK_CCHAR:
    case TOK_LCHAR:
    case TOK_STR:
    case TOK_LSTR:
    case TOK_CFLOAT:
    case TOK_LINENUM:
    case TOK_PPNUM:
        return 1;
    case TOK_CDOUBLE:
    case TOK_CLLONG:
    case TOK_CULLONG:
        return 2;
    case TOK_CLDOUBLE:
        return 3; /* Fixed directly to 12 bytes / 4 for absolute native 32-bit x86 Flat layout */
    default:
        return 0;
    }
}

/* TokenString Structural Memory Framework */

/* Initialize a newly instantiated continuous token sequence recorder structure */
static inline void tok_str_new(TokenString *s)
{
    s->str = NULL;
    s->len = 0;
    s->allocated_len = 0;
    s->last_line_num = -1;
}

/* 03/08/2026 - TCC 0.9.24 */
static void tok_str_free(int *str)
{
    tcc_free(str);
}

/* 03/08/2026 - TCC 0.9.24 */
/* Expand the token string array memory allocation block to accommodate subsequent token input streams */
static int *tok_str_realloc(TokenString *s)
{
    int *str, len;

    /* 07/08/2026 */
    // len = s->allocated_len + TOK_STR_ALLOC_INCR;
    /* 03/08/2026 */
    if (s->allocated_len == 0) {
        len = 8;
    } else {
        len = s->allocated_len * 2;
    }
    /* ..... */

    str = tcc_realloc(s->str, len * sizeof(int));
    if (!str)
        error("memory full");
    s->allocated_len = len;
    s->str = str;
    return str;
}

/* Append a singular base lexical token directly to the end of the specified token string */
static void tok_str_add(TokenString *s, int t)
{
    int len, *str;

    len = s->len;
    str = s->str;
    if (len >= s->allocated_len)
        str = tok_str_realloc(s);
    str[len++] = t;
    s->len = len;
}

/* Append an extended token metadata structure along with its dynamic payload straight into the queue */
static void tok_str_add2(TokenString *s, int t, CValue *cv)
{
    int len, *str;

    len = s->len;
    str = s->str;

    /* Secure the maximum required execution boundary envelope before triggering memory resize routines */
    if (len + TOK_MAX_SIZE > s->allocated_len)
        str = tok_str_realloc(s);
    str[len++] = t;
    switch(t) {
    case TOK_CINT:
    case TOK_CUINT:
    case TOK_CCHAR:
    case TOK_LCHAR:
    case TOK_CFLOAT:
    case TOK_LINENUM:
        str[len++] = cv->tab[0];
        break;
    case TOK_PPNUM:
    case TOK_STR:
    case TOK_LSTR:
        /* 07/08/2026 */ 
        str[len++] = (int)cstr_dup(cv->cstr);
        break;
    case TOK_CDOUBLE:
    case TOK_CLLONG:
    case TOK_CULLONG:
        str[len++] = cv->tab[0];
        str[len++] = cv->tab[1];
        break;
    case TOK_CLDOUBLE:
        str[len++] = cv->tab[0];
        str[len++] = cv->tab[1];
        str[len++] = cv->tab[2]; /* Directly inject 12-byte layout parameters into execution slot fields */
        break;
    default:
        break;
    }
    s->len = len;
}

/* Append the active operational compiler parser token straight into the tracking sequence structure */
static void tok_str_add_tok(TokenString *s)
{
    CValue cval;

    /* Intercept tracking line updates injecting explicit line info structures upon modification boundaries */
    if (file->line_num != s->last_line_num) {
        s->last_line_num = file->line_num;
        cval.i = s->last_line_num;
        tok_str_add2(s, TOK_LINENUM, &cval);
    }
    tok_str_add2(s, tok, &tokc);
}

/* Fast layout mapping macro unpacking native 12-byte x86 FPU long double structures from memory fields */
#define LDOUBLE_GET(p, cv)                      \
        cv.tab[0] = p[0];                       \
        cv.tab[1] = p[1];                       \
        cv.tab[2] = p[2];

/* Get a token sequence from an integer cache array and advance the pointer index layout.
   Coded strictly as a macro sequence to guarantee complete bypass of pointer aliasing bugs. */
#define TOK_GET(t, p, cv)                       \
{                                               \
    t = *p++;                                   \
    switch(t) {                                 \
    case TOK_CINT:                              \
    case TOK_CUINT:                             \
    case TOK_CCHAR:                             \
    case TOK_LCHAR:                             \
    case TOK_CFLOAT:                            \
    case TOK_LINENUM:                           \
    case TOK_STR:                               \
    case TOK_LSTR:                              \
    case TOK_PPNUM:                             \
        cv.tab[0] = *p++;                       \
        break;                                  \
    case TOK_CDOUBLE:                           \
    case TOK_CLLONG:                            \
    case TOK_CULLONG:                           \
        cv.tab[0] = p[0];                       \
        cv.tab[1] = p[1];                       \
        p += 2;                                 \
        break;                                  \
    case TOK_CLDOUBLE:                          \
        LDOUBLE_GET(p, cv);                     \
        p += 3; /* Fixed directly to 12 bytes / 4 format for absolute 32-bit flat i386 FPU pipelines */ \
        break;                                  \
    default:                                    \
        break;                                  \
    }                                           \
}

/* Preprocessor Macro Directive (Define) Management Framework */

/* Inject a newly discovered preprocessor macro block structure onto the evaluation stack */
static inline void define_push(int v, int macro_type, int *str, Sym *first_arg)
{
    Sym *s;

    s = sym_push2(&define_stack, v, macro_type, (int)str);
    s->next = first_arg;
    table_ident[v - TOK_IDENT]->sym_define = s;
}

/* Neutralize and unregister an active macro configuration layout mapping by cutting the dictionary references */
static void define_undef(Sym *s)
{
    int v;
    v = s->v;
    if (v >= TOK_IDENT && v < tok_ident)
        table_ident[v - TOK_IDENT]->sym_define = NULL;
    s->v = 0;
}

/* Perform a rapid lookup query for a registered macro identifier descriptor */
static inline Sym *define_find(int v)
{
    v -= TOK_IDENT;
    if ((unsigned)v >= (unsigned)(tok_ident - TOK_IDENT))
        return NULL;
    return table_ident[v]->sym_define;
}

/* Purge and dismantle macro compilation stack scopes sequentially until the specified milestone boundary */
static void free_defines(Sym *b)
{
    Sym *top, *top1;
    int v;

    top = define_stack;
    while (top != b) {
        top1 = top->prev;
        /* Safeguard standard parameter arguments or hardcoded predefined descriptors from deletion loops */
        if (top->c)
            tok_str_free((int *)top->c);
        v = top->v;
        if (v >= TOK_IDENT && v < tok_ident)
            table_ident[v - TOK_IDENT]->sym_define = NULL;
        tcc_free(top);
        top = top1;
    }
    define_stack = b;
}

/* Branching Label Lookup and Structural Resolution Engines */

/* Perform a rapid lookup query for a standard branch destination label */
static Sym *label_find(int v)
{
    v -= TOK_IDENT;
    if ((unsigned)v >= (unsigned)(tok_ident - TOK_IDENT))
        return NULL;
    return table_ident[v]->sym_label;
}

/* Register and push a newly encountered branch jump destination label frame onto the tracker stack */
static Sym *label_push(Sym **ptop, int v, int flags)
{
    Sym *s, **ps;
    s = sym_push2(ptop, v, 0, 0);
    s->r = flags;
    ps = &table_ident[v - TOK_IDENT]->sym_label;
    if (ptop == &global_label_stack) {
        /* Route underneath local scopes to preserve visibility during global label evaluation traps */
        while (*ps != NULL)
            ps = &(*ps)->prev_tok;
    }
    s->prev_tok = *ps;
    *ps = s;
    return s;
}

/* Dismantle label stack chains and verify resolution constraints. Enforce static symbol binding on computed labels */
static void label_pop(Sym **ptop, Sym *slast)
{
    Sym *s, *s1;
    for(s = *ptop; s != slast; s = s1) {
        s1 = s->prev;
        if (s->r == LABEL_DECLARED) {
            warning("label '%s' declared but not used", get_tok_str(s->v, NULL));
        } else if (s->r == LABEL_FORWARD) {
            error("label '%s' used but not defined", get_tok_str(s->v, NULL));
        } else {
            if (s->c) {
                /* Target address translation: Bind computed labels straight to flat contiguous segment offsets */
                put_extern_sym(s, cur_text_section, (long)s->next, 1);
            }
        }
        /* Sever structural dictionary lookup connections and free storage resources */
        table_ident[s->v - TOK_IDENT]->sym_label = s->prev_tok;
        tcc_free(s);
    }
    *ptop = slast;
}

/* Preprocessor Directive Expression and Macro Parsing Engines */

/* Evaluate conditional expressions for preprocessor directives like #if and #elif */
static int expr_preprocess(void)
{
    int c, t;
    TokenString str;
    
    tok_str_new(&str);
    while (tok != TOK_LINEFEED && tok != TOK_EOF) {
        next(); /* Trigger automatic macro expansion loops */
        if (tok == TOK_DEFINED) {
            next_nomacro();
            t = tok;
            if (t == '(') 
                next_nomacro();
            c = define_find(tok) != 0;
            if (t == '(')
                next_nomacro();
            tok = TOK_CINT;
            tokc.i = c;
        } else if (tok >= TOK_IDENT) {
            /* Fallback strategy: Translate unmapped or undefined macros straight to absolute zero */
            tok = TOK_CINT;
            tokc.i = 0;
        }
        tok_str_add_tok(&str);
    }
    tok_str_add(&str, -1); /* Emulate absolute terminal end-of-file signal token */
    tok_str_add(&str, 0);
    
    /* Re-route execution context to evaluate standard C constant mathematical expressions */
    macro_ptr = str.str;
    next();
    c = expr_const();
    macro_ptr = NULL;
    tok_str_free(str.str);
    return c != 0;
}

/* Parse token sequences immediately following a newly detected #define preprocessor directive */
static void parse_define(void)
{
    Sym *s, *first, **ps;
    int v, t, varg, is_vaargs, c;
    TokenString str;

    v = tok;
    if (v < TOK_IDENT)
        error("invalid macro name '%s'", get_tok_str(tok, &tokc));

    first = NULL;
    t = MACRO_OBJ;

    /* Enforce strict ANSI standard: The open parenthesis '(' must directly follow the macro identifier */
    c = file->buf_ptr[0];
    if (c == '\\')
        c = handle_stray1(file->buf_ptr);

    if (c == '(') {
        next_nomacro();
        next_nomacro();
        ps = &first;
        while (tok != ')') {
            varg = tok;
            next_nomacro();
            is_vaargs = 0;

            if (varg == TOK_DOTS) {
                varg = TOK___VA_ARGS__;
                is_vaargs = 1;
            } else if (tok == TOK_DOTS && gnu_ext) {
                is_vaargs = 1;
                next_nomacro();
            }

            if (varg < TOK_IDENT)
                error("badly punctuated parameter list");

            s = sym_push2(&define_stack, varg | SYM_FIELD, is_vaargs, 0);
            *ps = s;
            ps = &s->next;

            if (tok != ',')
                break;
            next_nomacro();
        }
        t = MACRO_FUNC;
    }

    tok_str_new(&str);
    next_nomacro();

    /* Track token inputs continuously; EOF evaluation remains mandatory for command line -D payload injections */
    while (tok != TOK_LINEFEED && tok != TOK_EOF) {
        tok_str_add2(&str, tok, &tokc);
        next_nomacro();
    }
    tok_str_add(&str, 0);

    /* Safely register the newly synthesized macro parameters directly into the permanent identifier table */
    define_push(v, t, str.str, first);
}

//* Inclusion Header Cache and Filesystem Search Engines */

/* Query the registered cached include database to avoid redundant lookup cycles */
static CachedInclude *search_cached_include(TCCState *s1, int type, const char *filename)
{
    CachedInclude *e;
    int i;

    for(i = 0; i < s1->nb_cached_includes; i++) {
        e = s1->cached_includes[i];
        if (e->type == type && !strcmp(e->filename, filename))
            return e;
    }
    return NULL;
}

/* Register a newly discovered header path directly into the global inclusion cache tracker array */
static inline void add_cached_include(TCCState *s1, int type, const char *filename, int ifndef_macro)
{
    CachedInclude *e;

    /* Enforce strict single-registration rule to bypass duplicated memory overheads */
    if (search_cached_include(s1, type, filename))
        return;

    /* Allocate exact continuous memory slot matching the canonical layout filename length */
    e = tcc_malloc(sizeof(CachedInclude) + strlen(filename));
    if (!e)
        return;
        
    e->type = type;
    strcpy(e->filename, filename);
    e->ifndef_macro = ifndef_macro;
    
    dynarray_add((void ***)&s1->cached_includes, &s1->nb_cached_includes, e);
}

/* 03/08/2026 - TCC 0.9.24 (Modified) */

/* is_bof is true if first non space token at beginning of file */
static void preprocess(int is_bof)
{
    TCCState *s1 = tcc_state;
    int size, i, c, n, saved_parse_flags;
    char buf[1024], *q, *p;
    char buf1[1024];
    BufferedFile *f;
    Sym *s;
    CachedInclude *e;
    
    saved_parse_flags = parse_flags;
    parse_flags = PARSE_FLAG_PREPROCESS | PARSE_FLAG_TOK_NUM | PARSE_FLAG_LINEFEED;
    next_nomacro();
 redo:
    switch(tok) {
    case TOK_DEFINE:
        next_nomacro();
        parse_define();
        break;
    case TOK_UNDEF:
        next_nomacro();
        s = define_find(tok);
        /* Undefine symbol by resetting its link registry entry in table_ident */
        if (s)
            define_undef(s);
        break;
    case TOK_INCLUDE:
        ch = file->buf_ptr[0];
        skip_spaces();
        if (ch == '<') {
            c = '>';
            goto read_name;
        } else if (ch == '\"') {
            c = ch;
        read_name:
            // minp();
            // q = buf;
            // while (ch != c && ch != '\n' && ch != CH_EOF) {
            //     if ((q - buf) < sizeof(buf) - 1)
            //         *q++ = ch;
            //     minp();
            // }
            /* 03/08/2026 - TCC 0.9.24 */ 
            inp();
            q = buf;
            while (ch != c && ch != '\n' && ch != CH_EOF) {
                if ((q - buf) < sizeof(buf) - 1)
                    *q++ = ch;
                if (ch == '\\') {
                    if (handle_stray_noerror() == 0)
                        --q;
                } else
                    inp();
            }
            /* ...... */
            *q = '\0';
            minp();
        } else {
            /* Computed #include processing paths */
            next();
            buf[0] = '\0';
            if (tok == TOK_STR) {
                while (tok != TOK_LINEFEED) {
                    if (tok != TOK_STR) {
                    include_syntax:
                        error("'#include' expects \"FILENAME\" or <FILENAME>");
                    }
                    pstrcat(buf, sizeof(buf), (char *)tokc.cstr->data);
                    next();
                }
                c = '\"';
            } else {
                int len;
                while (tok != TOK_LINEFEED) {
                    pstrcat(buf, sizeof(buf), get_tok_str(tok, &tokc));
                    next();
                }
                len = strlen(buf);
                if (len < 2 || buf[0] != '<' || buf[len - 1] != '>')
                    goto include_syntax;
                memmove(buf, buf + 1, len - 2);
                buf[len - 2] = '\0';
                c = '>';
            }
        }

        e = search_cached_include(s1, c, buf);
        if (e && define_find(e->ifndef_macro)) {
            /* Bypass inclusion parsing loop entirely if the guard macro remains predefined */
            /* 03/08/2026 */
            /* no need to parse the include because the 'ifndef macro' is defined */
// #ifdef INC_DEBUG
//          printf("%s: skipping %s\n", file->filename, buf);
// #endif
        } else {
            if (c == '\"') {
                /* Traverse current source workspace directory path mapping for header files first */
                size = 0;
                p = strrchr(file->filename, '/');
                if (p) 
                    size = p + 1 - file->filename;
                if (size > sizeof(buf1) - 1)
                    size = sizeof(buf1) - 1;
                memcpy(buf1, file->filename, size);
                buf1[size] = '\0';
                pstrcat(buf1, sizeof(buf1), buf);
                f = tcc_open(s1, buf1);
                if (f)
                    goto found;
            }
            if (s1->include_stack_ptr >= s1->include_stack + INCLUDE_STACK_SIZE)
                error("#include recursion too deep");
            
            /* Scan configured standard paths for destination header files sequentially */
            n = s1->nb_include_paths + s1->nb_sysinclude_paths;
            for(i = 0; i < n; i++) {
                const char *path;
                if (i < s1->nb_include_paths)
                    path = s1->include_paths[i];
                else
                    path = s1->sysinclude_paths[i - s1->nb_include_paths];
                pstrcpy(buf1, sizeof(buf1), path);
                pstrcat(buf1, sizeof(buf1), "/");
                pstrcat(buf1, sizeof(buf1), buf);
                f = tcc_open(s1, buf1);
                if (f)
                    goto found;
            }
            error("include file '%s' not found", buf);
            // f = NULL;
            /* 03/08/2026 */
            break;
        found:
// #ifdef INC_DEBUG
//          printf("%s: including %s\n", file->filename, buf1);
// #endif
            f->inc_type = c;
            pstrcpy(f->inc_filename, sizeof(f->inc_filename), buf);
            
            /* Push active file frame snapshot context onto the preprocessor recursion file stack */
            *s1->include_stack_ptr++ = file;
            file = f;
            
            /* STABS debug emission engine code siphoned away to ensure strict runtime code minimalism */
            tok_flags |= TOK_FLAG_BOF | TOK_FLAG_BOL;
            ch = file->buf_ptr[0];
            goto the_end;
        }
        break;
    case TOK_IFNDEF:
        c = 1;
        goto do_ifdef;
    case TOK_IF:
        c = expr_preprocess();
        goto do_if;
    case TOK_IFDEF:
        c = 0;
    do_ifdef:
        next_nomacro();
        if (tok < TOK_IDENT)
            error("invalid argument for '#if%sdef'", c ? "n" : "");
        if (is_bof) {
            if (c) {
                /* Include debugging logs stripped away to retain absolute core speed */
                file->ifndef_macro = tok;
            }
        }
        c = (define_find(tok) != 0) ^ c;
    do_if:
        if (s1->ifdef_stack_ptr >= s1->ifdef_stack + IFDEF_STACK_SIZE)
            error("memory full");
        *s1->ifdef_stack_ptr++ = c;
        goto test_skip;
    case TOK_ELSE:
        if (s1->ifdef_stack_ptr == s1->ifdef_stack)
            error("#else without matching #if");
        if (s1->ifdef_stack_ptr[-1] & 2)
            error("#else after #else");
        c = (s1->ifdef_stack_ptr[-1] ^= 3);
        goto test_skip;
    case TOK_ELIF:
        if (s1->ifdef_stack_ptr == s1->ifdef_stack)
            error("#elif without matching #if");
        c = s1->ifdef_stack_ptr[-1];
        if (c > 1)
            error("#elif after #else");
        
        /* Skip evaluation loop if the historical branch condition evaluates as true */
        if (c == 1)
            goto skip;
        c = expr_preprocess();
        s1->ifdef_stack_ptr[-1] = c;
    test_skip:
        if (!(c & 1)) {
        skip:
            preprocess_skip();
            is_bof = 0;
            goto redo;
        }
        break;
    case TOK_ENDIF:
        if (s1->ifdef_stack_ptr <= file->ifdef_stack_ptr)
            error("#endif without matching #if");
        s1->ifdef_stack_ptr--;
        /* '#ifndef macro' was at the start of file. Now we check if
           an '#endif' is exactly at the end of file */
        if (file->ifndef_macro &&
            s1->ifdef_stack_ptr == file->ifdef_stack_ptr) {
            file->ifndef_macro_saved = file->ifndef_macro;
            /* need to set to zero to avoid false matches if another
               #ifndef at middle of file */
            file->ifndef_macro = 0;
            while (tok != TOK_LINEFEED)
                next_nomacro();
            tok_flags |= TOK_FLAG_ENDIF;
            goto the_end;
        }
        break;
    case TOK_LINE:
        next();
        if (tok != TOK_CINT)
            error("#line");
        file->line_num = tokc.i - 1; /* The line number will be incremented after */
        next();
        if (tok != TOK_LINEFEED) {
            if (tok != TOK_STR)
                error("#line");
            pstrcpy(file->filename, sizeof(file->filename), (char *)tokc.cstr->data);
        }
        break;
    case TOK_ERROR:
    case TOK_WARNING:
        c = tok;
        ch = file->buf_ptr[0];
        skip_spaces();
        q = buf;
        while (ch != '\n' && ch != CH_EOF) {
           // if ((q - buf) < sizeof(buf) - 1)
           //     *q++ = ch;
           //  minp();
           /* 03/08/2026 - TCC 0.9.24 */
           if ((q - buf) < sizeof(buf) - 1)
               *q++ = ch;
           if (ch == '\\') {
               if (handle_stray_noerror() == 0)
                   --q;
           } else
               inp();
        }
        *q = '\0';
        if (c == TOK_ERROR)
            error("#error %s", buf);
        else
            warning("#warning %s", buf);
        break;
    case TOK_PRAGMA:
        /* Pragmas are safely bypassed and ignored under the TRDOS flat compilation paradigm */
        break;
    default:
        if (tok == TOK_LINEFEED || tok == '!' || tok == TOK_CINT) {
            /* '!' is ignored to allow C scripts. numbers are ignored to emulate cpp behaviour */
        } else {
            // error("invalid preprocessing directive #%s", get_tok_str(tok, &tokc));
            /* 03/08/2026 - TCC 0.9.24 */
            if (!(saved_parse_flags & PARSE_FLAG_ASM_COMMENTS))
                warning("Ignoring unknown preprocessing directive #%s", get_tok_str(tok, &tokc));
        }
        break;
    }
    /* ignore other preprocess commands or #! for C scripts */
    while (tok != TOK_LINEFEED)
        next_nomacro();
 the_end:
    parse_flags = saved_parse_flags;
}

//* Escape Sequence and Preprocessor Big Number Mathematical Utilities */

/* Parse and evaluate standard and extended literal escape sequences within string structures */
static void parse_escape_string(CString *outstr, const uint8_t *buf, int is_long)
{
    int c, n;
    const char *p;

    p = (const char *)buf;
    for(;;) {
        c = *p;
        if (c == '\0')
            break;
        if (c == '\\') {
            p++;
            c = *p;
            switch(c) {
            case '0': case '1': case '2': case '3':
            case '4': case '5': case '6': case '7':
                /* Parse at most three consecutive octal digit qualifiers */
                n = c - '0';
                p++;
                c = *p;
                if (isoct(c)) {
                    n = n * 8 + c - '0';
                    p++;
                    c = *p;
                    if (isoct(c)) {
                        n = n * 8 + c - '0';
                        p++;
                    }
                }
                c = n;
                goto add_char_nonext;
            case 'x':
                p++;
                n = 0;
                for(;;) {
                    c = *p;
                    if (c >= 'a' && c <= 'f')
                        c = c - 'a' + 10;
                    else if (c >= 'A' && c <= 'F')
                        c = c - 'A' + 10;
                    else if (isnum(c))
                        c = c - '0';
                    else
                        break;
                    n = n * 16 + c;
                    p++;
                }
                c = n;
                goto add_char_nonext;
            case 'a':
                c = '\a';
                break;
            case 'b':
                c = '\b';
                break;
            case 'f':
                c = '\f';
                break;
            case 'n':
                c = '\n';
                break;
            case 'r':
                c = '\r';
                break;
            case 't':
                c = '\t';
                break;
            case 'v':
                c = '\v';
                break;
            case 'e':
                if (!gnu_ext)
                    goto invalid_escape;
                c = 27; /* ASCII Escape code value character tracking assignment */
                break;
            case '\'':
            case '\"':
            case '\\': 
            case '?':
                break;
            default:
            invalid_escape:
                // error("invalid escaped char");
                /* 03/08/2026 - TCC 0.9.24 */
                if (c >= '!' && c <= '~')
                    warning("unknown escape sequence: \'\\%c\'", c);
                else
                    warning("unknown escape sequence: \'\\x%x\'", c);
                break;
            }
        }
        p++;
    add_char_nonext:
        if (!is_long)
            cstr_ccat(outstr, c);
        else
            cstr_wccat(outstr, c);
    }
    
    /* Inject structural trailing null terminator to lock string memory layout */
    if (!is_long)
        cstr_ccat(outstr, '\0');
    else
        cstr_wccat(outstr, '\0');
}

/* Enforce static 64-bit internal numerical allocation boundaries for preprocessor evaluation */
#define BN_SIZE 2

/* Big Number Shift Engine: bn = (bn << shift) | or_val to process broad integer token inputs */
void bn_lshift(unsigned int *bn, int shift, int or_val)
{
    int i;
    unsigned int v;
    for(i = 0; i < BN_SIZE; i++) {
        v = bn[i];
        bn[i] = (v << shift) | or_val;
        or_val = v >> (32 - shift);
    }
}

/* Wipe targeted multi-precision big number structures back to pure absolute zero states */
void bn_zero(unsigned int *bn)
{
    int i;
    for(i = 0; i < BN_SIZE; i++) {
        bn[i] = 0;
    }
}

/* Parse a number enclosed within a null-terminated string 'p' and load it directly into the active token storage */
void parse_number(const char *p)
{
    int b, t, shift, frac_bits, s, exp_val, ch;
    char *q;
    unsigned int bn[BN_SIZE];
    double d;

    /* Initialize core token buffer parsing workspace layout */
    q = token_buf;
    ch = *p++;
    t = ch;
    ch = *p++;
    *q++ = t;
    b = 10;
    
    if (t == '.') {
        goto float_frac_parse;
    } else if (t == '0') {
        if (ch == 'x' || ch == 'X') {
            q--;
            ch = *p++;
            b = 16;
        } else if (tcc_ext && (ch == 'b' || ch == 'B')) {
            q--;
            ch = *p++;
            b = 2;
        }
    }
    
    /* Process and load all valid numerical digit characters sequentially.
       Octal verification is deferred here to safely accommodate floating-point syntax constraints */
    while (1) {
        if (ch >= 'a' && ch <= 'f')
            t = ch - 'a' + 10;
        else if (ch >= 'A' && ch <= 'F')
            t = ch - 'A' + 10;
        else if (isnum(ch))
            t = ch - '0';
        else
            break;
            
        if (t >= b)
            break;
            
        if (q >= token_buf + STRING_MAX_SIZE) {
        num_too_long:
            error("number too long");
        }
        *q++ = ch;
        ch = *p++;
    }
    
    if (ch == '.' ||
        ((ch == 'e' || ch == 'E') && b == 10) ||
        ((ch == 'p' || ch == 'P') && (b == 16 || b == 2))) {
        if (b != 10) {
            /* Hand-crafted hexadecimal or binary floating-point evaluation motor.
               Enforced directly to override variant non-ISOC99 library interpretation anomalies safely */
            *q = '\0';
            if (b == 16)
                shift = 4;
            else 
                shift = 2;
                
            bn_zero(bn);
            q = token_buf;
            while (1) {
                t = *q++;
                if (t == '\0') {
                    break;
                } else if (t >= 'a') {
                    t = t - 'a' + 10;
                } else if (t >= 'A') {
                    t = t - 'A' + 10;
                } else {
                    t = t - '0';
                }
                bn_lshift(bn, shift, t);
            }
            frac_bits = 0;
            if (ch == '.') {
                ch = *p++;
                while (1) {
                    t = ch;
                    if (t >= 'a' && t <= 'f') {
                        t = t - 'a' + 10;
                    } else if (t >= 'A' && t <= 'F') {
                        t = t - 'A' + 10;
                    } else if (t >= '0' && t <= '9') {
                        t = t - '0';
                    } else {
                        break;
                    }
                    if (t >= b)
                        error("invalid digit");
                    bn_lshift(bn, shift, t);
                    frac_bits += shift;
                    ch = *p++;
                }
            }
            if (ch != 'p' && ch != 'P')
                expect("exponent");
            ch = *p++;
            s = 1;
            exp_val = 0;
            if (ch == '+') {
                ch = *p++;
            } else if (ch == '-') {
                s = -1;
                ch = *p++;
            }
            if (ch < '0' || ch > '9')
                expect("exponent digits");
            while (ch >= '0' && ch <= '9') {
                exp_val = exp_val * 10 + ch - '0';
                ch = *p++;
            }
            exp_val = exp_val * s;
            
            /* Construct the floating point value inside a standard double register block */
            d = (double)bn[1] * 4294967296.0 + (double)bn[0];
            d = ldexp(d, exp_val - frac_bits);
            t = toup(ch);
            if (t == 'F') {
                ch = *p++;
                tok = TOK_CFLOAT;
                tokc.f = (float)d;
            } else if (t == 'L') {
                ch = *p++;
                tok = TOK_CLDOUBLE;
                tokc.ld = (long double)d;
            } else {
                tok = TOK_CDOUBLE;
                tokc.d = d;
            }
        } else {
            /* Process decimal floating-point formatting patterns */
            if (ch == '.') {
                if (q >= token_buf + STRING_MAX_SIZE)
                    goto num_too_long;
                *q++ = ch;
                ch = *p++;
            float_frac_parse:
                while (ch >= '0' && ch <= '9') {
                    if (q >= token_buf + STRING_MAX_SIZE)
                        goto num_too_long;
                    *q++ = ch;
                    ch = *p++;
                }
            }
            if (ch == 'e' || ch == 'E') {
                if (q >= token_buf + STRING_MAX_SIZE)
                    goto num_too_long;
                *q++ = ch;
                ch = *p++;
                if (ch == '-' || ch == '+') {
                    if (q >= token_buf + STRING_MAX_SIZE)
                        goto num_too_long;
                    *q++ = ch;
                    ch = *p++;
                }
                if (ch < '0' || ch > '9')
                    expect("exponent digits");
                while (ch >= '0' && ch <= '9') {
                    if (q >= token_buf + STRING_MAX_SIZE)
                        goto num_too_long;
                    *q++ = ch;
                    ch = *p++;
                }
            }
            *q = '\0';
            t = toup(ch);
            errno = 0;
            if (t == 'F') {
                ch = *p++;
                tok = TOK_CFLOAT;
                tokc.f = strtof(token_buf, NULL);
            } else if (t == 'L') {
                ch = *p++;
                tok = TOK_CLDOUBLE;
                tokc.ld = strtold(token_buf, NULL);
            } else {
                tok = TOK_CDOUBLE;
                tokc.d = strtod(token_buf, NULL);
            }
        }
    } else {
        unsigned long long n, n1;
        int lcount, ucount;

        /* Evaluate and process raw integer numbers */
        *q = '\0';
        q = token_buf;
        if (b == 10 && *q == '0') {
            b = 8;
            q++;
        }
        n = 0;
        while(1) {
            t = *q++;
            if (t == '\0') {
                break;
            } else if (t >= 'a') {
                t = t - 'a' + 10;
            } else if (t >= 'A') {
                t = t - 'A' + 10;
            } else {
                t = t - '0';
                if (t >= b)
                    error("invalid digit");
            }
            n1 = n;
            n = n * b + t;
            
            /* Enforce hard verification checking for integer overflows */
            if (n < n1)
                error("integer constant overflow");
        }
        
        if ((n & 0xffffffff00000000LL) != 0) {
            if ((n >> 63) != 0)
                tok = TOK_CULLONG;
            else
                tok = TOK_CLLONG;
        } else if (n > 0x7fffffff) {
            tok = TOK_CUINT;
        } else {
            tok = TOK_CINT;
        }
        
        lcount = 0;
        ucount = 0;
        for(;;) {
            t = toup(ch);
            if (t == 'L') {
                if (lcount >= 2)
                    error("three 'l's in integer constant");
                lcount++;
                if (lcount == 2) {
                    if (tok == TOK_CINT)
                        tok = TOK_CLLONG;
                    else if (tok == TOK_CUINT)
                        tok = TOK_CULLONG;
                }
                ch = *p++;
            } else if (t == 'U') {
                if (ucount >= 1)
                    error("two 'u's in integer constant");
                ucount++;
                if (tok == TOK_CINT)
                    tok = TOK_CUINT;
                else if (tok == TOK_CLLONG)
                    tok = TOK_CULLONG;
                ch = *p++;
            } else {
                break;
            }
        }
        if (tok == TOK_CINT || tok == TOK_CUINT)
            tokc.ui = n;
        else
            tokc.ull = n;
    }
}

/* Macro engine designed to evaluate double-character tokens rapidly without pointer aliasing bugs */
#define PARSE2(c1, tok1, c2, tok2)              \
    case c1:                                    \
        PEEKC(c, p);                            \
        if (c == c2) {                          \
            p++;                                \
            tok = tok2;                         \
        } else {                                \
            tok = tok1;                         \
        }                                       \
        break;

/* 03/08/2026 - TCC 0.9.24 */

/* Return next token directly from the source pipeline without applying macro substitution */
static inline void next_nomacro1(void)
{
    int t, c, is_long;
    TokenSym *ts;
    uint8_t *p, *p1;
    unsigned int h;

    p = file->buf_ptr;
 redo_no_start:
    c = *p;
    switch(c) {
    case ' ':
    case '\t':
    case '\f':
    case '\v':
    case '\r':
        p++;
        goto redo_no_start;
        
    case '\\':
        /* Validate if the lookahead character indicates a strict structural End-of-Buffer boundary */
        if (p >= file->buf_end) {
            file->buf_ptr = p;
            handle_eob();
            p = file->buf_ptr;
            if (p >= file->buf_end)
                goto parse_eof;
            else
                goto redo_no_start;
        } else {
            file->buf_ptr = p;
            ch = *p;
            handle_stray();
            p = file->buf_ptr;
            goto redo_no_start;
        }
    parse_eof:
        {
            TCCState *s1 = tcc_state;
            // if (parse_flags & PARSE_FLAG_LINEFEED) {
            //    tok = TOK_LINEFEED;
            /* 03/08/2026 - TCC 0.9.24 */
            if ((parse_flags & PARSE_FLAG_LINEFEED)
                && !(tok_flags & TOK_FLAG_EOF)) {
                tok_flags |= TOK_FLAG_EOF;
                tok = TOK_LINEFEED;
                goto keep_tok_flags;           
            /* ...... */
            } else if (s1->include_stack_ptr == s1->include_stack ||
                       !(parse_flags & PARSE_FLAG_PREPROCESS)) {
                /* Terminal milestone reached: No active files remaining on include stack layout */
                tok = TOK_EOF;
            } else {
                /* 03/08/2026 - TCC 0.9.24 */
                tok_flags &= ~TOK_FLAG_EOF;
                /* pop include file */
                /* ...... */
                /* test if previous '#endif' was after a #ifdef at start of file */
                /* Restore historical file layout context from preprocessor stack frames */
                if (tok_flags & TOK_FLAG_ENDIF) {
                    add_cached_include(s1, file->inc_type, file->inc_filename,
                                       file->ifndef_macro_saved);
                }

                /* Standard STABS debug tracking trace code completely siphoned away to maintain core static minimalism */
                /* pop include stack */
                tcc_close(file);
                s1->include_stack_ptr--;
                file = *s1->include_stack_ptr;
                p = file->buf_ptr;
                goto redo_no_start;
            }
        }
        break;

    case '\n':
        // if (parse_flags & PARSE_FLAG_LINEFEED) {
        //    tok = TOK_LINEFEED;
        // } else {
        //    file->line_num++;
        //    tok_flags |= TOK_FLAG_BOL;
        //    p++;
        //    goto redo_no_start;
        // }
        // break;
        /* 03/08/2026 - TCC 0.9.24 */
        file->line_num++;
        tok_flags |= TOK_FLAG_BOL;
        p++;
        if (0 == (parse_flags & PARSE_FLAG_LINEFEED))
            goto redo_no_start;
        tok = TOK_LINEFEED;
        goto keep_tok_flags;

    case '#':
        PEEKC(c, p);
        if ((tok_flags & TOK_FLAG_BOL) && (parse_flags & PARSE_FLAG_PREPROCESS)) {
            file->buf_ptr = p;
            preprocess(tok_flags & TOK_FLAG_BOF);
            p = file->buf_ptr;
            goto redo_no_start;
        } else {
            if (c == '#') {
                p++;
                tok = TOK_TWOSHARPS;
            } else {
                // tok = '#';
                /* 03/08/2026 - TCC 0.9.24 */
                if (parse_flags & PARSE_FLAG_ASM_COMMENTS) {
                    p = parse_line_comment(p - 1);
                    goto redo_no_start;
                } else {
                    tok = '#';
                }
            }
        }
        break;

    case 'a': case 'b': case 'c': case 'd':
    case 'e': case 'f': case 'g': case 'h':
    case 'i': case 'j': case 'k': case 'l':
    case 'm': case 'n': case 'o': case 'p':
    case 'q': case 'r': case 's': case 't':
    case 'u': case 'v': case 'w': case 'x':
    case 'y': case 'z':
    case 'A': case 'B': case 'C': case 'D':
    case 'E': case 'F': case 'G': case 'H':
    case 'I': case 'J': case 'K': 
    case 'M': case 'N': case 'O': case 'P':
    case 'Q': case 'R': case 'S': case 'T':
    case 'U': case 'V': case 'W': case 'X':
    case 'Y': case 'Z': 
    case '_':
    parse_ident_fast:
        p1 = p;
        h = TOK_HASH_INIT;
        h = TOK_HASH_FUNC(h, c);
        p++;
        for(;;) {
            c = *p;
            if (!isidnum_table[c])
                break;
            h = TOK_HASH_FUNC(h, c);
            p++;
        }
        if (c != '\\') {
            TokenSym **pts;
            int len;

            /* Fast path: No stray backslash discovered, resolve tokens via quick continuous hash lookup */
            len = p - p1;
            h &= (TOK_HASH_SIZE - 1);
            pts = &hash_ident[h];
            for(;;) {
                ts = *pts;
                if (!ts)
                    break;
                if (ts->len == len && !memcmp(ts->str, p1, len))
                    goto token_found;
                pts = &(ts->hash_next);
            }
            ts = tok_alloc_new(pts, p1, len);
        token_found: ;
        } else {
            /* Slower path: Handle unexpected backslash stray alignments within identifier parsing stream */
            cstr_reset(&tokcstr);

            while (p1 < p) {
                cstr_ccat(&tokcstr, *p1);
                p1++;
            }
            p--;
            PEEKC(c, p);
        parse_ident_slow:
            while (isidnum_table[c]) {
                cstr_ccat(&tokcstr, c);
                PEEKC(c, p);
            }
            ts = tok_alloc(tokcstr.data, tokcstr.size);
        }
        tok = ts->tok;
        break;
    case 'L':
        // t = (int)p;
        /* 03/08/2026 */
        t = p[1];
        if (t != '\\' && t != '\'' && t != '\"') {
            /* Fall back straight into the fast path if 'L' represents a standard isolated variable identifier */
            goto parse_ident_fast;
        } else {
            PEEKC(c, p);
            if (c == '\'' || c == '\"') {
                is_long = 1;
                goto str_const;
            } else {
                cstr_reset(&tokcstr);
                cstr_ccat(&tokcstr, 'L');
                goto parse_ident_slow;
            }
        }
        break;
    case '0': case '1': case '2': case '3':
    case '4': case '5': case '6': case '7':
    case '8': case '9':

        cstr_reset(&tokcstr);
        /* Lexical rule: Beyond initial digit trigger, capture consecutive alphanumeric characters or decimals */
    parse_num:
        for(;;) {
            t = c;
            cstr_ccat(&tokcstr, c);
            PEEKC(c, p);
            if (!(isnum(c) || isid(c) || c == '.' ||
                  ((c == '+' || c == '-') && (t == 'e' || t == 'E' || t == 'p' || t == 'P'))))
                break;
        }
        /* Append standard structural string null terminator to secure the token cache buffer formatting */
        cstr_ccat(&tokcstr, '\0');
        tokc.cstr = &tokcstr;
        tok = TOK_PPNUM;
        break;
    case '.':
        /* Specialized dot validation to seamlessly differentiate operator bounds from decimal floating point seeds */
        PEEKC(c, p);
        if (isnum(c)) {
            cstr_reset(&tokcstr);
            cstr_ccat(&tokcstr, '.');
            goto parse_num;
        } else if (c == '.') {
            PEEKC(c, p);
            if (c != '.')
                expect("'.'");
            PEEKC(c, p);
            tok = TOK_DOTS; /* Resolve sequential ellipsis punctuation token (...) */
        } else {
            tok = '.';
        }
        break;
    case '\'':
    case '\"':
        is_long = 0;
    str_const:
        {
            CString str;
            int sep;

            sep = c;

            /* Parse and process the raw preprocessor string character array */
            cstr_new(&str);
            p = parse_pp_string(p, sep, &str);
            cstr_ccat(&str, '\0');
            
            /* Evaluate structural escape sequences directly into the core token destination frame */
            cstr_reset(&tokcstr);
            parse_escape_string(&tokcstr, str.data, is_long);
            cstr_free(&str);

            if (sep == '\'') {
                int char_size;
                if (!is_long)
                    char_size = 1;
                else
                    char_size = sizeof(int);
                if (tokcstr.size <= char_size)
                    error("empty character constant");
                if (tokcstr.size > 2 * char_size)
                    warning("multi-character character constant");
                if (!is_long) {
                    tokc.i = *(int8_t *)tokcstr.data;
                    tok = TOK_CCHAR;
                } else {
                    tokc.i = *(int *)tokcstr.data;
                    tok = TOK_LCHAR;
                }
            } else {
                tokc.cstr = &tokcstr;
                if (!is_long)
                    tok = TOK_STR;
                else
                    tok = TOK_LSTR;
            }
        }
        break;

    case '<':
        PEEKC(c, p);
        if (c == '=') {
            p++;
            tok = TOK_LE;
        } else if (c == '<') {
            PEEKC(c, p);
            if (c == '=') {
                p++;
                tok = TOK_A_SHL;
            } else {
                tok = TOK_SHL;
            }
        } else {
            tok = TOK_LT;
        }
        break;
        
    case '>':
        PEEKC(c, p);
        if (c == '=') {
            p++;
            tok = TOK_GE;
        } else if (c == '>') {
            PEEKC(c, p);
            if (c == '=') {
                p++;
                tok = TOK_A_SAR;
            } else {
                tok = TOK_SAR;
            }
        } else {
            tok = TOK_GT;
        }
        break;

    case '&':
        PEEKC(c, p);
        if (c == '&') {
            p++;
            tok = TOK_LAND;
        } else if (c == '=') {
            p++;
            tok = TOK_A_AND;
        } else {
            tok = '&';
        }
        break;
        
    case '|':
        PEEKC(c, p);
        if (c == '|') {
            p++;
            tok = TOK_LOR;
        } else if (c == '=') {
            p++;
            tok = TOK_A_OR;
        } else {
            tok = '|';
        }
        break;

    case '+':
        PEEKC(c, p);
        if (c == '+') {
            p++;
            tok = TOK_INC;
        } else if (c == '=') {
            p++;
            tok = TOK_A_ADD;
        } else {
            tok = '+';
        }
        break;

    case '-':
        PEEKC(c, p);
        if (c == '-') {
            p++;
            tok = TOK_DEC;
        } else if (c == '=') {
            p++;
            tok = TOK_A_SUB;
        } else if (c == '>') {
            p++;
            tok = TOK_ARROW;
        } else {
            tok = '-';
        }
        break;

    PARSE2('!', '!', '=', TOK_NE)
    PARSE2('=', '=', '=', TOK_EQ)
    PARSE2('*', '*', '=', TOK_A_MUL)
    PARSE2('%', '%', '=', TOK_A_MOD)
    PARSE2('^', '^', '=', TOK_A_XOR)
        
    case '/':
        PEEKC(c, p);
        if (c == '*') {
            p = parse_comment(p);
            goto redo_no_start;
        } else if (c == '/') {
            p = parse_line_comment(p);
            goto redo_no_start;
        } else if (c == '=') {
            p++;
            tok = TOK_A_DIV;
        } else {
            tok = '/';
        }
        break;
        
        /* simple tokens */
    case '(':
    case ')':
    case '[':
    case ']':
    case '{':
    case '}':
    case ',':
    case ';':
    case ':':
    case '?':
    case '~':
    case '$': /* only used in assembler */
    /* 03/08/2026 - TCC 0.9.24 */
    case '@': /* dito */
        tok = c;
        p++;
        break;
    default:
        error("unrecognized character \\x%02x", c);
        break;
    }
    tok_flags = 0;
    /* 03/08/2026 - TCC 0.9.24 */
keep_tok_flags:
    file->buf_ptr = p;
}

/* Return next token without macro substitution. Can read input layers directly from macro_ptr buffer */
static void next_nomacro(void)
{
    if (macro_ptr) {
    redo:
        tok = *macro_ptr;
        if (tok) {
            TOK_GET(tok, macro_ptr, tokc);
            if (tok == TOK_LINENUM) {
                file->line_num = tokc.i;
                goto redo;
            }
        }
    } else {
        next_nomacro1();
    }
}

/* Substitute parameter arguments in macro_str and return a newly allocated token string block */
static int *macro_arg_subst(Sym **nested_list, int *macro_str, Sym *args)
{
    int *st, last_tok, t, notfirst;
    Sym *s;
    CValue cval;
    TokenString str;
    CString cstr;

    tok_str_new(&str);
    last_tok = 0;
    while(1) {
        TOK_GET(t, macro_str, cval);
        if (!t)
            break;
            
        if (t == '#') {
            /* Execute preprocessor stringize operator (#) */
            TOK_GET(t, macro_str, cval);
            if (!t)
                break;
            s = sym_find2(args, t);
            if (s) {
                cstr_new(&cstr);
                st = (int *)s->c;
                notfirst = 0;
                while (*st) {
                    if (notfirst)
                        cstr_ccat(&cstr, ' ');
                    TOK_GET(t, st, cval);
                    cstr_cat(&cstr, get_tok_str(t, &cval));
                    notfirst = 1;
                }
                cstr_ccat(&cstr, '\0');
                
                /* Inject the stringized literal straight into the token emission queue */
                cval.cstr = &cstr;
                tok_str_add2(&str, TOK_STR, &cval);
                cstr_free(&cstr);
            } else {
                tok_str_add2(&str, t, &cval);
            }
        } else if (t >= TOK_IDENT) {
            s = sym_find2(args, t);
            if (s) {
                st = (int *)s->c;
                /* If '##' token pasting operator is adjacent, suppress immediate parameter substitution */
                if (*macro_str == TOK_TWOSHARPS || last_tok == TOK_TWOSHARPS) {
                    /* Special GNU C macro layout extension: '##' absorbs the preceding comma ',' if VA_ARGS is completely empty */
                    if (gnu_ext && s->type.t && last_tok == TOK_TWOSHARPS && str.len >= 2 && str.str[str.len - 2] == ',') {
                        if (*st == 0) {
                            /* Suppress both the loose comma and the trailing twin sharps operator safely */
                            str.len -= 2;
                        } else {
                            /* Strip out the structural twin sharps sequence and route straight into variable addition paths */
                            str.len--;
                            goto add_var;
                        }
                    } else {
                        int t1;
                    add_var:
                        for(;;) {
                            TOK_GET(t1, st, cval);
                            if (!t1)
                                break;
                            tok_str_add2(&str, t1, &cval);
                        }
                    }
                } else {
                    // macro_subst(&str, nested_list, st);
                    /* 03/08/2026 - TCC 0.9.24 */
                    macro_subst(&str, nested_list, st, NULL);
                }
            } else {
                tok_str_add(&str, t);
            }
        } else {
            tok_str_add2(&str, t, &cval);
        }
        last_tok = t;
    }
    tok_str_add(&str, 0);
    return str.str;
}

/* Static tracking array providing localized chronological markers for ANSI C standard macro expansion frames */
static char const ab_month_name[12][4] =
{
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
};

/* Do macro substitution of current token with macro 's' and add result to tok_str.
   Tracks 'nested_list' to eliminate infinite preprocessor recursion patterns.
   Returns non-zero value if no substitution needs to be executed */
// static int macro_subst_tok(TokenString *tok_str, Sym **nested_list, Sym *s)
/* 03/08/2026 - TCC 0.9.24 */
static int macro_subst_tok(TokenString *tok_str,
                           Sym **nested_list, Sym *s, struct macro_level **can_read_stream)
{
    Sym *args, *sa, *sa1;
    // int mstr_allocated, parlevel, *mstr, t;
    /* 03/08/2026 */
    int mstr_allocated, parlevel, *mstr, t, t1;
    TokenString str;
    char *cstrval;
    CValue cval;
    CString cstr;
    /* 03/08/2026 */
    char buf[32];
            
    /* Evaluate and process special native ANSI C standard built-in macro expansions */
    if (tok == TOK___LINE__) {
        // cval.i = file->line_num;
        // tok_str_add2(tok_str, TOK_CINT, &cval);
        /* 03/08/2026 - TCC 0.9.24 */
        snprintf(buf, sizeof(buf), "%d", file->line_num);
        cstrval = buf;
        t1 = TOK_PPNUM;
        goto add_cstr1;
    } else if (tok == TOK___FILE__) {
        cstrval = file->filename;
        goto add_cstr;
    } else if (tok == TOK___DATE__ || tok == TOK___TIME__) {
        time_t ti;
        struct tm *tm;
        /* 03/08/2026 */
        // char buf[64];

        time(&ti);
        tm = localtime(&ti);
        if (tok == TOK___DATE__) {
            snprintf(buf, sizeof(buf), "%s %2d %d", 
                     ab_month_name[tm->tm_mon], tm->tm_mday, tm->tm_year + 1900);
        } else {
            snprintf(buf, sizeof(buf), "%02d:%02d:%02d", 
                     tm->tm_hour, tm->tm_min, tm->tm_sec);
        }
        cstrval = buf;
    add_cstr:
        /* 03/08/2026 */
        t1 = TOK_STR;
    add_cstr1:
        cstr_new(&cstr);
        cstr_cat(&cstr, cstrval);
        cstr_ccat(&cstr, '\0');
        cval.cstr = &cstr;
        // tok_str_add2(tok_str, TOK_STR, &cval);
        /* 03/08/2026 */ 
        tok_str_add2(tok_str, t1, &cval);
        cstr_free(&cstr);
    } else {
        mstr = (int *)s->c;
        mstr_allocated = 0;
        if (s->type.t == MACRO_FUNC) {
            /* Peek downstream parameters to verify if the macro definition identifier is followed by an open parenthesis */
        redo:
            if (macro_ptr) {
                t = *macro_ptr;
                // if (t == 0) {
                /* End of current macro cache stream: Advance pointer directly to source file frame */
                //    macro_ptr = NULL;
                //    goto parse_stream;
                // }
                /* 03/08/2026 - TCC 0.9.24 */
                if (t == 0 && can_read_stream) {
                    /* end of macro stream: we must look at the token
                       after in the file */
                    struct macro_level *ml = *can_read_stream;
                    macro_ptr = NULL;
                    if (ml)
                    {
                        macro_ptr = ml->p;
                        ml->p = NULL;
                        *can_read_stream = ml -> prev;
                    }
                    goto redo;
                } 
            } else {
            // parse_stream:
                ch = file->buf_ptr[0];
                while (is_space(ch) || ch == '\n')
                    cinp();
                t = ch;
            }
            if (t != '(') /* Bypass macro expansion entirely if lookahead parameter is not an open parenthesis */
                return -1;
                    
            /* Parse functional macro argument lists */
            next_nomacro();
            next_nomacro();
            args = NULL;
            sa = s->next;
            
            for(;;) {
                /* Capture and handle direct empty structural function macro layouts '()' */
                if (!args && tok == ')')
                    break;
                if (!sa)
                    error("macro '%s' used with too many args", get_tok_str(s->v, 0));
                    
                tok_str_new(&str);
                parlevel = 0;
                
                /* Keep traversing parameters unless a closing boundary matching active parenthesis level is found */
                while ((parlevel > 0 || (tok != ')' && (tok != ',' || sa->type.t))) && tok != -1) {
                    if (tok == '(')
                        parlevel++;
                    else if (tok == ')')
                        parlevel--;
                    // tok_str_add2(&str, tok, &tokc);
                    /* 03/08/2026 - TCC 0.9.24 */
                    if (tok != TOK_LINEFEED)
                       tok_str_add2(&str, tok, &tokc);
                    next_nomacro();
                }
                tok_str_add(&str, 0);
                sym_push2(&args, sa->v & ~SYM_FIELD, sa->type.t, (int)str.str);
                sa = sa->next;
                
                if (tok == ')') {
                    /* GNU C Macro expansion safety: Append an empty tracking variable argument if it is completely omitted */
                    if (sa && sa->type.t && gnu_ext)
                        continue;
                    else
                        break;
                }
                if (tok != ',')
                    expect(",");
                next_nomacro();
            }
            if (sa) {
                error("macro '%s' used with too few args", get_tok_str(s->v, 0));
            }

            /* Execute inner token substitution for each parsed argument sequence */
            mstr = macro_arg_subst(nested_list, mstr, args);
            
            /* Recycle allocated temporary tracking symbol memory blocks from heap structures */
            sa = args;
            while (sa) {
                sa1 = sa->prev;
                tok_str_free((int *)sa->c);
                // tcc_free(sa);
                /* 03/08/2026 - TCC 0.9.24 */
                sym_free(sa);
                sa = sa1;
            }
            mstr_allocated = 1;
        }
        
        /* Enqueue macro identifier into structural nested list before evaluating subsequent expansions */
        sym_push2(nested_list, s->v, 0, 0);
        // macro_subst(tok_str, nested_list, mstr);
        /* 03/08/2026 - TCC 0.9.24 */
        macro_subst(tok_str, nested_list, mstr, can_read_stream);
        
        /* Pop current macro context from the recursion safety list and free resources */
        sa1 = *nested_list;
        *nested_list = sa1->prev;
        // tcc_free(sa1);
        /* 03/08/2026 */
        sym_free(sa1);
        
        if (mstr_allocated)
            tok_str_free(mstr);
    }
    return 0;
}

/* Handle the token pasting '##' operator. Return NULL if no '##' sequence is encountered.
   Otherwise, return the newly synthesized combined token string block (which must be freed) */
static inline int *macro_twosharps(const int *macro_str)
{
    TokenSym *ts;
    const int *macro_ptr1, *start_macro_ptr, *ptr, *saved_macro_ptr;
    int t;
    const char *p1, *p2;
    CValue cval;
    TokenString macro_str1;
    CString cstr;

    start_macro_ptr = macro_str;
    
    /* Search sequentially to locate the first occurrence of the '##' operator */
    for(;;) {
        macro_ptr1 = macro_str;
        TOK_GET(t, macro_str, cval);
        /* Terminate pipeline immediately if the end of the macro string sequence is reached */
        if (t == 0)
            return NULL;
        if (*macro_str == TOK_TWOSHARPS)
            break;
    }

    /* Enforce advanced preprocessor concatenation sweeps to process discovered '##' operators */
    cstr_new(&cstr);
    tok_str_new(&macro_str1);
    tok = t;
    tokc = cval;

    /* Re-route and cache all standard lexical tokens discovered up to this milestone boundary */
    for(ptr = start_macro_ptr; ptr < macro_ptr1;) {
        TOK_GET(t, ptr, cval);
        tok_str_add2(&macro_str1, t, &cval);
    }
    saved_macro_ptr = macro_ptr;
    
    macro_ptr = (int *)macro_str;
    for(;;) {
        while (*macro_ptr == TOK_TWOSHARPS) {
            macro_ptr++;
            macro_ptr1 = macro_ptr;
            t = *macro_ptr;
            if (t) {
                TOK_GET(t, macro_ptr, cval);
                /* Execute raw character concatenation if both components are valid identifiers or numbers */
                cstr_reset(&cstr);
                p1 = get_tok_str(tok, &tokc);
                cstr_cat(&cstr, p1);
                p2 = get_tok_str(t, &cval);
                cstr_cat(&cstr, p2);
                cstr_ccat(&cstr, '\0');
                
                if ((tok >= TOK_IDENT || tok == TOK_PPNUM) && (t >= TOK_IDENT || t == TOK_PPNUM)) {
                    if (tok == TOK_PPNUM) {
                        /* Map synthesized sequence directly into a preprogramming numeric token structure */
                        /* 03/08/2026 - TCC 0.9.24 */
                        // tokc.cstr = &cstr;
                        /* NOTE: no need to allocate because
                           tok_str_add2() does it */
                        cstr_reset(&tokcstr);
                        tokcstr = cstr;
                        cstr_new(&cstr);
                        tokc.cstr = &tokcstr;
                        /* ..... */
                    } else {
                        /* Perform strict validation parsing to assert the newly merged identifier complies with grammar rules */
                        if (t == TOK_PPNUM) {
                            const char *p;
                            int c;

                            p = p2;
                            for(;;) {
                                c = *p;
                                if (c == '\0')
                                    break;
                                p++;
                                if (!isnum(c) && !isid(c))
                                    goto error_pasting;
                            }
                        }
                        ts = tok_alloc(cstr.data, strlen(cstr.data));
                        tok = ts->tok; /* Forcefully override and mask the current operational token */
                    }
                } else {
                    const char *str = cstr.data;
                    const unsigned char *q;

                    /* Verify if the combined operational string matches a legitimate compound operator token */
                    if (!strcmp(str, ">>=")) {
                        tok = TOK_A_SAR;
                    } else if (!strcmp(str, "<<=")) {
                        tok = TOK_A_SHL;
                    } else if (strlen(str) == 2) {
                        /* Traverse the twin-character lookup layout map to resolve combined operator bindings */
                        q = tok_two_chars;
                        for(;;) {
                            if (!*q)
                                goto error_pasting;
                            if (q[0] == str[0] && q[1] == str[1])
                                break;
                            q += 3;
                        }
                        tok = q[2];
                    } else {
                    error_pasting:
                        /* Paste validation failure path: Isolate and cache token names to protect static internal printing buffers */
                        cstr_reset(&cstr);
                        p1 = get_tok_str(tok, &tokc);
                        cstr_cat(&cstr, p1);
                        cstr_ccat(&cstr, '\0');
                        p2 = get_tok_str(t, &cval);
                        warning("pasting \"%s\" and \"%s\" does not give a valid preprocessing token", cstr.data, p2);
                        
                        /* Fallback strategy: Add the mismatched tokens sequentially into the layout stream without merging them */
                        tok_str_add2(&macro_str1, tok, &tokc);
                        tok = t;
                        tokc = cval;
                    }
                }
            }
        }
        tok_str_add2(&macro_str1, tok, &tokc);
        next_nomacro();
        if (tok == 0)
            break;
    }
    macro_ptr = (int *)saved_macro_ptr;
    cstr_free(&cstr);
    tok_str_add(&macro_str1, 0);
    return macro_str1.str;
}

/* Do macro substitution of macro_str sequence and append the finalized result directly onto tok_str.
   Tracks 'nested_list' map layers internally to suppress infinite preprocessor recursive loops */
// static void macro_subst(TokenString *tok_str, Sym **nested_list, const int *macro_str)
/* 03/08/2026 - TCC 0.9.24 */
static void macro_subst(TokenString *tok_str, Sym **nested_list, 
                        const int *macro_str, struct macro_level ** can_read_stream)
{
    Sym *s;
    // int *saved_macro_ptr, *macro_str1;
    /* 03/08/2026 */
    int *macro_str1;
    const int *ptr;
    int t, ret;
    CValue cval;
    /* 03/08/2026 */
    struct macro_level ml;

    /* Execute primary analytical scan to resolve token pasting '##' operator constraints */
    ptr = macro_str;
    macro_str1 = macro_twosharps(ptr);
    if (macro_str1) 
        ptr = macro_str1;
        
    while (1) {
        /* Condition validation: ptr == NULL exclusively triggers when tokens flow out of 
           source filesystem streams during complex parametrizable macro function calls */
        if (ptr == NULL)
            break;
        TOK_GET(t, ptr, cval);
        if (t == 0)
            break;
            
        s = define_find(t);
        if (s != NULL) {
            /* If the discovered macro identifier matches an active parent layout context layer, suppress expansion */
            if (sym_find2(*nested_list, t))
                goto no_subst;
                
            // saved_macro_ptr = macro_ptr;
            /* 03/08/2026 */
            ml.p = macro_ptr;
            if (can_read_stream)
                ml.prev = *can_read_stream, *can_read_stream = &ml;
            /* ...... */
            macro_ptr = (int *)ptr;
            tok = t;
            // ret = macro_subst_tok(tok_str, nested_list, s);
            /* 03/08/2026 */
            ret = macro_subst_tok(tok_str, nested_list, s, can_read_stream);
            // ptr = (const int *)macro_ptr;
            /* 05/08/2026 */
            ptr = (int *)macro_ptr;
            // macro_ptr = saved_macro_ptr;
            /* 03/08/2026 */
            macro_ptr = ml.p;
            if (can_read_stream && *can_read_stream == &ml)
                *can_read_stream = ml.prev;
            /* ...... */
            if (ret != 0)
                goto no_subst;
        } else {
        no_subst:
            tok_str_add2(tok_str, t, &cval);
        }
    }
    if (macro_str1)
        tok_str_free(macro_str1);
}

/* 03/08/2026 - TCC 0.9.24 */
/* Master Pipeline Entry: Return the next live compilation C token applying complete macro substitution */
static void next(void)
{
    Sym *nested_list, *s;
    TokenString str;
    /* 03/08/2026 */
    struct macro_level *ml;

 redo:
    next_nomacro();
    if (!macro_ptr) {
        /* Evaluate and process identifier structures for potential macro expansion if reading straight from physical file streams */
        if (tok >= TOK_IDENT && (parse_flags & PARSE_FLAG_PREPROCESS)) {
            s = define_find(tok);
            if (s) {
                /* Target macro matched: Initialize local token serialization strings and attempt substitution */
                tok_str_new(&str);
                nested_list = NULL;
                // if (macro_subst_tok(&str, &nested_list, s) == 0) {
                /* 03/08/2026 */
                if (macro_subst_tok(&str, &nested_list, s, &ml) == 0) {
                    /* Substitution pipeline succeeded. Append string null block and shift execution routing indicators */
                    tok_str_add(&str, 0);
                    macro_ptr = str.str;
                    macro_ptr_allocated = str.str;
                    goto redo;
                }
            }
        }
    } else {
        if (tok == 0) {
            /* Handle terminal macro memory block boundaries or internal pushback buffer exhaustion milestones */
            if (unget_buffer_enabled) {
                macro_ptr = unget_saved_macro_ptr;
                unget_buffer_enabled = 0;
            } else {
                /* Purge expired dynamic macro sequence memory structures from heap layout */
                tok_str_free(macro_ptr_allocated);
                macro_ptr = NULL;
            }
            goto redo;
        }
    }
    
    /* Convert raw preprocessor digit sequences (TOK_PPNUM) into concrete native C numeric constant types */
    if (tok == TOK_PPNUM && (parse_flags & PARSE_FLAG_TOK_NUM)) {
        parse_number((char *)tokc.cstr->data);
    }
}

/* Push back the current live token structure onto the parser queue setting active token directly to 'last_tok' */
static inline void unget_tok(int last_tok)
{
    int i, n;
    int *q;
    
    unget_saved_macro_ptr = macro_ptr;
    unget_buffer_enabled = 1;
    q = unget_saved_buffer;
    macro_ptr = q;
    *q++ = tok;
    
    n = tok_ext_size(tok) - 1;
    for(i = 0; i < n; i++)
        *q++ = tokc.tab[i];
    *q = 0; /* Inject structural terminal string null block wrapper */
    tok = last_tok;
}

/* Simple hardware-aligned integer payload value swap utility wrapper */
void swap(int *p, int *q)
{
    int t;
    t = *p;
    *p = *q;
    *q = t;
}

/* Push a complete contextual value payload directly onto the primary compiler evaluation stack */
void vsetc(CType *type, int r, CValue *vc)
{
    int v;

    // if (vtop >= vstack + VSTACK_SIZE)
    /* 03/08/2026 - TCC 0.9.24 */ 
    if (vtop >= vstack + (VSTACK_SIZE - 1))
        error("memory full");
        
    /* Optimization barrier: Neutralize and resolve pending CPU comparison flags if downstream 
       instructions are requested, preventing complex register allocation conflicts */
    if (vtop >= vstack) {
        v = vtop->r & VT_VALMASK;
        if (v == VT_CMP || (v & ~1) == VT_JMP)
            gv(RC_INT);
    }
    
    vtop++;
    vtop->type = *type;
    vtop->r = r;
    vtop->r2 = VT_CONST;
    vtop->c = *vc;
}

/* Push a standard 32-bit native integer constant straight onto the evaluation stack */
void vpushi(int v)
{
    CValue cval;
    cval.i = v;
    vsetc(&int_type, VT_CONST, &cval);
}

/* Generate and register a newly synthesized static tracking symbol targeted at a specific flat section */
static Sym *get_sym_ref(CType *type, Section *sec, unsigned long offset, unsigned long size)
{
    int v;
    Sym *sym;

    v = anon_sym++;
    sym = global_identifier_push(v, type->t | VT_STATIC, 0);
    sym->type.ref = type->ref;
    sym->r = VT_CONST | VT_SYM;
    
    /* Enforce strict target binding directly through our arithmetically safe flat relocation registry */
    put_extern_sym(sym, sec, offset, size);
    return sym;
}

/* Push a section-relative offset reference by injecting a loose anonymous tracing symbol wrapper */
static void vpush_ref(CType *type, Section *sec, unsigned long offset, unsigned long size)
{
    CValue cval;

    cval.ul = 0;
    vsetc(type, VT_CONST | VT_SYM, &cval);
    vtop->sym = get_sym_ref(type, sec, offset, size);
}

/* Define or query a unique external global linkage symbol reference inside permanent context scopes */
static Sym *external_global_sym(int v, CType *type, int r)
{
    Sym *s;

    s = sym_find(v);
    if (!s) {
        /* Construct a forward reference allocation descriptor directly inside the permanent tables */
        s = global_identifier_push(v, type->t | VT_EXTERN, 0);
        s->type.ref = type->ref;
        s->r = r | VT_CONST | VT_SYM;
    }
    return s;
}

/* Define a localized or forward external lookup symbol ensuring strict validation checks */
static Sym *external_sym(int v, CType *type, int r)
{
    Sym *s;

    s = sym_find(v);
    if (!s) {
        /* Allocate a forward reference linkage map frame onto the semantic token sequence ystack */
        s = sym_push(v, type, r | VT_CONST | VT_SYM, 0);
        s->type.t |= VT_EXTERN;
    } else {
        if (!is_compatible_types(&s->type, type))
            error("incompatible types for redefinition of '%s'", get_tok_str(v, NULL));
    }
    return s;
}

/* Push an explicit memory layout reference pointing to an external global symbol descriptor */
static void vpush_global_sym(CType *type, int v)
{
    Sym *sym;
    CValue cval;

    sym = external_global_sym(v, type, 0);
    cval.ul = 0;
    vsetc(type, VT_CONST | VT_SYM, &cval);
    vtop->sym = sym;
}

/* Wrapper tracking standard type registrations pushing arbitrary register properties into vsetc */
void vset(CType *type, int r, int v)
{
    CValue cval;

    cval.i = v;
    vsetc(type, r, &cval);
}

/* Shorthand abstraction pushing a standardized 32-bit native integer structure rapidly */
void vseti(int r, int v)
{
    CType type;
    type.t = VT_INT;
    vset(&type, r, v);
}

/* Transpose the top two operational slots on the evaluation stack layout precisely */
void vswap(void)
{
    SValue tmp;

    tmp = vtop[0];
    vtop[0] = vtop[-1];
    vtop[-1] = tmp;
}

/* Secure copy an external evaluation block and advance the stack tracking register pointer */
void vpushv(SValue *v)
{
    // if (vtop >= vstack + VSTACK_SIZE)
    /* 03/08/2026 - TCC 0.9.24 */
    if (vtop >= vstack + (VSTACK_SIZE - 1))
        error("memory full");
    vtop++;
    *vtop = *v;
}

/* Duplicate the current top slot entry layout on the evaluation stack */
void vdup(void)
{
    vpushv(vtop);
}

/* 03/08/2026 - TCC 0.9.24 */

/* Save register 'r' directly onto the memory stack frames and mark it as unallocated */
void save_reg(int r)
{
    int l, saved, size, align;
    SValue *p, sv;
    CType *type;

    /* Traverse and modify all tracked active execution evaluation stack contexts */
    saved = 0;
    l = 0;
    for(p = vstack; p <= vtop; p++) {
        // if ((p->r & VT_VALMASK) == r || (p->r2 & VT_VALMASK) == r) {
            /* Synchronize data state forcing register save parameters if not already executed */
        /* 03/08/2026 - TCC 0.9.24 */         
        if ((p->r & VT_VALMASK) == r ||
            ((p->type.t & VT_BTYPE) == VT_LLONG && (p->r2 & VT_VALMASK) == r)) {
            /* must save value on stack if not already done */
            if (!saved) {
                /* Reload targeted register because primary reference might match the auxiliary long long layout */
                r = p->r & VT_VALMASK;
                
                type = &p->type;
                if ((p->r & VT_LVAL) || (!is_float(type->t) && (type->t & VT_BTYPE) != VT_LLONG))
                    type = &int_type;
                    
                size = type_size(type, &align);
                loc = (loc - size) & -align;
                sv.type.t = type->t;
                sv.r = VT_LOCAL | VT_LVAL;
                sv.c.ul = loc;
                store(r, &sv);

                /* Native Native TRDOS 386: Evacuate and pop the floating point top descriptor ST0 if cached */
                if (r == TREG_ST0) {
                    o(0xd9dd); /* fstp %st(1) execution machine opcode insertion */
                }

                /* Resolve structural 64-bit multi-precision long long segments sequentially */
                if ((type->t & VT_BTYPE) == VT_LLONG) {
                    sv.c.ul += 4;
                    store(p->r2, &sv);
                }
                l = loc;
                saved = 1;
            }
            
            /* Recalibrate active evaluation index tags marking them as localized memory storage references */
            if (p->r & VT_LVAL) {
                /* Bounds verification masks cleanly purged to guarantee strict flat stack alignment metrics */
                p->r = (p->r & ~VT_VALMASK) | VT_LLOCAL;
            } else {
                p->r = lvalue_type(p->type.t) | VT_LOCAL;
            }
            p->r2 = VT_CONST;
            p->c.ul = l;
        }
    }
}

/* Query the hardware architecture to locate a free register matching target class constraints */
int get_reg(int rc)
{
    int r;
    SValue *p;

    /* Attempt to discover an unallocated hardware register frame */
    for(r = 0; r < NB_REGS; r++) {
        if (reg_classes[r] & rc) {
            for(p = vstack; p <= vtop; p++) {
                if ((p->r & VT_VALMASK) == r || (p->r2 & VT_VALMASK) == r)
                    goto notfound;
            }
            return r;
        }
    notfound: ;
    }
    
    /* Allocation fail path: Flush the oldest persistent register context down on the evaluation stack.
       Traversing sequentially from bottom to top prevents destruction of variables required by gen_opi() */
    for(p = vstack; p <= vtop; p++) {
        r = p->r & VT_VALMASK;
        if (r < VT_CONST && (reg_classes[r] & rc))
            goto save_found;
            
        r = p->r2 & VT_VALMASK;
        if (r < VT_CONST && (reg_classes[r] & rc)) {
        save_found:
            save_reg(r);
            return r;
        }
    }
    
    return -1;
}

/* Save and flush all active hardware registers up to the specified boundary stack depth */
void save_regs(int n)
{
    int r;
    SValue *p, *p1;
    p1 = vtop - n;
    for(p = vstack; p <= p1; p++) {
        r = p->r & VT_VALMASK;
        if (r < VT_CONST) {
            save_reg(r);
        }
    }
}

/* Move active values between registers flushing historical payload data out to prevent overwrite corruption */
void move_reg(int r, int s)
{
    SValue sv;

    if (r != s) {
        save_reg(r);
        sv.type.t = VT_INT;
        sv.r = s;
        sv.c.ul = 0;
        load(r, &sv);
    }
}

/* Get absolute memory address of vtop stack entry (vtop MUST BE an active lvalue context) */
void gaddrof(void)
{
    vtop->r &= ~VT_LVAL;
    /* Optimization path: If historical entry was a saved local variable, revert safely back to localized allocation */
    if ((vtop->r & VT_VALMASK) == VT_LLOCAL)
        vtop->r = (vtop->r & ~(VT_VALMASK | VT_LVAL_TYPE)) | VT_LOCAL | VT_LVAL;
}

/* Load vtop into a hardware processor register belonging to class 'rc'.
   Lvalues are dereferenced and converted directly into scalar or float register values. */
int gv(int rc)
{
    int r, r2, rc2, bit_pos, bit_size, size, align, i;
    unsigned long long ll;

    /* Handle C structure bitfield packing extractions directly via hardware shift instructions */
    if (vtop->type.t & VT_BITFIELD) {
        bit_pos = (vtop->type.t >> VT_STRUCT_SHIFT) & 0x3f;
        bit_size = (vtop->type.t >> (VT_STRUCT_SHIFT + 6)) & 0x3f;
        
        /* Strip out bitfield attributes to prevent infinite compiler optimization tracking loops */
        vtop->type.t &= ~(VT_BITFIELD | (-1 << VT_STRUCT_SHIFT));
        
        /* Generate analytical machine level bit shifts */
        vpushi(32 - (bit_pos + bit_size));
        gen_op(TOK_SHL);
        vpushi(32 - bit_size);
        gen_op(TOK_SAR); /* Evaluated and automatically masked as SHR if unsigned */
        r = gv(rc);
    } else {
        if (is_float(vtop->type.t) && (vtop->r & (VT_VALMASK | VT_LVAL)) == VT_CONST) {
            Sym *sym;
            int *ptr;
            unsigned long offset;
            
            /* Native x86 Floating Point optimization: Cache raw float constants straight into contiguous data segment */
            size = type_size(&vtop->type, &align);
            offset = (data_section->data_offset + align - 1) & -align;
            data_section->data_offset = offset;

            /* 03/08/2026- TCC 0.9.24 */
            /* XXX: not portable yet */
#ifdef __i386__
            /* Zero pad x87 tenbyte long doubles */
            if (size == 12)
                vtop->c.tab[2] &= 0xffff;
#endif
            /* ....... */
            
            ptr = section_ptr_add(data_section, size);
            size = size >> 2;
            for(i = 0; i < size; i++)
                ptr[i] = vtop->c.tab[i];
                
            sym = get_sym_ref(&vtop->type, data_section, offset, size << 2);
            vtop->r |= VT_LVAL | VT_SYM;
            vtop->sym = sym;
            vtop->c.ul = 0;
        }

        r = vtop->r & VT_VALMASK;
        
        /* Trigger direct register loading cycle if entry matches memory layout bounds, casts, or class mismatches */
        if (r >= VT_CONST || 
            (vtop->r & VT_LVAL) ||
            !(reg_classes[r] & rc) ||
            ((vtop->type.t & VT_BTYPE) == VT_LLONG && !(reg_classes[vtop->r2] & rc))) {
            
            r = get_reg(rc);
            if ((vtop->type.t & VT_BTYPE) == VT_LLONG) {
                /* Multi-precision 64-bit long long splitting: Disassemble data into twin 32-bit storage payloads */
                if ((vtop->r & (VT_VALMASK | VT_LVAL)) == VT_CONST) {
                    ll = vtop->c.ull;
                    vtop->c.ui = ll; /* Lower dword layout */
                    load(r, vtop);
                    vtop->r = r;
                    vpushi(ll >> 32); /* Upper dword layout */
                } else if (r >= VT_CONST || (vtop->r & VT_LVAL)) {
                    /* Execute direct double-register sequential loading sequence from memory descriptors */
                    load(r, vtop);
                    vdup();
                    vtop[-1].r = r;
                    vtop->type.t = VT_INT;
                    gaddrof();
                    vpushi(4);
                    gen_op('+');
                    vtop->r |= VT_LVAL;
                } else {
                    /* Safe physical data transfer across adjacent register maps */
                    load(r, vtop);
                    vdup();
                    vtop[-1].r = r;
                    vtop->r = vtop[-1].r2;
                }
                
                /* Target next available data processing general purpose integer register slot */
                rc2 = RC_INT;
                if (rc == RC_IRET)
                    rc2 = RC_LRET;
                r2 = get_reg(rc2);
                load(r2, vtop);
                vpop();
                vtop->r2 = r2;
            } else if ((vtop->r & VT_LVAL) && !is_float(vtop->type.t)) {
                int t1, t;
                /* Resolve scalar types checking layout sizes to guard against potential type truncation or extensions */
                t = vtop->type.t;
                t1 = t;
                
                if (vtop->r & VT_LVAL_BYTE)
                    t = VT_BYTE;
                else if (vtop->r & VT_LVAL_SHORT)
                    t = VT_SHORT;
                if (vtop->r & VT_LVAL_UNSIGNED)
                    t |= VT_UNSIGNED;
                    
                vtop->type.t = t;
                load(r, vtop);
                vtop->type.t = t1;
            } else {
                /* Execute standard isolated standard scalar or single-precision register data load loop */
                load(r, vtop);
            }
        }
        vtop->r = r;
    }
    return r;
}

/* Generate values for vtop[-1] and vtop[0] inside corresponding classes rc1 and rc2.
   Enforces strict resolution order for evaluation short-circuits like VT_JMP or VT_CMP. */
void gv2(int rc1, int rc2)
{
    int v;

    /* Prioritize the generation of generic registers first to prevent unexpected reload traps */
    v = vtop[0].r & VT_VALMASK;
    if (v != VT_CMP && (v & ~1) != VT_JMP && rc1 <= rc2) {
        vswap();
        gv(rc1);
        vswap();
        gv(rc2);
        /* Verify if the secondary tracking register requests an immediate reload sweep */
        if ((vtop[-1].r & VT_VALMASK) >= VT_CONST) {
            vswap();
            gv(rc1);
            vswap();
        }
    } else {
        gv(rc2);
        vswap();
        gv(rc1);
        vswap();
        /* Verify if the primary tracking register requests an immediate reload sweep */
        if ((vtop[0].r & VT_VALMASK) >= VT_CONST) {
            gv(rc2);
        }
    }
}

/* Expand a 64-bit multi-precision long long stack entry into twin 32-bit integer registers */
void lexpand(void)
{
    int u;

    u = vtop->type.t & VT_UNSIGNED;
    gv(RC_INT);
    vdup();
    vtop[0].r = vtop[-1].r2;
    vtop[0].r2 = VT_CONST;
    vtop[-1].r2 = VT_CONST;
    vtop[0].type.t = VT_INT | u;
    vtop[-1].type.t = VT_INT | u;
}

/* Synthesize a singular 64-bit long long structured value out of two standalone integer registers */
void lbuild(int t)
{
    gv2(RC_INT, RC_INT);
    vtop[-1].r2 = vtop[0].r;
    vtop[-1].type.t = t;
    vpop();
}

/* Rotate the designated 'n' quantity of initial evaluation stack entries straight to the bottom */
void vrotb(int n)
{
    int i;
    SValue tmp;

    tmp = vtop[-n + 1];
    for(i = -n + 1; i != 0; i++)
        vtop[i] = vtop[i + 1];
    vtop[0] = tmp;
}

/* 28/07/2026 - TCC 0.9.23 */
/* rotate n first stack elements to the top 
   I1 ... In -> In I1 ... I(n-1)  [top is right]
 */
void vrott(int n)
{
    int i;
    SValue tmp;

    tmp = vtop[0];
    for(i = 0;i < n - 1; i++)
        vtop[-i] = vtop[-i - 1];
    vtop[-n + 1] = tmp;
}

/* Pop the active top entry frame off the internal execution evaluation stack */
void vpop(void)
{
    int v;
    v = vtop->r & VT_VALMASK;

    /* Native TRDOS 386 x87 FPU specific: Enforce floating-point stack evacuation if not blocked */
    if (v == TREG_ST0 && !nocode_wanted) {
        o(0xd9dd); /* fstp %st(1) execution machine opcode insertion */
    } else if (v == VT_JMP || v == VT_JMPI) {
        /* Direct back-patching routing to finalize loose logical jumps (&& or ||) missing comparison tests */
        gsym(vtop->c.ul);
    }
    vtop--;
}

/* Force-convert the top stack frame entry into a register, duplicating its contents across an auxiliary register slot */
void gv_dup(void)
{
    int rc, t, r, r1;
    SValue sv;

    t = vtop->type.t;
    if ((t & VT_BTYPE) == VT_LLONG) {
        lexpand();
        gv_dup();
        vswap();
        vrotb(3);
        gv_dup();
        vrotb(4);
        /* Target internal layout sequence alignment: H L L1 H1 */
        lbuild(t);
        vrotb(3);
        vrotb(3);
        vswap();
        lbuild(t);
        vswap();
    } else {
        rc = RC_INT;
        sv.type.t = VT_INT;
        if (is_float(t)) {
            rc = RC_FLOAT;
            sv.type.t = t;
        }
        r = gv(rc);
        r1 = get_reg(rc);
        sv.r = r;
        sv.c.ul = 0;
        load(r1, &sv); /* Execute data transfer moving the payload from register 'r' straight into 'r1' */
        vdup();
        vtop->r = r1;
    }
}

/* 04/08/2026 - Google AI */
/* 64-bit bölme ve kalan fonksiyonları (libgcc alternatifleri) */
long long __divdi3(long long a, long long b) {
    if (b == 0) return 0; /* Sıfıra bölme hatasını önlemek için güvenli çıkış */
    return a / b;
}
long long __moddi3(long long a, long long b) {
    if (b == 0) return 0;
    return a % b;
}
/* ....... */

/* 28/07/2026 - TCC 0.9.23 */

/* Generate CPU independent 64-bit (unsigned) long long operations and semantic logic rules */
void gen_opl(int op)
{
    int t, a, b, op1, c, i;
    int func;
    /* 28/07/2026 */
    // GFuncContext gf;
    SValue tmp;

    switch(op) {
    case '/':
    case TOK_PDIV:
        func = TOK___divdi3;
        goto gen_func;
    case TOK_UDIV:
        func = TOK___udivdi3;
        goto gen_func;
    case '%':
        func = TOK___moddi3;
        goto gen_func;
    case TOK_UMOD:
        func = TOK___umoddi3;
    gen_func:
        /* Route and dispatch generic 64-bit long long math runtime library function call loops */
        /* 28/07/2026 */
        // gfunc_start(&gf, FUNC_CDECL);
        // gfunc_param(&gf);
        // gfunc_param(&gf);
        vpush_global_sym(&func_old_type, func);
        // gfunc_call(&gf);
        /* 28/07/2026 */
        vrott(3);
        gfunc_call(2);
        vpushi(0);
        vtop->r = REG_IRET;
        vtop->r2 = REG_LRET;
        break;
    case '^':
    case '&':
    case '|':
    case '*':
    case '+':
    case '-':
        t = vtop->type.t;
        vswap();
        lexpand();
        vrotb(3);
        lexpand();
        
        /* Evaluate target data sequence alignment frame: L1 H1 L2 H2 */
        tmp = vtop[0];
        vtop[0] = vtop[-3];
        vtop[-3] = tmp;
        tmp = vtop[-2];
        vtop[-2] = vtop[-3];
        vtop[-3] = tmp;
        vswap();
        
        /* Realized memory map layout sequence link: H1 H2 L1 L2 */
        if (op == '*') {
            vpushv(vtop - 1);
            vpushv(vtop - 1);
            gen_op(TOK_UMULL);
            lexpand();
            
            for(i = 0; i < 4; i++)
                vrotb(6);
                
            tmp = vtop[0];
            vtop[0] = vtop[-2];
            vtop[-2] = tmp;
            
            gen_op('*');
            vrotb(3);
            vrotb(3);
            gen_op('*');
            gen_op('+');
            gen_op('+');
        } else if (op == '+' || op == '-') {
            if (op == '+')
                op1 = TOK_ADDC1;
            else
                op1 = TOK_SUBC1;
            gen_op(op1);
            
            /* Target calculation map stack: H1 H2 (L1 op L2) */
            vrotb(3);
            vrotb(3);
            gen_op(op1 + 1); /* Execute sequential TOK_xxxC2 carry chain instructions */
        } else {
            gen_op(op);
            vrotb(3);
            vrotb(3);
            gen_op(op);
        }
        /* stack: L H */
        lbuild(t);
        break;
    case TOK_SAR:
    case TOK_SHR:
    case TOK_SHL:
        if ((vtop->r & (VT_VALMASK | VT_LVAL | VT_SYM)) == VT_CONST) {
            t = vtop[-1].type.t;
            vswap();
            lexpand();
            vrotb(3);
            
            /* Target instruction layout stack: L H shift */
            c = (int)vtop->c.i;
            vpop();
            if (op != TOK_SHL)
                vswap();

            if (c >= 32) {
                /* stack: L H */
                vpop();
                if (c > 32) {
                    vpushi(c - 32);
                    gen_op(op);
                }
                if (op != TOK_SAR) {
                    vpushi(0);
                } else {
                    gv_dup();
                    vpushi(31);
                    gen_op(TOK_SAR);
                }
                vswap();
            } else {
                vswap();
                gv_dup();
                /* stack: H L L */
                vpushi(c);
                gen_op(op);
                vswap();
                vpushi(32 - c);
                if (op == TOK_SHL)
                    gen_op(TOK_SHR);
                else
                    gen_op(TOK_SHL);
                vrotb(3);
                /* stack: L L H */
                vpushi(c);
                if (op == TOK_SHL)
                    gen_op(TOK_SHL);
                else
                    gen_op(TOK_SHR);
                gen_op('|');
            }
            if (op != TOK_SHL)
                vswap();
            lbuild(t);
        } else {
            /* Execute dynamic runtime shifting fallback routing targeting 64-bit libc library links */
            switch(op) {
            case TOK_SAR:
                func = TOK___sardi3;
                goto gen_func;
            case TOK_SHR:
                func = TOK___shrdi3;
                goto gen_func;
            case TOK_SHL:
                func = TOK___shldi3;
                goto gen_func;
            }
        }
        break;
    default:
        /* Evaluate and process 64-bit conditional comparison operations */
        t = vtop->type.t;
        vswap();
        lexpand();
        vrotb(3);
        lexpand();

        tmp = vtop[-1];
        vtop[-1] = vtop[-2];
        vtop[-2] = tmp;

        /* stack: L1 L2 H1 H2 */

        /* Invert and recalibrate logic boundaries when values evaluate as equal to handle low dword checks */
        op1 = op;
        if (op1 == TOK_LT)
            op1 = TOK_LE;
        else if (op1 == TOK_GT)
            op1 = TOK_GE;
        else if (op1 == TOK_ULT)
            op1 = TOK_ULE;
        else if (op1 == TOK_UGT)
            op1 = TOK_UGE;

        a = 0;
        b = 0;
        gen_op(op1);
        if (op1 != TOK_NE) {
            a = gtst(1, 0);
        }
        if (op != TOK_EQ) {
            if (a == 0) {
                b = gtst(0, 0);
            } else {
                /* Native TRDOS 386: Direct emission of the 0x850f machine instruction (JNZ/JNE conditional branch) */
                b = psym(0x850f, 0);
            }
        }

        /* Execute comparison on low dwords. This layout layer evaluates strictly as unsigned */
        op1 = op;
        if (op1 == TOK_LT)
            op1 = TOK_ULT;
        else if (op1 == TOK_LE)
            op1 = TOK_ULE;
        else if (op1 == TOK_GT)
            op1 = TOK_UGT;
        else if (op1 == TOK_GE)
            op1 = TOK_UGE;
            
        gen_op(op1);
        a = gtst(1, a);
        gsym(b);
        vseti(VT_JMPI, a);
        break;
    }
}

/* 07/08/2026 */
/* Handle compile-time integer constant optimizations and generic machine-independent evaluations */
void gen_opic(int op)
{
    int fc, c1, c2, n;
    SValue *v1, *v2;

    v1 = vtop - 1;
    v2 = vtop;
    
    /* Determine if adjacent evaluation slots qualify as strict compile-time constants */
    c1 = (v1->r & (VT_VALMASK | VT_LVAL | VT_SYM)) == VT_CONST;
    c2 = (v2->r & (VT_VALMASK | VT_LVAL | VT_SYM)) == VT_CONST;
    
    if (c1 && c2) {
        fc = v2->c.i;
        switch(op) {
        case '+': v1->c.i += fc; break;
        case '-': v1->c.i -= fc; break;
        case '&': v1->c.i &= fc; break;
        case '^': v1->c.i ^= fc; break;
        case '|': v1->c.i |= fc; break;
        case '*': v1->c.i *= fc; break;

        case TOK_PDIV:
        case '/':
        case '%':
        case TOK_UDIV:
        case TOK_UMOD:
            /* Raise strict diagnostic trap if a divide-by-zero anomaly is intercepted inside constants */
            if (fc == 0) {
                if (const_wanted)
                    error("division by zero in constant");
                goto general_case;
            }
            switch(op) {
            default: v1->c.i /= fc; break;
            case '%': v1->c.i %= fc; break;
            case TOK_UDIV: v1->c.i = (unsigned)v1->c.i / fc; break;
            case TOK_UMOD: v1->c.i = (unsigned)v1->c.i % fc; break;
            }
            break;
        case TOK_SHL: v1->c.i <<= fc; break;
        case TOK_SHR: v1->c.i = (unsigned)v1->c.i >> fc; break;
        case TOK_SAR: v1->c.i >>= fc; break;
        
        /* Direct binary relational evaluation katman tests */
        case TOK_ULT: v1->c.i = (unsigned)v1->c.i < (unsigned)fc; break;
        case TOK_UGE: v1->c.i = (unsigned)v1->c.i >= (unsigned)fc; break;
        case TOK_EQ: v1->c.i = v1->c.i == fc; break;
        case TOK_NE: v1->c.i = v1->c.i != fc; break;
        case TOK_ULE: v1->c.i = (unsigned)v1->c.i <= (unsigned)fc; break;
        case TOK_UGT: v1->c.i = (unsigned)v1->c.i > (unsigned)fc; break;
        case TOK_LT: v1->c.i = v1->c.i < fc; break;
        case TOK_GE: v1->c.i = v1->c.i >= fc; break;
        case TOK_LE: v1->c.i = v1->c.i <= fc; break;
        case TOK_GT: v1->c.i = v1->c.i > fc; break;
        
        /* Preprocessor shortcut logical checks */
        case TOK_LAND: v1->c.i = v1->c.i && fc; break;
        case TOK_LOR: v1->c.i = v1->c.i || fc; break;
        default:
            goto general_case;
        }
        vtop--;
    } else {
        /* Optimization sweep: If commutative operators are found, shift the constant payload to the second slot */
        if (c1 && (op == '+' || op == '&' || op == '^' || op == '|' || op == '*')) {
            vswap();
            swap(&c1, &c2);
        }
        fc = vtop->c.i;
        
        /* Apply mathematical shortcut identities to drop redundant instructions rapidly */
        if (c2 && (((op == '*' || op == '/' || op == TOK_UDIV || op == TOK_PDIV) && fc == 1) ||
                   ((op == '+' || op == '-' || op == '|' || op == '^' || 
                     op == TOK_SHL || op == TOK_SHR || op == TOK_SAR) && fc == 0) ||
                   (op == '&' && fc == -1))) {
            vtop--;
        } else if (c2 && (op == '*' || op == TOK_PDIV || op == TOK_UDIV)) {
            /* Transform expensive multiplications or divisions directly into high-efficiency bitwise hardware shifts */
            if (fc > 0 && (fc & (fc - 1)) == 0) {
                n = -1;
                while (fc) {
                    fc >>= 1;
                    n++;
                }
                vtop->c.i = n;
                if (op == '*')
                    op = TOK_SHL;
                else if (op == TOK_PDIV)
                    op = TOK_SAR;
                else
                    op = TOK_SHR;
            }
            goto general_case;
        } else if (c2 && (op == '+' || op == '-') &&
                   (vtop[-1].r & (VT_VALMASK | VT_LVAL | VT_SYM)) == (VT_CONST | VT_SYM)) {
            /* Optimization rule: Directly resolve structural symbol plus constant transformations */
            if (op == '-')
                fc = -fc;
            vtop--;
            vtop->c.i += fc;
        } else {
        general_case:
            if (!nocode_wanted) {
                /* Forward down directly into the low-level machine code instruction generator */
                gen_opi(op);
            } else {
                vtop--;
            }
        }
    }
}

/* Generate floating-point execution sequences applying strict ANSI compliant constant folding propagation */
void gen_opif(int op)
{
    int c1, c2;
    SValue *v1, *v2;
    long double f1, f2;

    v1 = vtop - 1;
    v2 = vtop;
    
    c1 = (v1->r & (VT_VALMASK | VT_LVAL | VT_SYM)) == VT_CONST;
    c2 = (v2->r & (VT_VALMASK | VT_LVAL | VT_SYM)) == VT_CONST;
    
    if (c1 && c2) {
        if (v1->type.t == VT_FLOAT) {
            f1 = v1->c.f;
            f2 = v2->c.f;
        } else if (v1->type.t == VT_DOUBLE) {
            f1 = v1->c.d;
            f2 = v2->c.d;
        } else {
            f1 = v1->c.ld;
            f2 = v2->c.ld;
        }

        /* ANSI C Compliance verification: Enforce runtime constant propagation exclusively on finite math limits */
        if (!ieee_finite(f1) || !ieee_finite(f2))
            goto general_case;

        switch(op) {
        case '+': f1 += f2; break;
        case '-': f1 -= f2; break;
        case '*': f1 *= f2; break;
        case '/': 
            if (f2 == 0.0) {
                if (const_wanted)
                    error("division by zero in constant");
                goto general_case;
            }
            f1 /= f2; 
            break;
        default:
            goto general_case;
        }
        
        if (v1->type.t == VT_FLOAT) {
            v1->c.f = f1;
        } else if (v1->type.t == VT_DOUBLE) {
            v1->c.d = f1;
        } else {
            v1->c.ld = f1;
        }
        vtop--;
    } else {
    general_case:
        if (!nocode_wanted) {
            gen_opf(op);
        } else {
            vtop--;
        }
    }
}

/* Extract and return the underlying physical allocation storage layout size pointed to by the active type structure */
static int pointed_size(CType *type)
{
    int align;
    return type_size(pointed_type(type), &align);
}

/* 28/07/2026 - TCC 0.9.23 */

static inline int is_null_pointer(SValue *p)
{
    if ((p->r & (VT_VALMASK | VT_LVAL | VT_SYM)) != VT_CONST)
        return 0;
    return ((p->type.t & VT_BTYPE) == VT_INT && p->c.i == 0) ||
        ((p->type.t & VT_BTYPE) == VT_LLONG && p->c.ll == 0);
}

static inline int is_integer_btype(int bt)
{
    return (bt == VT_BYTE || bt == VT_SHORT ||
            bt == VT_INT || bt == VT_LLONG);
}

/* 28/07/2026 - TCC 0.9.23 */

/* check types for comparison or substraction of pointers */
static void check_comparison_pointer_types(SValue *p1, SValue *p2, int op)
{
    CType *type1, *type2, tmp_type1, tmp_type2;
    int bt1, bt2;

    /* null pointers are accepted for all comparisons as gcc */
    if (is_null_pointer(p1) || is_null_pointer(p2))
        return;
    type1 = &p1->type;
    type2 = &p2->type;
    bt1 = type1->t & VT_BTYPE;
    bt2 = type2->t & VT_BTYPE;
    /* accept comparison between pointer and integer with a warning */
    if ((is_integer_btype(bt1) || is_integer_btype(bt2)) && op != '-') {
        if (op != TOK_LOR && op != TOK_LAND ) /* 03/08/2026 - TCC 0.9.24 */
            warning("comparison between pointer and integer");
        return;
    }

    /* both must be pointers or implicit function pointers */
    if (bt1 == VT_PTR) {
        type1 = pointed_type(type1);
    } else if (bt1 != VT_FUNC) 
        goto invalid_operands;

    if (bt2 == VT_PTR) {
        type2 = pointed_type(type2);
    } else if (bt2 != VT_FUNC) { 
    invalid_operands:
        error("invalid operands to binary %s", get_tok_str(op, NULL));
    }
    if ((type1->t & VT_BTYPE) == VT_VOID || 
        (type2->t & VT_BTYPE) == VT_VOID)
        return;
    tmp_type1 = *type1;
    tmp_type2 = *type2;
    tmp_type1.t &= ~(VT_UNSIGNED | VT_CONSTANT | VT_VOLATILE);
    tmp_type2.t &= ~(VT_UNSIGNED | VT_CONSTANT | VT_VOLATILE);
    if (!is_compatible_types(&tmp_type1, &tmp_type2)) {
        /* gcc-like error if '-' is used */
        if (op == '-')
            goto invalid_operands;
        else
            warning("comparison of distinct pointer types lacks a cast");
    }
}

/* 07/08/2026 */
/* 28/07/2026 - TCC 0.9.23 */

/* Generic binary operation engine: Evaluates language semantics and handles implicit type promotions */
void gen_op(int op)
{
    int u, t1, t2, bt1, bt2, t;
    CType type1;

    t1 = vtop[-1].type.t;
    t2 = vtop[0].type.t;
    bt1 = t1 & VT_BTYPE;
    bt2 = t2 & VT_BTYPE;

    if (bt1 == VT_PTR || bt2 == VT_PTR) {
        /* Evaluation path: At least one of the operational operands is an active pointer structure */
        if (op >= TOK_ULT && op <= TOK_GT) {
            /* Relational checks: Map cross-pointer comparison operands strictly as unsigned integers */
     
            /* 28/07/2026 - TCC 0.9.23 */
            check_comparison_pointer_types(vtop - 1, vtop, op);

            t = VT_INT | VT_UNSIGNED;
            goto std_op;
        }
        
        /* Direct check: If both elements evaluate as pointers, enforce the strict subtraction operation rule */
        if (bt1 == VT_PTR && bt2 == VT_PTR) {
            if (op != '-')
                error("cannot use pointers here");

            /* 28/07/2026 - TCC 0.9.23 */         
            check_comparison_pointer_types(vtop - 1, vtop, op);

            u = pointed_size(&vtop[-1].type);
            gen_opic(op);

            /* Enforce integer type destination masking pointer distance parameters */
            vtop->type.t = VT_INT; 
            vpushi(u);
            gen_op(TOK_PDIV);
        } else {
            /* Pointers arithmetic rule: Exactly one memory pointer requires addition (+) or subtraction (-) operators */
            if (op != '-' && op != '+')
                error("cannot use pointers here");
                
            /* Optimization shortcut: Forcefully swap operand layout so the pointer remains positioned first */
            if (bt2 == VT_PTR) {
                vswap();
                swap(&t1, &t2);
            }
            type1 = vtop[-1].type;
            
            /* Calculate array address scales by evaluating memory cell sizes sequentially */
            vpushi(pointed_size(&vtop[-1].type));
            gen_op('*');
            
            /* Runtime array bounds checking code safely stripped away to maintain absolute flat execution speed */
            gen_opic(op);
            
            /* Re-route and assert the original base pointer type metadata descriptors */
            vtop->type = type1;
        }
    } else if (is_float(bt1) || is_float(bt2)) {
        /* Target evaluation logic: Compute the highest precision format forcing implicit floating point casts */
        if (bt1 == VT_LDOUBLE || bt2 == VT_LDOUBLE) {
            t = VT_LDOUBLE;
        } else if (bt1 == VT_DOUBLE || bt2 == VT_DOUBLE) {
            t = VT_DOUBLE;
        } else {
            t = VT_FLOAT;
        }
        
        if (op != '+' && op != '-' && op != '*' && op != '/' && (op < TOK_ULT || op > TOK_GT))
            error("invalid operands for binary operation");
        goto std_op;
    } else if (bt1 == VT_LLONG || bt2 == VT_LLONG) {
        /* Promote type fields directly to match 64-bit multi-precision long long boundary frames */
        t = VT_LLONG;
        if ((t1 & (VT_BTYPE | VT_UNSIGNED)) == (VT_LLONG | VT_UNSIGNED) ||
            (t2 & (VT_BTYPE | VT_UNSIGNED)) == (VT_LLONG | VT_UNSIGNED))
            t |= VT_UNSIGNED;
        goto std_op;
    } else {
        /* Standard native 32-bit x86 Protected Mode flat integer calculations pipeline */
        t = VT_INT;
        if ((t1 & (VT_BTYPE | VT_UNSIGNED)) == (VT_INT | VT_UNSIGNED) ||
            (t2 & (VT_BTYPE | VT_UNSIGNED)) == (VT_INT | VT_UNSIGNED))
            t |= VT_UNSIGNED;
            
    std_op:
        /* Semantic map translation: Convert implicit signed expressions directly to low-level unsigned hardware configurations */
        if (t & VT_UNSIGNED) {
            if (op == TOK_SAR)
                op = TOK_SHR;
            else if (op == '/')
                op = TOK_UDIV;
            else if (op == '%')
                op = TOK_UMOD;
            else if (op == TOK_LT)
                op = TOK_ULT;
            else if (op == TOK_GT)
                op = TOK_UGT;
            else if (op == TOK_LE)
                op = TOK_ULE;
            else if (op == TOK_GE)
                op = TOK_UGE;
        }
        vswap();
        type1.t = t;
        gen_cast(&type1);
        vswap();
        
        /* Bitwise shift exception constraint: Retain shift operation magnitude values strictly as native integers */
        if (op == TOK_SHR || op == TOK_SAR || op == TOK_SHL)
            type1.t = VT_INT;
            
        gen_cast(&type1);
        if (is_float(t))
            gen_opif(op);
        else if ((t & VT_BTYPE) == VT_LLONG)
            gen_opl(op);
        else
            gen_opic(op);
            
        if (op >= TOK_ULT && op <= TOK_GT) {
            vtop->type.t = VT_INT; /* Enforce relational evaluation final outputs explicitly as integers (0 or 1) */
        } else {
            vtop->type.t = t;
        }
    }
}

/* 28/07/2026 - TCC 0.9.23 */

/* Generic integer to floating-point conversion wrapper optimized for 64-bit unsigned long long case */
void gen_cvt_itof1(int t)
{
    /* 28/07/2026 */
    // GFuncContext gf;

    if ((vtop->type.t & (VT_BTYPE | VT_UNSIGNED)) == (VT_LLONG | VT_UNSIGNED)) {
        /* Dispatch and route generic 64-bit runtime conversion function call loops */
        // gfunc_start(&gf, FUNC_CDECL);
        // gfunc_param(&gf);
        if (t == VT_FLOAT)
            vpush_global_sym(&func_old_type, TOK___ulltof);
        else if (t == VT_DOUBLE)
            vpush_global_sym(&func_old_type, TOK___ulltod);
        else
            vpush_global_sym(&func_old_type, TOK___ulltold);
        // gfunc_call(&gf);
        /* 28/07/2026 */
        vrott(2);
        gfunc_call(1);
        /* .... */
        vpushi(0);
        vtop->r = REG_FRET;
    } else {
        /* Fall back straight into the native x86 hardware FPU conversion engine */
        gen_cvt_itof(t);
    }
}

/* 28/07/2026 - TCC 0.9.23 */

/* Generic floating-point to integer conversion wrapper optimized for 64-bit unsigned long long case */
void gen_cvt_ftoi1(int t)
{
    /* 28/07/2026 */
    // GFuncContext gf;
    int st;

    if (t == (VT_LLONG | VT_UNSIGNED)) {
        /* Enforce software runtime library implementation fallback as x86 cannot process this natively */
        // gfunc_start(&gf, FUNC_CDECL);
        st = vtop->type.t & VT_BTYPE;
        // gfunc_param(&gf);
        if (st == VT_FLOAT)
            vpush_global_sym(&func_old_type, TOK___fixunssfdi);
        else if (st == VT_DOUBLE)
            vpush_global_sym(&func_old_type, TOK___fixunsdfdi);
        else
            vpush_global_sym(&func_old_type, TOK___fixunsxfdi);
        // gfunc_call(&gf);
        /* 28/07/2026 */
        vrott(2);
        gfunc_call(1);
        /* .... */
        vpushi(0);
        vtop->r = REG_IRET;
        vtop->r2 = REG_LRET;
    } else {
        /* Fall back straight into the native x86 hardware FPU truncation engine */
        gen_cvt_ftoi(t);
    }
}

/* Force explicit character (8-bit) or short integer (16-bit) conversion boundaries on evaluation stack */
void force_charshort_cast(int t)
{
    int bits, dbt;
    dbt = t & VT_BTYPE;
    
    if (dbt == VT_BYTE)
        bits = 8;
    else
        bits = 16;
        
    if (t & VT_UNSIGNED) {
        /* Execute zero-extension optimization by applying bitwise masking operation */
        vpushi((1 << bits) - 1);
        gen_op('&');
    } else {
        /* Execute sign-extension optimization via hardware arithmetic shift sequences */
        bits = 32 - bits;
        vpushi(bits);
        gen_op(TOK_SHL);
        /* 03/08/2026 - TCC 0.9.24 */
        /* result must be signed or the SAR is converted to an SHL
           This was not the case when "t" was a signed short
           and the last value on the stack was an unsigned int */
        vtop->type.t &= ~VT_UNSIGNED;
        /* .... */
        vpushi(bits);
        gen_op(TOK_SAR);
    }
}

/* 03/08/2026 - TCC 0.9.24 */

/* Execute compiler explicit or implicit type casting operations on the top stack entry vtop */
static void gen_cast(CType *type)
{
    int sbt, dbt, sf, df, c;

    /* Process delayed historical cast enforcement for narrow char or short variable storage */
    if (vtop->r & VT_MUSTCAST) {
        vtop->r &= ~VT_MUSTCAST;
        force_charshort_cast(vtop->type.t);
    }
    
    /* 03/08/2026 - TCC 0.9.24 */
    /* bitfields first get cast to ints */
    if (vtop->type.t & VT_BITFIELD) {
        gv(RC_INT);
    }
    /* ........ */

    dbt = type->t & (VT_BTYPE | VT_UNSIGNED);
    sbt = vtop->type.t & (VT_BTYPE | VT_UNSIGNED);

    if (sbt != dbt && !nocode_wanted) {
        sf = is_float(sbt);
        df = is_float(dbt);
        c = (vtop->r & (VT_VALMASK | VT_LVAL | VT_SYM)) == VT_CONST;
        
        if (sf && df) {
            /* Transform compile-time floating-point constants directly to target precision maps */
            if (c) {
                if (dbt == VT_FLOAT && sbt == VT_DOUBLE) 
                    vtop->c.f = (float)vtop->c.d;
                else if (dbt == VT_FLOAT && sbt == VT_LDOUBLE) 
                    vtop->c.f = (float)vtop->c.ld;
                else if (dbt == VT_DOUBLE && sbt == VT_FLOAT) 
                    vtop->c.d = (double)vtop->c.f;
                else if (dbt == VT_DOUBLE && sbt == VT_LDOUBLE) 
                    vtop->c.d = (double)vtop->c.ld;
                else if (dbt == VT_LDOUBLE && sbt == VT_FLOAT) 
                    vtop->c.ld = (long double)vtop->c.f;
                else if (dbt == VT_LDOUBLE && sbt == VT_DOUBLE) 
                    vtop->c.ld = (long double)vtop->c.d;
            } else {
                /* Generate low-level x87 hardware conversion opcodes for dynamic variables */
                gen_cvt_ftof(dbt);
            }
        } else if (df) {
            /* Execute mathematical conversion shifting scalar integer maps straight into floating-point targets */
            if (c) {
                switch(sbt) {
                case VT_LLONG | VT_UNSIGNED:
                case VT_LLONG:
                    goto do_itof;
                case VT_INT | VT_UNSIGNED:
                    switch(dbt) {
                    case VT_FLOAT: vtop->c.f = (float)vtop->c.ui; break;
                    case VT_DOUBLE: vtop->c.d = (double)vtop->c.ui; break;
                    case VT_LDOUBLE: vtop->c.ld = (long double)vtop->c.ui; break;
                    }
                    break;
                default:
                    switch(dbt) {
                    case VT_FLOAT: vtop->c.f = (float)vtop->c.i; break;
                    case VT_DOUBLE: vtop->c.d = (double)vtop->c.i; break;
                    case VT_LDOUBLE: vtop->c.ld = (long double)vtop->c.i; break;
                    }
                    break;
                }
            } else {
            do_itof:
                gen_cvt_itof1(dbt);
            }
        } else if (sf) {
            /* convert fp to int */
            if (dbt == VT_BOOL) {
                 vpushi(0);
                 gen_op(TOK_NE);
            } else {
                /* Execute mathematical truncation shifting floating-point maps straight into scalar integer targets */
                if (dbt != (VT_INT | VT_UNSIGNED) &&
                    dbt != (VT_LLONG | VT_UNSIGNED) &&
                    dbt != VT_LLONG)
                    dbt = VT_INT;
                if (c) {
                    switch(dbt) {
                    case VT_LLONG | VT_UNSIGNED:
                    case VT_LLONG:
                        /* XXX: add const cases for long long */
                        goto do_ftoi;
                    case VT_INT | VT_UNSIGNED:
                        switch(sbt) {
                        case VT_FLOAT: vtop->c.ui = (unsigned int)vtop->c.d; break;
                        case VT_DOUBLE: vtop->c.ui = (unsigned int)vtop->c.d; break;
                        case VT_LDOUBLE: vtop->c.ui = (unsigned int)vtop->c.d; break;
                        }
                        break;
                    default:
                        /* int case */
                        switch(sbt) {
                        case VT_FLOAT: vtop->c.i = (int)vtop->c.d; break;
                        case VT_DOUBLE: vtop->c.i = (int)vtop->c.d; break;
                        case VT_LDOUBLE: vtop->c.i = (int)vtop->c.d; break;
                        }
                        break;
                    }
                } else {
                do_ftoi:
                    gen_cvt_ftoi1(dbt);
                }
                if (dbt == VT_INT && (type->t & (VT_BTYPE | VT_UNSIGNED)) != dbt) {
                    /* Cascade subsequent narrow mask cast processing loops for char/short/bool types */
                    vtop->type.t = dbt;
                    gen_cast(type);
                }
            }
        } else if ((dbt & VT_BTYPE) == VT_LLONG) {
            if ((sbt & VT_BTYPE) != VT_LLONG) {
                /* Promote baseline scalar integers straight into 64-bit multi-precision long long structures */
                if (c) {
                    if (sbt == (VT_INT | VT_UNSIGNED))
                        vtop->c.ll = vtop->c.ui;
                    else
                        vtop->c.ll = vtop->c.i;
                } else {
                    /* machine independent conversion */
                    gv(RC_INT);
                    /* generate high word */
                    if (sbt == (VT_INT | VT_UNSIGNED)) {
                        vpushi(0);
                        gv(RC_INT);
                    } else {
                        gv_dup();
                        vpushi(31);
                        gen_op(TOK_SAR);
                    }
                    /* patch second register */
                    vtop[-1].r2 = vtop->r;
                    vpop();
                }
            }
        } else if (dbt == VT_BOOL) {
            /* scalar to bool */
            vpushi(0);
            gen_op(TOK_NE);
        } else if ((dbt & VT_BTYPE) == VT_BYTE || 
                   (dbt & VT_BTYPE) == VT_SHORT) {
            /* 03/08/2026 - TCC 0.9.24 */
            if (sbt == VT_PTR) {
                vtop->type.t = VT_INT;
                warning("nonportable conversion from pointer to char/short");
            }
            /* ..... */
            force_charshort_cast(dbt);
        } else if ((dbt & VT_BTYPE) == VT_INT) {
            /* scalar to int */
            if (sbt == VT_LLONG) {
                /* Truncate 64-bit long long structures dropping high order dword fields */
                lexpand();
                vpop();
            } 
            /* if lvalue and single word type, nothing to do because
               the lvalue already contains the real type size (see
               VT_LVAL_xxx constants) */
        }
    /* 03/08/2026 - TCC 0.9.24 */
    } else if ((dbt & VT_BTYPE) == VT_PTR && !(vtop->r & VT_LVAL)) {
        /* if we are casting between pointer types,
           we must update the VT_LVAL_xxx size */
        vtop->r = (vtop->r & ~VT_LVAL_TYPE)
                  | (lvalue_type(type->ref->type.t) & VT_LVAL_TYPE);
    }
    vtop->type = *type;
}

/* Calculate the explicit execution memory footprint size and assign the minimum hardware alignment pointer 'a' */
static int type_size(CType *type, int *a)
{
    Sym *s;
    int bt;

    bt = type->t & VT_BTYPE;
    if (bt == VT_STRUCT) {
        s = type->ref;
        *a = s->r;
        return s->c;
    } else if (bt == VT_PTR) {
        if (type->t & VT_ARRAY) {
            s = type->ref;
            return type_size(&s->type, a) * s->c;
        } else {
            *a = PTR_SIZE;
            return PTR_SIZE;
        }
    } else if (bt == VT_LDOUBLE) {
        *a = LDOUBLE_ALIGN;
        return LDOUBLE_SIZE; /* Constrained directly to native 12-byte layout for x87 FPU optimization maps */
    } else if (bt == VT_DOUBLE || bt == VT_LLONG) {
        *a = 4; /* Enforced straight to native 4-byte boundaries matching the TRDOS 386 x86 Protected Mode layout */
        return 8;
    } else if (bt == VT_INT || bt == VT_ENUM || bt == VT_FLOAT) {
        *a = 4;
        return 4;
    } else if (bt == VT_SHORT) {
        *a = 2;
        return 2;
    } else {
        *a = 1;
        return 1;
    }
}

/* Return the underlying pointed target type from a given pointer type descriptor */
static inline CType *pointed_type(CType *type)
{
    return &type->ref->type;
}

/* Modify the target type configuration converting its layout definition into an explicit pointer to type */
static void mk_pointer(CType *type)
{
    Sym *s;
    s = sym_push(SYM_FIELD, type, 0, -1);
    type->t = VT_PTR | (type->t & ~VT_TYPE);
    type->ref = s;
}

/* 03/08/2026 - TCC 0.9.24 */
/* 28/07/2026 - TCC 0.9.23 */ 

/* compare function types. OLD functions match any new functions */
static int is_compatible_func(CType *type1, CType *type2)
{
    Sym *s1, *s2;

    s1 = type1->ref;
    s2 = type2->ref;
    if (!is_compatible_types(&s1->type, &s2->type))
        return 0;
    /* check func_call */
    if (s1->r != s2->r)
        return 0;
    /* Legacy fallback: Support prototype overrides if historical K&R style parameters are cached */
    if (s1->c == FUNC_OLD || s2->c == FUNC_OLD)
        return 1;
    if (s1->c != s2->c)
        return 0;
    while (s1 != NULL) {
        if (s2 == NULL)
            return 0;
        // if (!is_compatible_types(&s1->type, &s2->type))
        /* 03/08/2026 - TCC 0.9.24 */
        if (!is_compatible_parameter_types(&s1->type, &s2->type))
            return 0;
        s1 = s1->next;
        s2 = s2->next;
    }
    if (s2)
        return 0;
    return 1;
}

/* 03/08/2026 - TCC 0.9.24 */
/* return true if type1 and type2 are the same.  If unqualified is
   true, qualifiers on the types are ignored.

   - enums are not checked as gcc __builtin_types_compatible_p () 
 */
static int compare_types(CType *type1, CType *type2, int unqualified)
{
    int bt1, t1, t2;

    t1 = type1->t & VT_TYPE;
    t2 = type2->t & VT_TYPE;
    if (unqualified) {
        /* strip qualifiers before comparing */
        t1 &= ~(VT_CONSTANT | VT_VOLATILE);
        t2 &= ~(VT_CONSTANT | VT_VOLATILE);
    }
    /* XXX: bitfields ? */
    if (t1 != t2)
        return 0;
    /* test more complicated cases */
    bt1 = t1 & VT_BTYPE;
    if (bt1 == VT_PTR) {
        type1 = pointed_type(type1);
        type2 = pointed_type(type2);
        return is_compatible_types(type1, type2);
    } else if (bt1 == VT_STRUCT) {
        return (type1->ref == type2->ref);
    } else if (bt1 == VT_FUNC) {
        return is_compatible_func(type1, type2);
    } else {
        return 1;
    }
}

/* 28/07/2026 - TCC 0.9.23 */ 
/* return true if type1 and type2 are exactly the same (including qualifiers).
   - enums are not checked as gcc __builtin_types_compatible_p ()
 */
// static int is_compatible_types(CType *type1, CType *type2)
// {
//    int bt1, t1, t2;
//
//    t1 = type1->t & VT_TYPE;
//    t2 = type2->t & VT_TYPE;
//    /* XXX: bitfields ? */
//    if (t1 != t2)
//        return 0;
//    /* test more complicated cases */
//    bt1 = t1 & VT_BTYPE;
//    if (bt1 == VT_PTR) {
//        type1 = pointed_type(type1);
//        type2 = pointed_type(type2);
//        return is_compatible_types(type1, type2);
//    } else if (bt1 == VT_STRUCT) {
//        return (type1->ref == type2->ref);
//    } else if (bt1 == VT_FUNC) {
//        return is_compatible_func(type1, type2);
//    } else {
//       return 1;
//    }
// }

/* 03/08/2026 - TCC 0.9.24 */
static int is_compatible_types(CType *type1, CType *type2)
{
    return compare_types(type1,type2,0);
}

/* 03/08/2026 - TCC 0.9.24 */
/* return true if type1 and type2 are the same (ignoring qualifiers).
*/
static int is_compatible_parameter_types(CType *type1, CType *type2)
{
    return compare_types(type1,type2,1);
}

/* 28/07/2026 - TCC 0.9.23 */
/* Print and format a structured C type descriptor straight into a human-readable destination buffer */
void type_to_str(char *buf, int buf_size, CType *type, const char *varstr)
{
    int bt, v, t;
    Sym *s, *sa;
    char buf1[256];
    const char *tstr;

    t = type->t & VT_TYPE;
    bt = t & VT_BTYPE;
    buf[0] = '\0';

    /* 28/07/2026 - TCC 0.9.23 */
    if (t & VT_CONSTANT)
        pstrcat(buf, buf_size, "const ");
    if (t & VT_VOLATILE)
        pstrcat(buf, buf_size, "volatile ");
    /* ... */    

    if (t & VT_UNSIGNED)
        pstrcat(buf, buf_size, "unsigned ");
        
    switch(bt) {
    case VT_VOID:
        tstr = "void";
        goto add_tstr;
    case VT_BOOL:
        tstr = "_Bool";
        goto add_tstr;
    case VT_BYTE:
        tstr = "char";
        goto add_tstr;
    case VT_SHORT:
        tstr = "short";
        goto add_tstr;
    case VT_INT:
        tstr = "int";
        goto add_tstr;
    case VT_LONG:
        tstr = "long";
        goto add_tstr;
    case VT_LLONG:
        tstr = "long long";
        goto add_tstr;
    case VT_FLOAT:
        tstr = "float";
        goto add_tstr;
    case VT_DOUBLE:
        tstr = "double";
        goto add_tstr;
    case VT_LDOUBLE:
        tstr = "long double";
    add_tstr:
        pstrcat(buf, buf_size, tstr);
        break;
    case VT_ENUM:
    case VT_STRUCT:
        if (bt == VT_STRUCT)
            tstr = "struct ";
        else
            tstr = "enum ";
        pstrcat(buf, buf_size, tstr);
        v = type->ref->v & ~SYM_STRUCT;
        if (v >= SYM_FIRST_ANOM)
            pstrcat(buf, buf_size, "<anonymous>");
        else
            pstrcat(buf, buf_size, get_tok_str(v, NULL));
        break;
    case VT_FUNC:
        s = type->ref;
        type_to_str(buf, buf_size, &s->type, varstr);
        pstrcat(buf, buf_size, "(");
        sa = s->next;
        while (sa != NULL) {
            type_to_str(buf1, sizeof(buf1), &sa->type, NULL);
            pstrcat(buf, buf_size, buf1);
            sa = sa->next;
            if (sa)
                pstrcat(buf, buf_size, ", ");
        }
        pstrcat(buf, buf_size, ")");
        goto no_var;
    case VT_PTR:
        s = type->ref;
        pstrcpy(buf1, sizeof(buf1), "*");
        if (varstr)
            pstrcat(buf1, sizeof(buf1), varstr);
        type_to_str(buf, buf_size, &s->type, buf1);
        goto no_var;
    }
    if (varstr) {
        pstrcat(buf, buf_size, " ");
        pstrcat(buf, buf_size, varstr);
    }
 no_var: ;
}

/* 28/07/2026 - TCC 0.9.23 */

/* Verify type compatibility to store vtop into 'dt' target type, injecting explicit casts if needed */
static void gen_assign_cast(CType *dt)
{
    CType *st, *type1, *type2, tmp_type1, tmp_type2;
    char buf1[256], buf2[256];
    int dbt, sbt;

    st = &vtop->type; /* source type */
    dbt = dt->t & VT_BTYPE;
    sbt = st->t & VT_BTYPE;
    if (dt->t & VT_CONSTANT)
        warning("assignment of read-only location");
    switch(dbt) {
    case VT_PTR:
        /* special cases for pointers */
        /* '0' can also be a pointer */
        if (is_null_pointer(vtop))
            goto type_ok;
        /* accept implicit pointer to integer cast with warning */
        if (is_integer_btype(sbt)) {
            warning("assignment makes pointer from integer without a cast");
            goto type_ok;
        }
        type1 = pointed_type(dt);
        /* a function is implicitely a function pointer */
        if (sbt == VT_FUNC) {
            if ((type1->t & VT_BTYPE) != VT_VOID &&
                !is_compatible_types(pointed_type(dt), st))
                goto error;
            else
                goto type_ok;
        }
        if (sbt != VT_PTR)
            goto error;
        type2 = pointed_type(st);
        if ((type1->t & VT_BTYPE) == VT_VOID || 
            (type2->t & VT_BTYPE) == VT_VOID) {
            /* void * can match anything */
        } else {
            /* exact type match, except for unsigned */
            tmp_type1 = *type1;
            tmp_type2 = *type2;
            tmp_type1.t &= ~(VT_UNSIGNED | VT_CONSTANT | VT_VOLATILE);
            tmp_type2.t &= ~(VT_UNSIGNED | VT_CONSTANT | VT_VOLATILE);
            if (!is_compatible_types(&tmp_type1, &tmp_type2))
                // goto error;
                /* 03/08/2026 - TCC 0.9.24 */
                warning("assignment from incompatible pointer type");
        }
        /* check const and volatile */
        if ((!(type1->t & VT_CONSTANT) && (type2->t & VT_CONSTANT)) ||
            (!(type1->t & VT_VOLATILE) && (type2->t & VT_VOLATILE)))
            warning("assignment discards qualifiers from pointer target type");
        break;
    case VT_BYTE:
    case VT_SHORT:
    case VT_INT:
    case VT_LLONG:
        if (sbt == VT_PTR || sbt == VT_FUNC) {
            warning("assignment makes integer from pointer without a cast");
        }
        /* XXX: more tests */
        break;
    case VT_STRUCT:
        tmp_type1 = *dt;
        tmp_type2 = *st;
        tmp_type1.t &= ~(VT_CONSTANT | VT_VOLATILE);
        tmp_type2.t &= ~(VT_CONSTANT | VT_VOLATILE);
        if (!is_compatible_types(&tmp_type1, &tmp_type2)) {
        error:
            type_to_str(buf1, sizeof(buf1), st, NULL);
            type_to_str(buf2, sizeof(buf2), dt, NULL);
            error("cannot cast '%s' to '%s'", buf1, buf2);
        }
        break;
    }
 type_ok:
    gen_cast(dt);
}

/* 28/07/2026 - TCC 0.9.23 */

/* store vtop in lvalue pushed on stack */
void vstore(void)
{
    int sbt, dbt, ft, r, t, size, align, bit_size, bit_pos, rc, delayed_cast;

    ft = vtop[-1].type.t;
    sbt = vtop->type.t & VT_BTYPE;
    dbt = ft & VT_BTYPE;
    if (((sbt == VT_INT || sbt == VT_SHORT) && dbt == VT_BYTE) ||
        (sbt == VT_INT && dbt == VT_SHORT)) {
        /* optimize char/short casts */
        delayed_cast = VT_MUSTCAST;
        vtop->type.t = ft & VT_TYPE;
        /* XXX: factorize */
        if (ft & VT_CONSTANT)
            warning("assignment of read-only location");
    } else {
        delayed_cast = 0;
        if (!(ft & VT_BITFIELD))
            gen_assign_cast(&vtop[-1].type);
    }

    if (sbt == VT_STRUCT) {
        /* if structure, only generate pointer */
        /* structure assignment : generate memcpy */
        /* XXX: optimize if small size */
        if (!nocode_wanted) {
            size = type_size(&vtop->type, &align);

            vpush_global_sym(&func_old_type, TOK_memcpy);

            /* destination */
            vpushv(vtop - 2);
            vtop->type.t = VT_INT;
            gaddrof();
            /* source */
            vpushv(vtop - 2);
            vtop->type.t = VT_INT;
            gaddrof();
            /* type size */
            vpushi(size);
            gfunc_call(3);
            
            vswap();
            vpop();
        } else {
            vswap();
            vpop();
        }
        /* leave source on stack */
    } else if (ft & VT_BITFIELD) {
        /* bitfield store handling */
        bit_pos = (ft >> VT_STRUCT_SHIFT) & 0x3f;
        bit_size = (ft >> (VT_STRUCT_SHIFT + 6)) & 0x3f;
        /* remove bit field info to avoid loops */
        vtop[-1].type.t = ft & ~(VT_BITFIELD | (-1 << VT_STRUCT_SHIFT));

        /* 03/08/2026 - TCC 0.9.24 */
        /* duplicate source into other register */
        gv_dup();
        vswap();
        vrott(3);
        /* .... */

        /* duplicate destination */
        vdup();
        vtop[-1] = vtop[-2];

        /* mask and shift source */
        vpushi((1 << bit_size) - 1);
        gen_op('&');
        vpushi(bit_pos);
        gen_op(TOK_SHL);
        /* load destination, mask and or with source */
        vswap();
        vpushi(~(((1 << bit_size) - 1) << bit_pos));
        gen_op('&');
        gen_op('|');
        /* store result */
        vstore();

        /* 03/08/2026 - TCC 0.9.24 */
        /* pop off shifted source from "duplicate source..." above */
        vpop();

    } else {
        if (!nocode_wanted) {
            rc = RC_INT;
            if (is_float(ft))
                rc = RC_FLOAT;
            r = gv(rc);  /* generate value */
            /* if lvalue was saved on stack, must read it */
            if ((vtop[-1].r & VT_VALMASK) == VT_LLOCAL) {
                SValue sv;
                t = get_reg(RC_INT);
                sv.type.t = VT_INT;
                sv.r = VT_LOCAL | VT_LVAL;
                sv.c.ul = vtop[-1].c.ul;
                load(t, &sv);
                vtop[-1].r = t | VT_LVAL;
            }
            store(r, vtop - 1);
            /* two word case handling : store second register at word + 4 */
            if ((ft & VT_BTYPE) == VT_LLONG) {
                vswap();
                /* convert to int to increment easily */
                vtop->type.t = VT_INT;
                gaddrof();
                vpushi(4);
                gen_op('+');
                vtop->r |= VT_LVAL;
                vswap();
                /* XXX: it works because r2 is spilled last ! */
                store(vtop->r2, vtop - 1);
            }
        }
        vswap();
        vtop--; /* NOT vpop() because on x86 it would flush the fp stack */
        vtop->r |= delayed_cast;
    }
}

/* Process and generate postfix or prefix increment and decrement operations (++, --) */
void inc(int post, int c)
{
    test_lvalue();
    vdup(); /* Secure and save the destination lvalue context on the evaluation stack */
    if (post) {
        gv_dup(); /* Duplicate the active value block if a postfix operator is encountered */
        vrotb(3);
        vrotb(3);
    }
    
    /* Calculate and push mathematical step constants matching token indicators directly */
    vpushi(c - TOK_MID); 
    gen_op('+');
    vstore(); /* Execute memory commitment storing the updated value back into lvalue */
    if (post)
        vpop(); /* Return the cached historical value snapshot if a postfix execution is triggered */
}

/* 28/07/2026 - TCC 0.9.23 */

/* Parse GNUC __attribute__ extension. Currently, the following
   extensions are recognized:
   - aligned(n) : set data/function alignment.
   - packed : force data alignment to 1
   - section(x) : generate data/code in this section.
   - unused : currently ignored, but may be used someday.
   - regparm(n) : pass function parameters in registers (i386 only)
 */
static void parse_attribute(AttributeDef *ad)
{
    int t, n;
    
    while (tok == TOK_ATTRIBUTE1 || tok == TOK_ATTRIBUTE2) {
        next();
        skip('(');
        skip('(');
        while (tok != ')') {
            if (tok < TOK_IDENT)
                expect("attribute name");
            t = tok;
            next();
            switch(t) {
            case TOK_SECTION1:
            case TOK_SECTION2:
                skip('(');
                if (tok != TOK_STR)
                    expect("section name");
                /* Align target attributes straight to our safe flat section mapping registry */
                ad->section = find_section(tcc_state, (char *)tokc.cstr->data);
                next();
                skip(')');
                break;
            case TOK_ALIGNED1:
            case TOK_ALIGNED2:
                if (tok == '(') {
                    next();
                    n = expr_const();
                    if (n <= 0 || (n & (n - 1)) != 0) 
                        error("alignment must be a positive power of two");
                    skip(')');
                } else {
                    n = MAX_ALIGN;
                }
                ad->aligned = n;
                break;
            /* 28/07/2026 - TCC 0.9.23 */
            case TOK_PACKED1:
            case TOK_PACKED2:
                ad->packed = 1;
                break;
            /* .... */
            case TOK_UNUSED1:
            case TOK_UNUSED2:
            case TOK_NORETURN1:
            case TOK_NORETURN2:
                /* Explicitly bypassed as the native TRDOS 386 port optimization layer drops dead objects dynamically */
                break;
            case TOK_CDECL1:
            case TOK_CDECL2:
            case TOK_CDECL3:
                ad->func_call = FUNC_CDECL;
                break;
            case TOK_STDCALL1:
            case TOK_STDCALL2:
            case TOK_STDCALL3:
                ad->func_call = FUNC_STDCALL;
                break;

            /* 28/07/2026 - TCC 0.9.23 */
#ifdef TCC_TARGET_I386
            case TOK_REGPARM1:
            case TOK_REGPARM2:
                skip('(');
                n = expr_const();
                if (n > 3) 
                    n = 3;
                else if (n < 0)
                    n = 0;
                if (n > 0)
                    ad->func_call = FUNC_FASTCALL1 + n - 1;
                skip(')');
                break;
            /* 03/08/2026 */
            /* 30/07/2026 - TCC 0.9.24 - tcc.c */
            case TOK_FASTCALL1:
            case TOK_FASTCALL2:
            case TOK_FASTCALL3:
                ad->func_call = FUNC_FASTCALLW; /* 30/07/2026 */
            //  FUNC_CALL(ad->func_attr) = FUNC_FASTCALLW;
                break;
#endif
            default:
                /* 28/07/2026 - TCC 0.9.23 */
                if (tcc_state->warn_unsupported)  /* 29/07/2026 */
                    warning("'%s' attribute ignored", get_tok_str(t, NULL));

                /* Safely consume parametric trailing tokens matching unknown GNU extensions */
                // if (tok == '(') {
                //    next();
                //    while (tok != ')' && tok != -1)
                //        next();
                //    next();
                // }
                /* 30/07/2026 - TCC 0.9.24 - tcc.c */
                /* skip parameters */
                if (tok == '(') {
                   int parenthesis = 0;
                   do {
                      if (tok == '(') 
                          parenthesis++;
                      else if (tok == ')')
                          parenthesis--;
                      next();
                   } while (parenthesis && tok != -1);
                }
                /* ...... */
                break;
            }
            if (tok != ',')
                break;
            next();
        }
        skip(')');
        skip(')');
    }
}

/* 03/08/2026 - TCC 0.9.24 */

/* Process enum/struct/union type declarations. Parameter 'u' corresponds to either VT_ENUM or VT_STRUCT */
static void struct_decl(CType *type, int u)
{
    int a, v, size, align, maxalign, c, offset;
    int bit_size, bit_pos, bsize, bt, lbit_pos;
    // Sym *s, *ss, **ps;
    /* 03/08/2026 */
    Sym *s, *ss, *ass, **ps;
    AttributeDef ad;
    CType type1, btype;

    a = tok; /* Capture and record the exact structural type declaration prefix token */
    next();
    if (tok != '{') {
        v = tok;
        next();
        if (v < TOK_IDENT)
            expect("struct/union/enum name");
            
        /* Struct already defined in context? Query the tracker and return it instantly if discovered */
        s = struct_find(v);
        if (s) {
            if (s->type.t != a)
                error("invalid type");
            goto do_decl;
        }
    } else {
        v = anon_sym++;
    }
    type1.t = a;
    // s = sym_push(v | SYM_STRUCT, &type1, 0, 0);
    /* 03/08/2026 - TCC 0.9.24 */
    /* we put an undefined size for struct/union */
    s = sym_push(v | SYM_STRUCT, &type1, 0, -1);
    s->r = 0; /* default alignment is zero as gcc */
    /* put struct/union/enum name in type */
 do_decl:
    type->t = u;
    type->ref = s;
    
    if (tok == '{') {
        next();
        // if (s->c)
        /* 07/08/2026 - TCC 0.9.24 */
        if (s->c != -1)
            error("struct/union/enum already defined");
            
        c = 0; /* Enforce compilation rules: Structures or enums cannot remain empty */
        
        if (a == TOK_ENUM) {
            /* Parse C enum sequence fields continuously */
            for(;;) {
                v = tok;
                if (v < TOK_UIDENT)
                    expect("identifier");
                next();
                if (tok == '=') {
                    next();
                    c = expr_const();
                }
                /* Enum identifiers implicitly possess static persistence within execution scopes */
                ss = sym_push(v, &int_type, VT_CONST, c);
                ss->type.t |= VT_STATIC;
                if (tok != ',')
                    break;
                next();
                c++;
                if (tok == '}')
                    break;
            }
            skip('}');
        } else {
            /* Parse composite struct or union elements sequentially */
            maxalign = 1;
            ps = &s->next;
            bit_pos = 0;
            offset = 0;
            while (tok != '}') {
                parse_btype(&btype, &ad);
                while (1) {
                    bit_size = -1;
                    v = 0;
                    type1 = btype;
                    if (tok != ':') {
                        // type_decl(&type1, &ad, &v, TYPE_DIRECT);
                        /* 03/08/2026 - TCC 0.9.24 */
                        type_decl(&type1, &ad, &v, TYPE_DIRECT | TYPE_ABSTRACT);
                        if (v == 0 && (type1.t & VT_BTYPE) != VT_STRUCT)
                            expect("identifier");
                        /* ....... */
                        if ((type1.t & VT_BTYPE) == VT_FUNC || (type1.t & (VT_TYPEDEF | VT_STATIC | VT_EXTERN | VT_INLINE)))
                            error("invalid type for '%s'", get_tok_str(v, NULL));
                    }
                    if (tok == ':') {
                        next();
                        bit_size = expr_const();
                        if (bit_size < 0)
                            error("negative width in bit-field '%s'", get_tok_str(v, NULL));
                        if (v && bit_size == 0)
                            error("zero width for bit-field '%s'", get_tok_str(v, NULL));
                    }
                    size = type_size(&type1, &align);

                    /* 03/08/2026 - TCC 0.9.24 (Modified) */
                    if (ad.aligned) {
                        if (align < ad.aligned)
                            align = ad.aligned;
                    } else if (ad.packed) {
                        align = 1;
                    }
                    /* ...... */

                    lbit_pos = 0;
                    if (bit_size >= 0) {
                        bt = type1.t & VT_BTYPE;
                        // if (bt != VT_INT && bt != VT_BYTE && bt != VT_SHORT && bt != VT_ENUM)
                        /* 03/08/2026 - TCC 0.9.24 */
                        if (bt != VT_INT && bt != VT_BYTE && bt != VT_SHORT && bt != VT_BOOL && bt != VT_ENUM)
                            error("bitfields must have scalar type");
                        bsize = size * 8;
                        if (bit_size > bsize) {
                            error("width of '%s' exceeds its type", get_tok_str(v, NULL));
                        } else if (bit_size == bsize) {
                            bit_pos = 0; /* Full boundary alignment width: Defuse sub-bit field modifications */
                        } else if (bit_size == 0) {
                            /* Clear packing limits to enforce strict structural data block alignment padding */
                            if (bit_pos > 0)
                                bit_pos = bsize;
                        } else {
                            if ((bit_pos + bit_size) > bsize)
                                bit_pos = 0;
                            lbit_pos = bit_pos;
                            
                            /* Pack sub-bit alignments into core type modifiers using structural shifts */
                            type1.t |= VT_BITFIELD | (bit_pos << VT_STRUCT_SHIFT) | (bit_size << (VT_STRUCT_SHIFT + 6));
                            bit_pos += bit_size;
                        }
                    } else {
                        bit_pos = 0;
                    }
                    // if (v) {
                    /* 03/08/2026 - TCC 0.9.24 */
                    if (v != 0 || (type1.t & VT_BTYPE) == VT_STRUCT) {
                        /* Allocate new contiguous memory tracking entries only if starting a fresh bit-field block */
                        if (lbit_pos == 0) {
                            if (a == TOK_STRUCT) {
                                c = (c + align - 1) & -align;
                                offset = c;
                                c += size;
                            } else {
                                offset = 0;
                                if (size > c)
                                    c = size;
                            }
                            if (align > maxalign)
                                maxalign = align;
                        }
                    /* 07/08/2026 */
                    }
                        
                    /* Debug log tracing loops completely siphoned away to retain absolute core minimalism */

                    // ss = sym_push(v | SYM_FIELD, &type1, 0, offset);
                    // *ps = ss;
                    // ps = &ss->next;
                    // }

                    /* 03/08/2026 - TCC 0.9.24 */
                    if (v == 0 && (type1.t & VT_BTYPE) == VT_STRUCT) {
                        ass = type1.ref;
                        while ((ass = ass->next) != NULL) {
                           ss = sym_push(ass->v, &ass->type, 0, offset + ass->c);
                           *ps = ss;
                           ps = &ss->next;
                        }
                    } else if (v) {
                        ss = sym_push(v | SYM_FIELD, &type1, 0, offset);
                        *ps = ss;
                        ps = &ss->next;
                    }
                    /* ....... */
 
                    if (tok == ';' || tok == TOK_EOF)
                        break;
                    skip(',');
                }
                skip(';');
            }
            skip('}');
            /* Compute and finalize structural size properties applying maximal alignment constraints */
            s->c = (c + maxalign - 1) & -maxalign; 
            s->r = maxalign;
        }
    }
}

/* 03/08/2026 - TCC 0.9.24 */
/* 28/07/2026 - TCC 0.9.23 */

/* Return 0 if no type declaration is encountered. Otherwise, return the parsed basic type and advance the token stream */
static int parse_btype(CType *type, AttributeDef *ad)
{
    // int t, u, type_found, typespec_found;
    /* 03/08/2026 - TCC 0.9.24 */
    int t, u, type_found, typespec_found, typedef_found;
    Sym *s;
    CType type1;

    memset(ad, 0, sizeof(AttributeDef));
    type_found = 0;
    typespec_found = 0; /* 28/07/2026 */
    /* 03/08/2026 - TCC 0.9.24 */
    typedef_found = 0;
    t = 0;
    
    while(1) {
        switch(tok) {
        case TOK_EXTENSION:
            /* Safely bypass and ignore explicit GNU C __extension__ keywords */
            next();
            continue;

        /* Core primitive data types resolution paths */
        case TOK_CHAR:
            u = VT_BYTE;
        basic_type:
            next();
        basic_type1:
            if ((t & VT_BTYPE) != 0)
                error("too many basic types");
            t |= u;
            typespec_found = 1;  /* 28/07/2026 */
            break;
        case TOK_VOID:
            u = VT_VOID;
            goto basic_type;
        case TOK_SHORT:
            u = VT_SHORT;
            goto basic_type;
        case TOK_INT:
            next();
            typespec_found = 1;  /* 28/07/2026 */
            break;
        case TOK_LONG:
            next();
            if ((t & VT_BTYPE) == VT_DOUBLE) {
                t = (t & ~VT_BTYPE) | VT_LDOUBLE;
            } else if ((t & VT_BTYPE) == VT_LONG) {
                /* Resolve continuous long long (64-bit integer) modifiers */
                t = (t & ~VT_BTYPE) | VT_LLONG; 
            } else {
                u = VT_LONG;
                goto basic_type1;
            }
            break;
        case TOK_BOOL:
            u = VT_BOOL;
            goto basic_type;
        case TOK_FLOAT:
            u = VT_FLOAT;
            goto basic_type;
        case TOK_DOUBLE:
            next();
            if ((t & VT_BTYPE) == VT_LONG) {
                /* Enforce x87 12-byte long double configurations if long double is found */
                t = (t & ~VT_BTYPE) | VT_LDOUBLE; 
            } else {
                u = VT_DOUBLE;
                goto basic_type1;
            }
            break;
        case TOK_ENUM:
            struct_decl(&type1, VT_ENUM);
        basic_type2:
            u = type1.t;
            type->ref = type1.ref;
            goto basic_type1;
        case TOK_STRUCT:
        case TOK_UNION:
            struct_decl(&type1, VT_STRUCT);
            goto basic_type2;

        /* Language native type qualifiers and layout modifiers */
        case TOK_CONST1:
        case TOK_CONST2:
        case TOK_CONST3:	/* 28/07/2026 */
            t |= VT_CONSTANT;
            next();
            break;
        case TOK_VOLATILE1:
        case TOK_VOLATILE2:
        case TOK_VOLATILE3:     /* 28/07/2026 */
            t |= VT_VOLATILE;
            next();
            break;
        // case TOK_REGISTER:
        case TOK_SIGNED1:
        case TOK_SIGNED2:
        case TOK_SIGNED3:       /* 28/07/2026 */
            typespec_found = 1;
	    t |= VT_SIGNED;
	    next();
	    break;
        case TOK_REGISTER:      /* 28/07/2026 */
        case TOK_AUTO:
        case TOK_RESTRICT1:
        case TOK_RESTRICT2:
        case TOK_RESTRICT3:
            next();
            break;
        case TOK_UNSIGNED:
            t |= VT_UNSIGNED;
            next();
            typespec_found = 1;  /* 28/07/2026 */
            break;

        /* Variable storage persistence and structural scopes visibility qualifiers */
        case TOK_EXTERN:
            t |= VT_EXTERN;
            next();
            break;
        case TOK_STATIC:
            t |= VT_STATIC;
            next();
            break;
        case TOK_TYPEDEF:
            t |= VT_TYPEDEF;
            next();
            break;
        case TOK_INLINE1:
        case TOK_INLINE2:
        case TOK_INLINE3:
            t |= VT_INLINE;
            next();
            break;

        /* GNU C compiler extensions parsing blocks */
        case TOK_ATTRIBUTE1:
        case TOK_ATTRIBUTE2:
            parse_attribute(ad);
            break;
        case TOK_TYPEOF1:
        case TOK_TYPEOF2:
        case TOK_TYPEOF3:
            next();
            parse_expr_type(&type1);
            goto basic_type2;
        default:
            /* 28/07/2026 - TCC 0.9.23 */
            // if (typespec_found)
            /* 03/08/2026 - TCC 0.9.24 */
            if (typespec_found || typedef_found)
               goto the_end;

            /* Evaluate custom user-defined types via typedef structural lookup chains */
            s = sym_find(tok);
            if (!s || !(s->type.t & VT_TYPEDEF))
                goto the_end;
            /* 03/08/2026 */
            typedef_found = 1;
            t |= (s->type.t & ~VT_TYPEDEF);
            type->ref = s->type.ref;
            next();
            /* 03/08/2026 */
            typespec_found = 1;
            break;
        }
        type_found = 1;
    }
the_end:
    /* 28/07/2026 - TCC 0.9.23 */
    if ((t & (VT_SIGNED|VT_UNSIGNED)) == (VT_SIGNED|VT_UNSIGNED))
      error("signed and unsigned modifier");
    if (tcc_state->char_is_unsigned) {
        if ((t & (VT_SIGNED|VT_UNSIGNED|VT_BTYPE)) == VT_BYTE)
            t |= VT_UNSIGNED;
    }
    t &= ~VT_SIGNED;
    /* ..... */
    /* Optimization rule: 'long' remains unrepresented as a raw isolated type internally; flatten it straight to standard 32-bit int */
    if ((t & VT_BTYPE) == VT_LONG)
        t = (t & ~VT_BTYPE) | VT_INT;
    type->t = t;
    return type_found;
}

/* 28/07/2026 - TCC 0.9.23 */

/* Convert a function parameter type dynamically (transforms array definitions to pointers and functions to function pointers) */
static inline void convert_parameter_type(CType *pt)
{
    /* remove const and volatile qualifiers (XXX: const could be used
       to indicate a const function parameter */
    pt->t &= ~(VT_CONSTANT | VT_VOLATILE); /* 28/07/2026 */
    /* array must be transformed to pointer according to ANSI C */
    pt->t &= ~VT_ARRAY;
    if ((pt->t & VT_BTYPE) == VT_FUNC) {
        mk_pointer(pt);
    }
}

/* 03/08/2026 - TCC 0.9.24 */
/* 28/07/2026 - TCC 0.9.23 */

/* Recursive postfix type parser resolving function signature parameters and array dimensional limits */
static void post_type(CType *type, AttributeDef *ad)
{
    int n, l, t1;
    Sym **plast, *s, *first;
    AttributeDef ad1;
    CType pt;

    if (tok == '(') {
        /* Evaluation path: Process and decompose a function prototype declaration sequence */
        next();
        l = 0;
        first = NULL;
        plast = &first;

        while (tok != ')') {
            /* Parse parameter identifier token name and compute contextual variable spacing */
            if (l != FUNC_OLD) {
                if (!parse_btype(&pt, &ad1)) {
                    if (l) {
                        error("invalid type");
                    } else {
                        l = FUNC_OLD;
                        goto old_proto;
                    }
                }
                l = FUNC_NEW;
                if ((pt.t & VT_BTYPE) == VT_VOID && tok == ')')
                    break;
                type_decl(&pt, &ad1, &n, TYPE_DIRECT | TYPE_ABSTRACT);
                if ((pt.t & VT_BTYPE) == VT_VOID)
                    error("parameter declared as void");
            } else {
            old_proto:
                /* Fallback strategy: Process legacy K&R style old function prototype descriptors */
                n = tok;
                /* 03/08/2026 - TCC 0.9.24 */
                if (n < TOK_UIDENT)
                    expect("identifier");
                /* ...... */
                pt.t = VT_INT;
                next();
            }
            convert_parameter_type(&pt);
            s = sym_push(n | SYM_FIELD, &pt, 0, 0);
            *plast = s;
            plast = &s->next;
            if (tok == ',') {
                next();
                if (l == FUNC_NEW && tok == TOK_DOTS) {
                    l = FUNC_ELLIPSIS; /* Mark signature type as variadic parameter function (...) */
                    next();
                    break;
                }
            }
        }
        /* Defuse empty declaration loops enforcing legacy prototype signatures if no parameters exist */
        if (l == 0)
            l = FUNC_OLD;
        skip(')');

        t1 = type->t & VT_STORAGE;
        // type->t &= ~VT_STORAGE;
        /* 28/07/2026 - TCC 0.9.23 */
        /* NOTE: const is ignored in returned type as it has a special
           meaning in gcc / C++ */
        type->t &= ~(VT_STORAGE | VT_CONSTANT); 

        post_type(type, ad);

        /* Enqueue an anonymous field descriptor containing the validated function signature prototype metadata */
        s = sym_push(SYM_FIELD, type, ad->func_call, l);
        s->next = first;
        type->t = t1 | VT_FUNC;
        type->ref = s;
    } else if (tok == '[') {
        /* Evaluation path: Parse multidimensional array layout definitions and constraint metrics */
        next();
        n = -1;
        if (tok != ']') {
            n = expr_const();
            if (n < 0)
                error("invalid array size");
        }
        skip(']');

        t1 = type->t & VT_STORAGE;
        type->t &= ~VT_STORAGE;
        post_type(type, ad);

        /* Enqueue an anonymous field descriptor mapping the array element component data boundaries */
        s = sym_push(SYM_FIELD, type, 0, n);
        type->t = t1 | VT_ARRAY | VT_PTR;
        type->ref = s;
    }
}

/* 28/07/2026 - TCC 0.9.23 */

/* Parse a type declaration sequence (excluding the basic type specification) and load it into 'type'.
   'td' acts as a directional bitmask flag identifying abstract or direct variable identifiers. */
static void type_decl(CType *type, AttributeDef *ad, int *v, int td)
{
    Sym *s;
    CType type1, *type2;
    int qualifiers;
    /* 28/07/2026 */
    while (tok == '*') {
        qualifiers = 0;
    redo:
        next();
        switch(tok) {
        case TOK_CONST1:
        case TOK_CONST2:
        case TOK_CONST3:
            qualifiers |= VT_CONSTANT;
            goto redo;
        case TOK_VOLATILE1:
        case TOK_VOLATILE2:
        case TOK_VOLATILE3:
            qualifiers |= VT_VOLATILE;
            goto redo;
        case TOK_RESTRICT1:
        case TOK_RESTRICT2:
        case TOK_RESTRICT3:
            goto redo;
        }
        mk_pointer(type);
        type->t |= qualifiers;
    }

    if (tok == TOK_ATTRIBUTE1 || tok == TOK_ATTRIBUTE2)
        parse_attribute(ad);

    /* Process recursive inner-parenthesis abstract type configurations complex layouts */
    type1.t = 0; 
    if (tok == '(') {
        next();
        if (tok == TOK_ATTRIBUTE1 || tok == TOK_ATTRIBUTE2)
            parse_attribute(ad);
        type_decl(&type1, ad, v, td);
        skip(')');
    } else {
        /* Parse literal variable identifier token labels directly */
        if (tok >= TOK_IDENT && (td & TYPE_DIRECT)) {
            *v = tok;
            next();
        } else {
            if (!(td & TYPE_ABSTRACT))
                expect("identifier");
            *v = 0;
        }
    }
    post_type(type, ad);
    
    if (tok == TOK_ATTRIBUTE1 || tok == TOK_ATTRIBUTE2)
        parse_attribute(ad);

    if (!type1.t)
        return;

    /* Chain and append newly resolved types at the absolute end of the recursive type1 layout map */
    type2 = &type1;
    for(;;) {
        s = type2->ref;
        type2 = &s->type;
        if (!type2->t) {
            *type2 = *type;
            break;
        }
    }
    *type = type1;
}

/* Extract and compute the baseline lvalue modifier token flags required to match native data storage type t */
static int lvalue_type(int t)
{
    int bt, r;
    r = VT_LVAL;
    bt = t & VT_BTYPE;
    
    if (bt == VT_BYTE || bt == VT_BOOL)
        r |= VT_LVAL_BYTE;
    else if (bt == VT_SHORT)
        r |= VT_LVAL_SHORT;
    else
        return r;
        
    if (t & VT_UNSIGNED)
        r |= VT_LVAL_UNSIGNED;
    return r;
}

/* 03/08/2026 - TCC 0.9.24  (Modified) */

/* Execute direct pointer indirection dereferencing operations ensuring strict semantic type validation */
static void indir(void)
{
    if ((vtop->type.t & VT_BTYPE) != VT_PTR) {
        /* 03/08/2026 */
        if ((vtop->type.t & VT_BTYPE) == VT_FUNC)
            return;
        expect("pointer");
    }
    if ((vtop->r & VT_LVAL) && !nocode_wanted)
        gv(RC_INT);

    vtop->type = *pointed_type(&vtop->type);

    /* Enforce language standard: Contiguous arrays are never raw native mutative assignable lvalues */
    // if (!(vtop->type.t & VT_ARRAY)) {
    /* 03/08/2026 */
    /* Arrays and functions are never lvalues */
    if (!(vtop->type.t & VT_ARRAY) && (vtop->type.t & VT_BTYPE) != VT_FUNC) {
        vtop->r |= lvalue_type(vtop->type.t);
        /* Bound checking hooks completely stripped away to maximize address calculation speeds */
    }
}

/* 28/07/2026 - TCC 0.9.23 */
/* Pass a parameter to a function and do type checking and casting */
static void gfunc_param_typed(Sym *func, Sym *arg)
{
    int func_type;
    CType type;

    func_type = func->c;
    if (func_type == FUNC_OLD ||
        (func_type == FUNC_ELLIPSIS && arg == NULL)) {
        /* default casting : only need to convert float to double */
        if ((vtop->type.t & VT_BTYPE) == VT_FLOAT) {
            type.t = VT_DOUBLE;
            gen_cast(&type);
        }
    } else if (arg == NULL) {
        error("too many arguments to function");
    } else {
        type = arg->type;
        type.t &= ~VT_CONSTANT; /* need to do that to avoid false warning */
        gen_assign_cast(&type);
    }
}

/* Parse explicit parenthesis structures isolating a type definition or cast/typeof expression segment */
static void parse_expr_type(CType *type)
{
    int n;
    AttributeDef ad;

    skip('(');
    if (parse_btype(type, &ad)) {
        type_decl(type, &ad, &n, TYPE_ABSTRACT);
    } else {
        expr_type(type);
    }
    skip(')');
}

/* 29/07/2026 - TCC 0.9.23 */
static void parse_type(CType *type)
{
    AttributeDef ad;
    int n;

    if (!parse_btype(type, &ad)) {
        expect("type");
    }
    type_decl(type, &ad, &n, TYPE_ABSTRACT);
}

/* Rapidly push the current active constant value snapshot from the lexical token parser block */
static void vpush_tokc(int t)
{
    CType type;
    type.t = t;
    vsetc(&type, VT_CONST, &tokc);
}

/* 03/08/2026 - TCC 0.9.24 */
/* 28/07/2026 - TCC 0.9.23 */

/* Parse a primary or unary expression sequence handling data primitives, casts, and pointer references */
static void unary(void)
{
    int n, t, align, size, r;
    CType type;
    Sym *s;
    // GFuncContext gf;
    AttributeDef ad;

 tok_next:
    switch(tok) {
    case TOK_EXTENSION:
        /* Safely skip explicit GNU C __extension__ attributes inside unary expression loops */
        next();
        goto tok_next;
    case TOK_CINT:
    case TOK_CCHAR: 
    case TOK_LCHAR:
        vpushi(tokc.i);
        next();
        break;
    case TOK_CUINT:
        vpush_tokc(VT_INT | VT_UNSIGNED);
        next();
        break;
    case TOK_CLLONG:
        vpush_tokc(VT_LLONG);
        next();
        break;
    case TOK_CULLONG:
        vpush_tokc(VT_LLONG | VT_UNSIGNED);
        next();
        break;
    case TOK_CFLOAT:
        vpush_tokc(VT_FLOAT);
        next();
        break;
    case TOK_CDOUBLE:
        vpush_tokc(VT_DOUBLE);
        next();
        break;
    case TOK_CLDOUBLE:
        vpush_tokc(VT_LDOUBLE);
        next();
        break;
    case TOK___FUNCTION__:
        if (!gnu_ext)
            goto tok_identifier;
        /* fall thru */
    case TOK___FUNC__:
        {
            void *ptr;
            int len;
            /* Resolve standard local function name context payload descriptor string */
            len = strlen(funcname) + 1;
            
            /* Generate matching char[len] array type structure dynamically */
            type.t = VT_BYTE;
            mk_pointer(&type);
            type.t |= VT_ARRAY;
            type.ref->c = len;
            vpush_ref(&type, data_section, data_section->data_offset, len);
            ptr = section_ptr_add(data_section, len);
            memcpy(ptr, funcname, len);
            next();
        }
        break;
    case TOK_LSTR:
        t = VT_INT;
        goto str_init;
    case TOK_STR:
        /* Process and instantiate continuous static raw string character data arrays */
        t = VT_BYTE;
    str_init:
        /* 28/07/2026 - TCC 0.9.23 */	
        if (tcc_state->warn_write_strings)
           t |= VT_CONSTANT;
        type.t = t;
        mk_pointer(&type);
        type.t |= VT_ARRAY;
        memset(&ad, 0, sizeof(AttributeDef));
        decl_initializer_alloc(&type, &ad, VT_CONST, 2, 0, 0);
        break;
    case '(':
        next();
        /* Type Casting or Grouped Expressions parsing branch */
        if (parse_btype(&type, &ad)) {
            type_decl(&type, &ad, &n, TYPE_ABSTRACT);
            skip(')');
            /* Check and process standard ISO C99 compound literal constructs */
            if (tok == '{') {
                /* data is allocated locally by default */
                if (global_expr)
                    r = VT_CONST;
                else
                    r = VT_LOCAL;
                
                /* All compound configurations evaluate as lvalues except raw arrays */
                if (!(type.t & VT_ARRAY))
                    r |= lvalue_type(type.t);
                memset(&ad, 0, sizeof(AttributeDef));
                decl_initializer_alloc(&type, &ad, r, 1, 0, 0);
            } else {
                unary();
                gen_cast(&type);
            }
        } else if (tok == '{') {
            /* Synchronize register states before entering localized statement blocks */
            save_regs(0); 
            block(NULL, NULL, NULL, NULL, 0, 1);
            skip(')');
        } else {
            gexpr();
            skip(')');
        }
        break;
    case '*':
        next();
        unary();
        indir(); /* Execute explicit pointer indirection dereference sequence */
        break;
    case '&':
        next();
        unary();
        /* Function names and array structures bypass classical lvalue traits */
        // if ((vtop->type.t & VT_BTYPE) != VT_FUNC && !(vtop->type.t & VT_ARRAY))
        /* 03/08/2026 - TCC 0.9.24 */
        if ((vtop->type.t & VT_BTYPE) != VT_FUNC &&
            !(vtop->type.t & VT_ARRAY) && !(vtop->type.t & VT_LLOCAL))
            test_lvalue();
        mk_pointer(&vtop->type);
        gaddrof();
        break;
    case '!':
        next();
        unary();
        if ((vtop->r & (VT_VALMASK | VT_LVAL | VT_SYM)) == VT_CONST)
            vtop->c.i = !vtop->c.i;
        else if ((vtop->r & VT_VALMASK) == VT_CMP)
            vtop->c.i = vtop->c.i ^ 1;
        else
            /* 03/08/2026 - TCC 0.9.24 */
            save_regs(1);
            /* .... */
            vseti(VT_JMP, gtst(1, 0));
        break;
    case '~':
        next();
        unary();
        vpushi(-1);
        gen_op('^');
        break;
    case '+':
        next();
        /* Add absolute zero to forcefully evaluate and trigger implicit conversion rules */
        unary();
        if ((vtop->type.t & VT_BTYPE) == VT_PTR)
            error("pointer not accepted for unary plus");
        vpushi(0);
        gen_op('+');
        break;
    case TOK_SIZEOF:
    case TOK_ALIGNOF1:
    case TOK_ALIGNOF2:
        t = tok;
        next();
        if (tok == '(') {
            parse_expr_type(&type);
        } else {
            unary_type(&type);
        }
        size = type_size(&type, &align);
        if (t == TOK_SIZEOF) {
            /* 28/07/2026 - TCC 0.9.23 */
            if (size < 0)
                error("sizeof applied to an incomplete type");
            vpushi(size);
        } else {
            vpushi(align);
        }
        /* 03/08/2026 - TCC 0.9.24 */
        vtop->type.t |= VT_UNSIGNED;
        /* ...... */
        break;

    /* 28/07/2026 - TCC 0.9.23 */
    case TOK_builtin_types_compatible_p:
        {
            CType type1, type2;
            next();
            skip('(');
            parse_type(&type1);
            skip(',');
            parse_type(&type2);
            skip(')');
            type1.t &= ~(VT_CONSTANT | VT_VOLATILE);
            type2.t &= ~(VT_CONSTANT | VT_VOLATILE);
            vpushi(is_compatible_types(&type1, &type2));
        }
        break;
    case TOK_builtin_constant_p:
        {
            int saved_nocode_wanted, res;
            next();
            skip('(');
            saved_nocode_wanted = nocode_wanted;
            nocode_wanted = 1;
            gexpr();
            res = (vtop->r & (VT_VALMASK | VT_LVAL | VT_SYM)) == VT_CONST;
            vpop();
            nocode_wanted = saved_nocode_wanted;
            skip(')');
            vpushi(res);
        }
        break;
     /* ...... */

    case TOK_INC:
    case TOK_DEC:
        t = tok;
        next();
        unary();
        inc(0, t); /* Execute prefix increment or decrement routine instantly */
        break;
    case '-':
        next();
        vpushi(0);
        unary();
        gen_op('-');
        break;
    case TOK_LAND:
        if (!gnu_ext)
            goto tok_identifier;
        next();
        /* GNU C Extension path: Secure and take the relative address offset of a target branching label */
        if (tok < TOK_UIDENT)
            expect("label identifier");
        s = label_find(tok);
        if (!s) {
            s = label_push(&global_label_stack, tok, LABEL_FORWARD);
        } else {
            if (s->r == LABEL_DECLARED)
                s->r = LABEL_FORWARD;
        }
        if (!s->type.t) {
            s->type.t = VT_VOID;
            mk_pointer(&s->type);
            s->type.t |= VT_STATIC;
        }
        vset(&s->type, VT_CONST | VT_SYM, 0);
        vtop->sym = s;
        next();
        break;
    default:
    tok_identifier:
        t = tok;
        next();
        if (t < TOK_UIDENT)
            expect("identifier");
        s = sym_find(t);
        if (!s) {
            if (tok != '(')
                error("'%s' undeclared", get_tok_str(t, NULL));
            /* 28/07/2026 - TCC 0.9.23 */
            /* for simple function calls, we tolerate undeclared
               external reference to int() function */
            if (tcc_state->warn_implicit_function_declaration)
                warning("implicit declaration of function '%s'", get_tok_str(t, NULL));
            /* ..... */
            /* Toleration strategy: Allow undeclared external function linkage defaulting implicitly to int() */
            s = external_global_sym(t, &func_old_type, 0); 
        }

        /* 28/07/2026 - TCC 0.9.23 */
        if ((s->type.t & (VT_STATIC | VT_INLINE | VT_BTYPE)) ==
            (VT_STATIC | VT_INLINE | VT_FUNC)) {
            /* if referencing an inline function, then we generate a
               symbol to it if not already done. It will have the
               effect to generate code for it at the end of the
               compilation unit. Inline function as always
               generated in the text section. */
            if (!s->c)
                put_extern_sym(s, text_section, 0, 0);
            r = VT_SYM | VT_CONST;
        } else {
            r = s->r;
        }
        /* ..... */

        vset(&s->type, s->r, s->c);
        /* If forward tracking reference is detected, redirect internal symbols directly to s */
        if (vtop->r & VT_SYM) {
            vtop->sym = s;
            vtop->c.ul = 0;
        }
        break;
    }
    
    /* Process postfix operators and compound array/structure membership access loops */
    while (1) {
        if (tok == TOK_INC || tok == TOK_DEC) {
            inc(1, tok);
            next();
        } else if (tok == '.' || tok == TOK_ARROW) {
            /* Structural layout member extraction */ 
            if (tok == TOK_ARROW) 
                indir();
            test_lvalue();
            gaddrof();
            next();
            if ((vtop->type.t & VT_BTYPE) != VT_STRUCT)
                expect("struct or union");
            s = vtop->type.ref;
            
            /* Traverse layout sequence to map targeted field boundaries */
            tok |= SYM_FIELD;
            while ((s = s->next) != NULL) {
                if (s->v == tok)
                    break;
            }
            if (!s)
                error("field not found");
                
            /* Factor field offset directly into target pointer reference */
            vtop->type = char_pointer_type; /* Shift type alias window transiently to 'char *' */
            vpushi(s->c);
            gen_op('+');
            
            vtop->type = s->type;
            if (!(vtop->type.t & VT_ARRAY)) {
                vtop->r |= lvalue_type(vtop->type.t);
                /* Bounds verification tracking structures cleanly bypassed to guard core execution speed */
            }
            next();
        } else if (tok == '[') {
            /* Array indexing evaluation path */
            next();
            gexpr();
            gen_op('+');
            indir();
            skip(']');
        } else if (tok == '(') {
            SValue ret;
            Sym *sa;

            /* 28/07/2026 - TCC  0.9.23 */
            int nb_args;

            /* Procedural Function Call Processing Engine */
            if ((vtop->type.t & VT_BTYPE) != VT_FUNC) {
                if ((vtop->type.t & (VT_BTYPE | VT_ARRAY)) == VT_PTR) {
                    vtop->type = *pointed_type(&vtop->type);
                    if ((vtop->type.t & VT_BTYPE) != VT_FUNC)
                        goto error_func;
                } else {
                error_func:
                    expect("function pointer");
                }
            } else {
                vtop->r &= ~VT_LVAL;
            }
            
            /* get return type */
            s = vtop->type.ref;
            /* 28/07/2026 */
            // if (!nocode_wanted) {
            //    save_regs(0); /* Evacuate and cache active volatile working registers */
            //    gfunc_start(&gf, s->r);
            // }
            next();
            sa = s->next; /* Position tracking at first registered structural parameter cell */

            /* 28/07/2026 */
            nb_args = 0;

            /* Struct return ABI optimization: Pass the target output location pointer parameter implicitly */
            /* 28/07/2026 */
            if ((s->type.t & VT_BTYPE) == VT_STRUCT) {
                /* get some space for the returned structure */
                size = type_size(&s->type, &align);
                loc = (loc - size) & -align;
                ret.type = s->type;
                ret.r = VT_LOCAL | VT_LVAL;
                /* pass it as 'int' to avoid structure arg passing
                   problems */
                vseti(VT_LOCAL, loc);
                ret.c = vtop->c;
                nb_args++;
            } else {
                ret.type = s->type; 
                ret.r2 = VT_CONST;
                /* return in register */
                if (is_float(ret.type.t)) {
                    ret.r = REG_FRET; 
                } else {
                    if ((ret.type.t & VT_BTYPE) == VT_LLONG)
                        ret.r2 = REG_LRET;
                    ret.r = REG_IRET;
                }
                ret.c.i = 0;
            }

            if (tok != ')') {
                for(;;) {
                    expr_eq();
                    // gfunc_param_typed(&gf, s, sa);
                    gfunc_param_typed(s, sa);
                    /* 28/07/2026 */
                    nb_args++;
                    if (sa)
                        sa = sa->next;
                    if (tok == ')')
                        break;
                    skip(',');
                }
            }

            if (sa)
                error("too few arguments to function");
            skip(')');
            if (!nocode_wanted)
                // gfunc_call(&gf);
                /* 28/07/2026 */
                gfunc_call(nb_args);
            else
                // vtop--;
                /* 28/07/2026 */
                vtop -= (nb_args + 1);
                
            /* Push and stabilize the final resulting function return value context */
            vsetc(&ret.type, ret.r, &ret.c);
            vtop->r2 = ret.r2;
        } else {
            break;
        }
    }
}

/* Process and evaluate C assignment expressions including compound assignment operators */
static void uneq(void)
{
    int t;
    
    unary();
    if (tok == '=' || (tok >= TOK_A_MOD && tok <= TOK_A_DIV) ||
        tok == TOK_A_XOR || tok == TOK_A_OR || tok == TOK_A_SHL || tok == TOK_A_SAR) {
        test_lvalue();
        t = tok;
        next();
        if (t == '=') {
            expr_eq();
        } else {
            vdup();
            expr_eq();
            /* Extract the core mathematical operation by masking the compound assignment flag */
            gen_op(t & 0x7f);
        }
        vstore(); /* Commit the evaluated value straight into the target lvalue */
    }
}

/* Parse multiplicative operator precedence layers: multiplication, division, and modulo (*, /, %) */
static void expr_prod(void)
{
    int t;

    uneq();
    while (tok == '*' || tok == '/' || tok == '%') {
        t = tok;
        next();
        uneq();
        gen_op(t);
    }
}

/* Parse additive operator precedence layers: addition and subtraction (+, -) */
static void expr_sum(void)
{
    int t;

    expr_prod();
    while (tok == '+' || tok == '-') {
        t = tok;
        next();
        expr_prod();
        gen_op(t);
    }
}

/* Parse bitwise shift operator precedence layers: shift left and arithmetic shift right (<<, >>) */
static void expr_shift(void)
{
    int t;

    expr_sum();
    while (tok == TOK_SHL || tok == TOK_SAR) {
        t = tok;
        next();
        expr_sum();
        gen_op(t);
    }
}

/* Parse relational inequality operator precedence layers (<, >, <=, >=, unsigned checks) */
static void expr_cmp(void)
{
    int t;

    expr_shift();
    while ((tok >= TOK_ULE && tok <= TOK_GT) || tok == TOK_ULT || tok == TOK_UGE) {
        t = tok;
        next();
        expr_shift();
        gen_op(t);
    }
}

/* 03/08/2026 - TCC 0.9.24 */

/* Parse relational equality operator precedence layers: equal and not equal (==, !=) */
static void expr_cmpeq(void) /* Renamed/aligned internally matching clear sequential token steps */
{
    int t;

    expr_cmp();
    while (tok == TOK_EQ || tok == TOK_NE) {
        t = tok;
        next();
        expr_cmp();
        gen_op(t);
    }
}

/* Parse bitwise logical AND operator precedence layer (&) */
static void expr_and(void)
{
    expr_cmpeq(); /* Target corrected upstream link routing */
    while (tok == '&') {
        next();
        expr_cmpeq();
        gen_op('&');
    }
}

/* Parse bitwise logical XOR (exclusive OR) operator precedence layer (^) */
static void expr_xor(void)
{
    expr_and();
    while (tok == '^') {
        next();
        expr_and();
        gen_op('^');
    }
}

/* Parse bitwise logical OR (inclusive OR) operator precedence layer (|) */
static void expr_or(void)
{
    expr_xor();
    while (tok == '|') {
        next();
        expr_xor();
        gen_op('|');
    }
}

/* Compile-time static evaluate handler tracking conditional preprocessor logical AND expressions (&&) */
static void expr_land_const(void)
{
    expr_or();
    while (tok == TOK_LAND) {
        next();
        expr_or();
        gen_op(TOK_LAND);
    }
}

/* Compile-time static evaluate handler tracking conditional preprocessor logical OR expressions (||) */
static void expr_lor_const(void)
{
    expr_land_const();
    while (tok == TOK_LOR) {
        next();
        expr_land_const();
        gen_op(TOK_LOR);
    }
}

/* Process short-circuit runtime logical AND evaluation paths triggering hardware jump instruction blocks (&&) */
static void expr_land(void)
{
    int t;

    expr_or();
    if (tok == TOK_LAND) {
        t = 0;
        for(;;) {
            t = gtst(1, t);
            if (tok != TOK_LAND) {
                vseti(VT_JMPI, t);
                break;
            }
            next();
            expr_or();
        }
    }
}

/* Process short-circuit runtime logical OR evaluation paths triggering hardware jump instruction blocks (||) */
static void expr_lor(void)
{
    int t;

    expr_land();
    if (tok == TOK_LOR) {
        t = 0;
        for(;;) {
            t = gtst(0, t);
            if (tok != TOK_LOR) {
                vseti(VT_JMP, t);
                break;
            }
            next();
            expr_land();
        }
    }
}

/* Parse and evaluate conditional ternary expressions (? :) handling compile-time constants or runtime branches */
static void expr_eq(void)
{
    int tt, u, r1, r2, rc, t1, t2, bt1, bt2;
    SValue sv;
    CType type, type1, type2;

    if (const_wanted) {
        int c1, c;
        expr_lor_const();
        if (tok == '?') {
            c = vtop->c.i;
            vpop();
            next();
            if (tok == ':' && gnu_ext) {
                c1 = c;
            } else {
                gexpr();
                c1 = vtop->c.i;
                vpop();
            }
            skip(':');
            expr_eq();
            if (c)
                vtop->c.i = c1;
        }
    } else {
        expr_lor();
        if (tok == '?') {
            next();
            if (vtop != vstack) {
                /* Optimization path: Force identical register save maps across both evaluation branches */
                if (is_float(vtop->type.t))
                    rc = RC_FLOAT;
                else
                    rc = RC_INT;
                gv(rc);
                save_regs(1);
            }
            if (tok == ':' && gnu_ext) {
                gv_dup();
                tt = gtst(1, 0);
            } else {
                tt = gtst(1, 0);
                gexpr();
            }
            type1 = vtop->type;
            sv = *vtop; /* Cache and save current value frame to avoid register pollution */
            vtop--;     /* Decrement top pointer directly to shield floating point stack state from unexpected flushes */
            skip(':');
            u = gjmp(0);
            gsym(tt);
            expr_eq();
            type2 = vtop->type;

            t1 = type1.t;
            bt1 = t1 & VT_BTYPE;
            t2 = type2.t;
            bt2 = t2 & VT_BTYPE;
            
            /* Apply standard ISO C rules to resolve implicit type promotions across ternary operands */
            if (is_float(bt1) || is_float(bt2)) {
                if (bt1 == VT_LDOUBLE || bt2 == VT_LDOUBLE) {
                    type.t = VT_LDOUBLE;
                } else if (bt1 == VT_DOUBLE || bt2 == VT_DOUBLE) {
                    type.t = VT_DOUBLE;
                } else {
                    type.t = VT_FLOAT;
                }
            } else if (bt1 == VT_LLONG || bt2 == VT_LLONG) {
                type.t = VT_LLONG;
                if ((t1 & (VT_BTYPE | VT_UNSIGNED)) == (VT_LLONG | VT_UNSIGNED) ||
                    (t2 & (VT_BTYPE | VT_UNSIGNED)) == (VT_LLONG | VT_UNSIGNED))
                    type.t |= VT_UNSIGNED;
            } else if (bt1 == VT_PTR || bt2 == VT_PTR) {
                type = type1;
            /* 03/08/2026 - TCC 0.9.24 */
            } else if (bt1 == VT_FUNC || bt2 == VT_FUNC) {
                /* XXX: test function pointer compatibility */
                type = type1;
            /* ..... */
            } else if (bt1 == VT_STRUCT || bt2 == VT_STRUCT) {
                type = type1;
            } else if (bt1 == VT_VOID || bt2 == VT_VOID) {
                type.t = VT_VOID;
            } else {
                type.t = VT_INT;
                if ((t1 & (VT_BTYPE | VT_UNSIGNED)) == (VT_INT | VT_UNSIGNED) ||
                    (t2 & (VT_BTYPE | VT_UNSIGNED)) == (VT_INT | VT_UNSIGNED))
                    type.t |= VT_UNSIGNED;
            }
                
            /* Execute compilation type cast conversions targeting the secondary operand layer */
            gen_cast(&type);
            /* 03/08/2026 - TCC 0.9.24 */
            if (VT_STRUCT == (vtop->type.t & VT_BTYPE))
                gaddrof();
            /* ..... */
            rc = RC_INT;
            if (is_float(type.t)) {
                rc = RC_FLOAT;
            } else if ((type.t & VT_BTYPE) == VT_LLONG) {
                /* Target fixed return registers for 64-bit multi-precision layers to streamline hardware layouts */
                rc = RC_IRET; 
            }
            
            r2 = gv(rc);
            tt = gjmp(0);
            gsym(u);
            
            /* Restore the primary cached expression value snapshot and apply required casting rules */
            *vtop = sv;
            gen_cast(&type);
            /* 03/08/2026 - TCC 0.9.24 */
            if (VT_STRUCT == (vtop->type.t & VT_BTYPE))
                gaddrof();
            /* ..... */
            r1 = gv(rc);
            move_reg(r2, r1);
            vtop->r = r2;
            gsym(tt);
        }
    }
}

/* Parse comma-separated expression sequences sequentially advancing through sub-assignment frames */
static void gexpr(void)
{
    while (1) {
        expr_eq();
        if (tok != ',')
            break;
        vpop();
        next();
    }
}

/* Extract and resolve expression target types while muting explicit machine code emission paths */
static void expr_type(CType *type)
{
    int a;

    a = nocode_wanted;
    nocode_wanted = 1;
    gexpr();
    *type = vtop->type;
    vpop();
    nocode_wanted = a;
}

/* Extract and resolve unary expression target types while muting explicit machine code emission paths */
static void unary_type(CType *type)
{
    int a;

    a = nocode_wanted;
    nocode_wanted = 1;
    unary();
    *type = vtop->type;
    vpop();
    nocode_wanted = a;
}

/* Parse static constant evaluation statements updating vtop constraints */
static void expr_const1(void)
{
    int a;
    a = const_wanted;
    const_wanted = 1;
    expr_eq();
    const_wanted = a;
}

/* Validate compile-time evaluation loops extracting the raw static integer constant value payload */
static int expr_const(void)
{
    int c;
    expr_const1();
    if ((vtop->r & (VT_VALMASK | VT_LVAL | VT_SYM)) != VT_CONST)
        expect("constant expression");
    c = vtop->c.i;
    vpop();
    return c;
}

/* Query lookahead tokens rapidly to identify legitimate code block destination labels */
static int is_label(void)
{
    int last_tok;

    if (tok < TOK_UIDENT)
        return 0;
        
    last_tok = tok;
    next();
    if (tok == ':') {
        next();
        return last_tok;
    } else {
        unget_tok(last_tok); /* Restore historical scanner tracking stack if colon punctuation fails */
        return 0;
    }
}

/* Parse a statement block or control flow construct, tracking active loop/switch destination scopes */
static void block(int *bsym, int *csym, int *case_sym, int *def_sym, int case_reg, int is_expr)
{
    int a, b, c, d;
    Sym *s;

    /* Legacy STABS debug emission engine code siphoned away to retain absolute compile-time speed */

    if (is_expr) {
        /* Enforce fallback assignment rule: Default return value evaluates directly as (void) */
        vpushi(0);
        vtop->type.t = VT_VOID;
    }

    if (tok == TOK_IF) {
        /* Process and resolve conditional 'if' evaluation branches */
        next();
        skip('(');
        gexpr();
        skip(')');
        a = gtst(1, 0);
        block(bsym, csym, case_sym, def_sym, case_reg, 0);
        c = tok;
        if (c == TOK_ELSE) {
            next();
            d = gjmp(0);
            gsym(a);
            block(bsym, csym, case_sym, def_sym, case_reg, 0);
            gsym(d); /* Back-patch and finalize the conditional else jump destination */
        } else {
            gsym(a);
        }
    } else if (tok == TOK_WHILE) {
        /* Process and resolve conditional loop 'while' evaluation branches */
        next();
        d = ind;
        skip('(');
        gexpr();
        skip(')');
        a = gtst(1, 0);
        b = 0;
        block(&a, &b, case_sym, def_sym, case_reg, 0);
        gjmp_addr(d);
        gsym(a);
        gsym_addr(b, d);
    } else if (tok == '{') {
        Sym *llabel;
        
        next();
        /* Snapshot and record localized lexical and label tracking stack positions */
        s = local_stack;
        llabel = local_label_stack;
        
        /* Parse GCC localized __label__ syntax declarations dynamically if flagged */
        if (tok == TOK_LABEL) {
            next();
            for(;;) {
                if (tok < TOK_UIDENT)
                    expect("label identifier");
                label_push(&local_label_stack, tok, LABEL_DECLARED);
                next();
                if (tok == ',') {
                    next();
                } else {
                    skip(';');
                    break;
                }
            }
        }
        while (tok != '}') {
            decl(VT_LOCAL);
            if (tok != '}') {
                if (is_expr)
                    vpop();
                block(bsym, csym, case_sym, def_sym, case_reg, is_expr);
            }
        }
        /* Dismantle localized tracking layers popping symbols and labels out off stack frames cleanly */
        label_pop(&local_label_stack, llabel);
        sym_pop(&local_stack, s);
        next();
    } else if (tok == TOK_RETURN) {
        /* Process routine escape 'return' statements routing register states correctly */
        next();
        if (tok != ';') {
            gexpr();
            gen_assign_cast(&func_vt);
            if ((func_vt.t & VT_BTYPE) == VT_STRUCT) {
                CType type;
                /* Structure return ABI: Copy values straight into the implicit first pointer argument block allocation */
                type = func_vt;
                mk_pointer(&type);
                vset(&type, VT_LOCAL | VT_LVAL, func_vc);
                indir();
                vswap();
                vstore();
            } else if (is_float(func_vt.t)) {
                gv(RC_FRET);
            } else {
                gv(RC_IRET);
            }
            vtop--; /* Force direct decrement over vpop() to shield native x87 FPU stack from unintended flushes */
        }
        skip(';');
        rsym = gjmp(rsym); /* Route straight into the function epilogue escape jump chain */
    } else if (tok == TOK_BREAK) {
        /* Compute structural execution jump breaking out of loop or switch context boundaries */
        if (!bsym)
            error("cannot break");
        *bsym = gjmp(*bsym);
        next();
        skip(';');
    } else if (tok == TOK_CONTINUE) {
        /* Compute structural execution jump returning back to the active loop conditional threshold */
        if (!csym)
            error("cannot continue");
        *csym = gjmp(*csym);
        next();
        skip(';');
    } else if (tok == TOK_FOR) {
        int e;
        next();
        skip('(');
        if (tok != ';') {
            gexpr();
            vpop();
        }
        skip(';');
        d = ind;
        c = ind;
        a = 0;
        b = 0;
        if (tok != ';') {
            gexpr();
            a = gtst(1, 0);
        }
        skip(';');
        if (tok != ')') {
            e = gjmp(0);
            c = ind;
            gexpr();
            vpop();
            gjmp_addr(d);
            gsym(e);
        }
        skip(')');
        block(&a, &b, case_sym, def_sym, case_reg, 0);
        gjmp_addr(c);
        gsym(a);
        gsym_addr(b, c);
    } else if (tok == TOK_DO) {
        /* Process and resolve conditional loop 'do-while' evaluation branches */
        next();
        a = 0;
        b = 0;
        d = ind;
        block(&a, &b, case_sym, def_sym, case_reg, 0);
        skip(TOK_WHILE);
        skip('(');
        gsym(b);
        gexpr();
        c = gtst(0, 0);
        gsym_addr(c, d);
        skip(')');
        gsym(a);
        skip(';');
    } else if (tok == TOK_SWITCH) {
        /* Process and resolve multibranch conditional statement 'switch' evaluation branches */
        next();
        skip('(');
        gexpr();
        case_reg = gv(RC_INT); /* Enforce conversion routing values directly into standard integer register slots */
        vpop();
        skip(')');
        a = 0;
        b = gjmp(0); /* Emit primary initial jump targeting the entry case validation code blocks */
        c = 0;
        block(&a, csym, &b, &c, case_reg, 0);
        if (c == 0)
            c = ind;
        gsym_addr(b, c); /* Finalize fallback destination pointing straight to default label block or switch escape marker */
        gsym(a);         /* Back-patch loose breaks pointing them to destination instruction milestone offset */
    } else if (tok == TOK_CASE) {
        int v1, v2;
        if (!case_sym)
            expect("switch");
        next();
        v1 = expr_const();
        v2 = v1;
        if (gnu_ext && tok == TOK_DOTS) {
            /* GNU C Extension path: Parse sub-bit ranged value conditional branch parameters (case v1 ... v2) */
            next();
            v2 = expr_const();
            if (v2 < v1)
                warning("empty case range");
        }
        
        /* Bypass the statement body utilizing hardware branch jumps to evaluate condition constraints safely */
        b = gjmp(0);
        gsym(*case_sym);
        vseti(case_reg, 0);
        vpushi(v1);
        if (v1 == v2) {
            gen_op(TOK_EQ);
            *case_sym = gtst(1, 0);
        } else {
            gen_op(TOK_GE);
            *case_sym = gtst(1, 0);
            vseti(case_reg, 0);
            vpushi(v2);
            gen_op(TOK_LE);
            *case_sym = gtst(1, *case_sym);
        }
        gsym(b);
        skip(':');
        is_expr = 0;
        goto block_after_label;
    } else if (tok == TOK_DEFAULT) {
        next();
        skip(':');
        if (!def_sym)
            expect("switch");
        if (*def_sym)
            error("too many 'default'");
        *def_sym = ind;
        is_expr = 0;
        goto block_after_label;
    } else if (tok == TOK_GOTO) {
        /* Process dynamic jump structures mapping labels or calculated code-segment pointers straight to architecture lanes */
        next();
        if (tok == '*' && gnu_ext) {
            /* Computed goto instruction resolution path: Dereference code pointer addresses directly */
            next();
            gexpr();
            if ((vtop->type.t & VT_BTYPE) != VT_PTR)
                expect("pointer");
            ggoto();
        } else if (tok >= TOK_UIDENT) {
            s = label_find(tok);
            if (!s) {
                s = label_push(&global_label_stack, tok, LABEL_FORWARD);
            } else {
                if (s->r == LABEL_DECLARED)
                    s->r = LABEL_FORWARD;
            }
            if (s->r & LABEL_FORWARD) 
                s->next = (void *)gjmp((long)s->next);
            else
                gjmp_addr((long)s->next);
            next();
        } else {
            expect("label identifier");
        }
        skip(';');
    } else if (tok == TOK_ASM1 || tok == TOK_ASM2 || tok == TOK_ASM3) {
        /* Branch and route straight to internal native x86 inline assembly parsing engine */
        asm_instr();
    } else {
        b = is_label();
        if (b) {
            /* Destination Branching Label Processing Engine */
            s = label_find(b);
            if (s) {
                if (s->r == LABEL_DEFINED)
                    error("duplicate label '%s'", get_tok_str(s->v, NULL));
                gsym((long)s->next);
                s->r = LABEL_DEFINED;
            } else {
                s = label_push(&global_label_stack, b, LABEL_DEFINED);
            }
            s->next = (void *)ind;
            
        block_after_label:
            if (tok == '}') {
                warning("deprecated use of label at end of compound statement");
            } else {
                if (is_expr)
                    vpop();
                block(bsym, csym, case_sym, def_sym, case_reg, is_expr);
            }
        } else {
            /* Standard continuous C operational expression evaluation path */
            if (tok != ';') {
                if (is_expr) {
                    vpop();
                    gexpr();
                } else {
                    gexpr();
                    vpop();
                }
            }
            skip(';');
        }
    }
}

/* t is the array or struct type. c is the array or struct
   address. cur_index/cur_field is the pointer to the current
   value. 'size_only' is true if only size info is needed (only used
   in arrays) */
static void decl_designator(CType *type, Section *sec, unsigned long c, 
                            int *cur_index, Sym **cur_field, 
                            int size_only)
{
    Sym *s, *f;
    int notfirst, index, index_last, align, l, nb_elems, elem_size;
    CType type1;

    notfirst = 0;
    elem_size = 0;
    nb_elems = 1;
    
    if (gnu_ext && (l = is_label()) != 0)
        goto struct_field;
        
    while (tok == '[' || tok == '.') {
        if (tok == '[') {
            if (!(type->t & VT_ARRAY))
                expect("array type");
            s = type->ref;
            next();
            index = expr_const();
            if (index < 0 || (s->c >= 0 && index >= s->c))
                expect("invalid index");
                
            if (tok == TOK_DOTS && gnu_ext) {
                /* Process GNU C extension path: Parse braced array index ranges (e.g. [1 ... 5]) */
                next();
                index_last = expr_const();
                if (index_last < 0 || (s->c >= 0 && index_last >= s->c) || index_last < index)
                    expect("invalid index");
            } else {
                index_last = index;
            }
            skip(']');
            if (!notfirst)
                *cur_index = index_last;
            type = pointed_type(type);
            elem_size = type_size(type, &align);
            c += index * elem_size;
            
            /* Enforce constraint: We exclusively support range initialization formatting rules for the final designator element */
            nb_elems = index_last - index + 1;
            if (nb_elems != 1) {
                notfirst = 1;
                break;
            }
        } else {
            next();
            l = tok;
            next();
        struct_field:
            if ((type->t & VT_BTYPE) != VT_STRUCT)
                expect("struct/union type");
            s = type->ref;
            l |= SYM_FIELD;
            f = s->next;
            while (f) {
                if (f->v == l)
                    break;
                f = f->next;
            }
            if (!f)
                expect("field");
            if (!notfirst)
                *cur_field = f;
                
            /* Resolve bitmask components overriding storage descriptors carefully */
            type1 = f->type;
            type1.t |= (type->t & ~VT_TYPE);
            type = &type1;
            c += f->c;
        }
        notfirst = 1;
    }
    if (notfirst) {
        if (tok == '=') {
            next();
        } else {
            if (!gnu_ext)
                expect("=");
        }
    } else {
        if (type->t & VT_ARRAY) {
            index = *cur_index;
            type = pointed_type(type);
            c += index * type_size(type, &align);
        } else {
            f = *cur_field;
            if (!f)
                error("too many field init");
                
            /* Resolve bitmask components overriding storage descriptors carefully */
            type1 = f->type;
            type1.t |= (type->t & ~VT_TYPE);
            type = &type1;
            c += f->c;
        }
    }
    decl_initializer(type, sec, c, 0, size_only);

    /* Process compile-time memory duplication loops to fulfill array data range requirements */
    if (!size_only && nb_elems > 1) {
        unsigned long c_end;
        uint8_t *src, *dst;
        int i;

        if (!sec)
            error("range init not supported yet for dynamic storage");
        c_end = c + nb_elems * elem_size;
        if (c_end > sec->data_allocated)
            section_realloc(sec, c_end);
        src = sec->data + c;
        dst = src;
        for(i = 1; i < nb_elems; i++) {
            dst += elem_size;
            memcpy(dst, src, elem_size);
        }
    }
}

#define EXPR_VAL   0
#define EXPR_CONST 1
#define EXPR_ANY   2

/* 03/08/2026 - TCC 0.9.24 */
/* 28/07/2026 - TCC 0.9.23 */

/* Store an active value or evaluated expression directly inside a global section layout or local dynamic array */
static void init_putv(CType *type, Section *sec, unsigned long c, int v, int expr_type)
{
    int saved_global_expr, bt, bit_pos, bit_size;
    void *ptr;
    unsigned long long bit_mask;

    /* 28/07/2026 */
    CType dtype;

    switch(expr_type) {
    case EXPR_VAL:
        vpushi(v);
        break;
    case EXPR_CONST:
        /* Compound literals must be strictly allocated globally inside this context frame layer */
        saved_global_expr = global_expr;
        global_expr = 1;
        expr_const1();
        global_expr = saved_global_expr;

        if ((vtop->r & (VT_VALMASK | VT_LVAL)) != VT_CONST)
            error("initializer element is not constant");
        break;
    case EXPR_ANY:
        expr_eq();
        break;
    }

    /* 28/07/2026 - TCC 0.9.23 */
    dtype = *type;
    dtype.t &= ~VT_CONSTANT; /* need to do that to avoid false warning */
    
    if (sec) {
        /* Global storage execution branch: Assign types and process structural relocation boundaries */
        // gen_assign_cast(type);
        /* 28/07/2026 */
        gen_assign_cast(&dtype);

        bt = type->t & VT_BTYPE;
        // ptr = (void *)(sec->data + c);
        /* 03/08/2026 */
        ptr = sec->data + c;

        if (!(type->t & VT_BITFIELD)) {
            bit_pos = 0;
            bit_size = 32;
            bit_mask = -1LL;
        } else {
            bit_pos = (vtop->type.t >> VT_STRUCT_SHIFT) & 0x3f;
            bit_size = (vtop->type.t >> (VT_STRUCT_SHIFT + 6)) & 0x3f;
            bit_mask = (1LL << bit_size) - 1;
        }

        if ((vtop->r & VT_SYM) &&
            (bt == VT_BYTE || bt == VT_SHORT || bt == VT_DOUBLE ||
             bt == VT_LDOUBLE || bt == VT_LLONG || (bt == VT_INT && bit_size != 32)))
            error("initializer element is not computable at load time");

        switch(bt) {
        case VT_BYTE:
            *(char *)ptr |= (vtop->c.i & bit_mask) << bit_pos;
            break;
        case VT_SHORT:
            *(short *)ptr |= (vtop->c.i & bit_mask) << bit_pos;
            break;
        case VT_DOUBLE:
            *(double *)ptr = vtop->c.d;
            break;
        case VT_LDOUBLE:
            *(long double *)ptr = vtop->c.ld; /* Fixed to native x87 FPU 12-byte layout for flat memory formats */
            break;
        case VT_LLONG:
            *(long long *)ptr |= (vtop->c.ll & bit_mask) << bit_pos;
            break;
        default:
            if (vtop->r & VT_SYM) {
                /* Target out global structural relocation metadata binding straight to target output table data */
                greloc(sec, vtop->sym, c, R_DATA_32);
            }
            *(int *)ptr |= (vtop->c.i & bit_mask) << bit_pos;
            break;
        }
        vtop--;
    } else {
        /* Local dynamic stack execution branch: Secure references and commit straight via vstore */
        // vset(type, VT_LOCAL, c);
        /* 28/07/2026 */
        // vset(&dtype, VT_LOCAL, c);
        /* 03/08/2026 - TCC 0.9.24 */
        vset(&dtype, VT_LOCAL|VT_LVAL, c);
        vswap();
        vstore();
        vpop();
    }
}

/* 28/07/2026 - TCC 0.9.23 */ 

/* Inject zero-fill padding macros to execute dynamic variable-based block layout initialization */
static void init_putz(CType *t, Section *sec, unsigned long c, int size)
{
    /* 28/07/2026 */
    // GFuncContext gf;

    if (sec) {
        /* Bypassed completely for global contexts as the loader layout implicitly wipes standard BSS segments to zero */
    } else {
        /* Emit a high-fidelity continuous memset call to safely initialize local dynamic dynamic runtime storage */
        // gfunc_start(&gf, FUNC_CDECL);
        // vpushi(size);
        // gfunc_param(&gf);
        // vpushi(0);
        // gfunc_param(&gf);
        // vseti(VT_LOCAL, c);
        // gfunc_param(&gf);
        // vpush_global_sym(&func_old_type, TOK_memset);
        // gfunc_call(&gf);
        /* 28/07/2026 */
        vpush_global_sym(&func_old_type, TOK_memset);
        vseti(VT_LOCAL, c);
        vpushi(0);
        vpushi(size);
        gfunc_call(3);
    }
}

/* 03/08/2026 - TCC 0.9.24 */

/* 'type' contains the type and storage info. 'c' is the offset of the
   object in section 'sec'. If 'sec' is NULL, it means stack based
   allocation. 'first' is true if array '{' must be read (multi
   dimension implicit array init handling). 'size_only' is true if
   size only evaluation is wanted (only for arrays). */
static void decl_initializer(CType *type, Section *sec, unsigned long c, 
                             int first, int size_only)
{
    int index, array_length, n, no_oblock, nb, parlevel, i;
    int size1, align1, expr_type;
    Sym *s, *f;
    CType *t1;

    if (type->t & VT_ARRAY) {
        s = type->ref;
        n = s->c;
        array_length = 0;
        t1 = pointed_type(type);
        size1 = type_size(t1, &align1);

        no_oblock = 1;
        if ((first && tok != TOK_LSTR && tok != TOK_STR) || tok == '{') {
            skip('{');
            no_oblock = 0;
        }

        /* Parse string literals if types align, otherwise treat as isolated pointer expressions */
        if ((tok == TOK_LSTR && (t1->t & VT_BTYPE) == VT_INT) ||
            (tok == TOK_STR && (t1->t & VT_BTYPE) == VT_BYTE)) {
            while (tok == TOK_STR || tok == TOK_LSTR) {
                int cstr_len, ch;
                CString *cstr;

                cstr = tokc.cstr;
                if (tok == TOK_STR)
                    cstr_len = cstr->size;
                else
                    cstr_len = cstr->size / sizeof(int);
                cstr_len--;
                nb = cstr_len;
                if (n >= 0 && nb > (n - array_length))
                    nb = n - array_length;
                if (!size_only) {
                    if (cstr_len > nb)
                        warning("initializer-string for array is too long");
                    /* High-speed fast optimization path for standard character arrays mapped in global storage */
                    if (sec && tok == TOK_STR && size1 == 1) {
                        memcpy(sec->data + c + array_length, cstr->data, nb);
                    } else {
                        for(i = 0; i < nb; i++) {
                            if (tok == TOK_STR)
                                ch = ((unsigned char *)cstr->data)[i];
                            else
                                ch = ((int *)cstr->data)[i];
                            init_putv(t1, sec, c + (array_length + i) * size1, ch, EXPR_VAL);
                        }
                    }
                }
                array_length += nb;
                next();
            }
            /* Inject tracking trailing null terminator dynamically if physical memory layout bounds permit */
            if (n < 0 || array_length < n) {
                if (!size_only) {
                    init_putv(t1, sec, c + (array_length * size1), 0, EXPR_VAL);
                }
                array_length++;
            }
        } else {
            index = 0;
            while (tok != '}') {
                decl_designator(type, sec, c, &index, NULL, size_only);
                if (n >= 0 && index >= n)
                    error("index too large");
                /* Automatically populate inner memory layout holes with hardware zero padding frames */
                if (!size_only && array_length < index) {
                    init_putz(t1, sec, c + array_length * size1, (index - array_length) * size1);
                }
                index++;
                if (index > array_length)
                    array_length = index;
                if (index >= n && no_oblock)
                    break;
                if (tok == '}')
                    break;
                skip(',');
            }
        }
        if (!no_oblock)
            skip('}');
        /* Force hardware zero padding layout fill on unallocated tail ends of the target array */
        if (!size_only && n >= 0 && array_length < n) {
            init_putz(t1, sec, c + array_length * size1, (n - array_length) * size1);
        }
        if (n < 0)
            s->c = array_length;
    } else if ((type->t & VT_BTYPE) == VT_STRUCT && (sec || !first || tok == '{')) {
        int par_count;

        par_count = 0;
        if (tok == '(') {
            AttributeDef ad1;
            CType type1;
            next();
            while (tok == '(') {
                par_count++;
                next();
            }
            if (!parse_btype(&type1, &ad1))
                expect("cast");
            type_decl(&type1, &ad1, &n, TYPE_ABSTRACT);

	    /* 03/08/2026 - TCC 0.9.24 */
            // if (!is_compatible_types(type, &type1))
            //    error("invalid type for cast");

            skip(')');
        }
        no_oblock = 1;
        if (first || tok == '{') {
            skip('{');
            no_oblock = 0;
        }
        s = type->ref;
        f = s->next;
        array_length = 0;
        index = 0;
        n = s->c;
        while (tok != '}') {
            decl_designator(type, sec, c, NULL, &f, size_only);
            index = f->c;
            if (!size_only && array_length < index) {
                init_putz(type, sec, c + array_length, index - array_length);
            }
            index = index + type_size(&f->type, &align1);
            if (index > array_length)
                array_length = index;
            f = f->next;
            if (no_oblock && f == NULL)
                break;
            if (tok == '}')
                break;
            skip(',');
        }
        /* Force hardware zero padding layout fill on unallocated tail ends of the target structure */
        if (!size_only && array_length < n) {
            init_putz(type, sec, c + array_length, n - array_length);
        }
        if (!no_oblock)
            skip('}');
        while (par_count) {
            skip(')');
            par_count--;
        }
    } else if (tok == '{') {
        next();
        decl_initializer(type, sec, c, first, size_only);
        skip('}');
    } else if (size_only) {
        /* Bypassed routing path: Safely parse and skip unallocated array expression streams */
        parlevel = 0;
        while ((parlevel > 0 || (tok != '}' && tok != ',')) && tok != -1) {
            if (tok == '(')
                parlevel++;
            else if (tok == ')')
                parlevel--;
            next();
        }
    } else {
        /* Enforce constant requirements for globals, fallback to active expressions inside dynamic stacks */
        expr_type = EXPR_CONST;
        if (!sec)
            expr_type = EXPR_ANY;
        init_putv(type, sec, c, 0, expr_type);
    }
}

/* 03/08/2026 - TCC 0.9.24 */

/* Parse an initializer for type 'type' if 'has_init' is non-zero, and allocate storage space in local 
   or global data segments ('r' acts as either VT_LOCAL or VT_CONST). Declares associated variables safely. */
static void decl_initializer_alloc(CType *type, AttributeDef *ad, int r, int has_init, int v, int scope)
{
    int size, align, addr, data_offset;
    int level;
    ParseState saved_parse_state;
    TokenString init_str;
    Section *sec;

    size = type_size(type, &align);
    tok_str_new(&init_str);
    
    if (size < 0) {
        if (!has_init) 
            error("unknown type size");
            
        /* Cache down all initialisation sequence strings to evaluate explicit array element sizing bounds */
        if (has_init == 2) {
            while (tok == TOK_STR || tok == TOK_LSTR) {
                tok_str_add_tok(&init_str);
                next();
            }
        } else {
            level = 0;
            while (level > 0 || (tok != ',' && tok != ';')) {
                if (tok < 0)
                    error("unexpected end of file in initializer");
                tok_str_add_tok(&init_str);
                if (tok == '{')
                    level++;
                else if (tok == '}') {
                    if (level == 0)
                        break;
                    level--;
                }
                next();
            }
        }
        tok_str_add(&init_str, -1);
        tok_str_add(&init_str, 0);
        
        /* Execute the primary analytical dry-run sizing pass over cached token stream strings */
        save_parse_state(&saved_parse_state);

        macro_ptr = init_str.str;
        next();
        decl_initializer(type, NULL, 0, 1, 1);
        
        /* Re-route pointer states preparing for the final concrete initialization parsing sweep */
        macro_ptr = init_str.str;
        next();
        
        size = type_size(type, &align);
        if (size < 0) 
            error("unknown type size");
    }
    
    /* Overwrite standard boundaries if custom attribute alignment parameter specifies a larger width */
    // if (ad->aligned > align)
    //    align = ad->aligned;
    /* 03/08/2026 - TCC 0.9.24 */
    if (ad->aligned) {
        if (ad->aligned > align)
            align = ad->aligned;
    } else if (ad->packed) {
        align = 1;
    }
    /* ......... */ 
        
    if ((r & VT_VALMASK) == VT_LOCAL) {
        sec = NULL;
        /* Bounds checking structures and safety loops siphoned away to retain absolute linear stack performance */
        loc = (loc - size) & -align;
        addr = loc;
        
        if (v) {
            /* Local variable path: Register metadata directly onto active local evaluation scopes */
            sym_push(v, type, r, addr);
        } else {
            /* Value stack reference path: Push address directly onto evaluation stack frames */
            vset(type, r, addr);
        }
    } else {
        Sym *sym;

        sym = NULL;
        if (v && scope == VT_CONST) {
            /* Cross-verify if the target global symbol identifier was already initialized inside dictionary maps */
            sym = sym_find(v);
            if (sym) {
                if (!is_compatible_types(&sym->type, type))
                    error("incompatible types for redefinition of '%s'", get_tok_str(v, NULL));
                if (sym->type.t & VT_EXTERN) {
                    sym->type.t &= ~VT_EXTERN;
                    /* 03/08/2026 - TCC 0.9.24 */
                    /* set array size if it was ommited in extern declaration */
                    if ((sym->type.t & VT_ARRAY) && sym->type.ref->c < 0 && type->ref->c >= 0)
                        sym->type.ref->c = type->ref->c;
                    /* ........ */ 
                } else {
                    if (!has_init)
                        goto no_alloc;
                }
            }
        }

        /* Route structural data allocation pipelines directly into the assigned ELF data section layout */
        sec = ad->section;
        if (!sec) {
            if (has_init)
                sec = data_section;
            // /* 03/08/2026 - TCC 0.9.24 */
            // else if (tcc_state->nocommon)
            //    sec = bss_section;
            // /* .......... */
        }
        if (sec) {
            data_offset = sec->data_offset;
            data_offset = (data_offset + align - 1) & -align;
            addr = data_offset;
            
            /* Increment data offset limits immediately to secure layout parameters against initialization loops */
            data_offset += size;
            sec->data_offset = data_offset;
            
            if (sec->sh_type != SHT_NOBITS && data_offset > sec->data_allocated)
                section_realloc(sec, data_offset);
            /* 03/08/2026 - TCC 0.9.24 */
            /* align section if needed */
            if (align > sec->sh_addralign)
                sec->sh_addralign = align;
            /* ........... */
        } else {
            addr = 0;
        }

        if (v) {
            // if (scope == VT_CONST) {
            //    if (!sym)
            //        goto do_def;
            // } else {
            // do_def:
            //    sym = sym_push(v, type, r | VT_SYM, 0);
            /* 03/08/2026 - TCC 0.9.24 */
            if (scope != VT_CONST || !sym) {
                sym = sym_push(v, type, r | VT_SYM, 0);
            /* ........... */    
            }
            
            /* Commit definition parameters straight into the output native ELF symbol tables map */
            if (sec) {
                put_extern_sym(sym, sec, addr, size);
            } else {
                Elf32_Sym *esym;
                /* Map global uninitialized symbols as standard SHN_COMMON block allocations */
                put_extern_sym(sym, NULL, align, size);
                esym = &((Elf32_Sym *)symtab_section->data)[sym->c];
                esym->st_shndx = SHN_COMMON;
            }
        } else {
            CValue cval;
            /* Reference payload path: Generate static reference descriptors and load directly onto the value stack */
            sym = get_sym_ref(type, sec, addr, size);
            cval.ul = 0;
            vsetc(type, VT_CONST | VT_SYM, &cval);
            vtop->sym = sym;
        }
    }
    
    if (has_init) {
        decl_initializer(type, sec, addr, 1, 0);
        /* Safely recycle temporary token caching string allocations and restore historical parser state tracking */
        if (init_str.str) {
            tok_str_free(init_str.str);
            restore_parse_state(&saved_parse_state);
        }
    }
 no_alloc: ;
}

/* Parse a legacy K&R (old-style) function parameter declaration list mapping types to symbols sequentially */
static void func_decl_list(Sym *func_sym)
{
    AttributeDef ad;
    int v;
    Sym *s;
    CType btype, type;

    /* Traverse and evaluate each formal parameter declaration mapping downstream context lines */
    while (tok != '{' && tok != ';' && tok != ',' && tok != TOK_EOF) {
        if (!parse_btype(&btype, &ad)) 
            expect("declaration list");
            
        if (((btype.t & VT_BTYPE) == VT_ENUM || (btype.t & VT_BTYPE) == VT_STRUCT) && tok == ';') {
            /* Support language standard: Allow isolated structure or enumeration definitions missing variables trailing after */
        } else {
            for(;;) {
                type = btype;
                type_decl(&type, &ad, &v, TYPE_DIRECT);
                
                /* Scan and locate the mapped parameter label directly inside the internal function parameter stack layout */
                s = func_sym->next;
                while (s != NULL) {
                    if ((s->v & ~SYM_FIELD) == v)
                        goto found;
                    s = s->next;
                }
                error("declaration for parameter '%s' but no such parameter", get_tok_str(v, NULL));
                
            found:
                /* Verify constraints: Specifying alternative storage descriptors except 'register' remains strictly forbidden */
                if (type.t & VT_STORAGE)
                    error("storage class specified for '%s'", get_tok_str(v, NULL)); 
                    
                convert_parameter_type(&type);
                
                /* Update symbol table frame binding the finalized type specifications onto the parameter entry */
                s->type = type;
                
                if (tok == ',')
                    next();
                else
                    break;
            }
        }
        skip(';');
    }
}

/* 03/08/2026 - TCC 0.9.24 */
/* 29/07/2026 - TCC 0.9.23 */
/* parse a function defined by symbol 'sym' and generate its code in
   'cur_text_section' */
static void gen_function(Sym *sym)
{
    /* 03/08/2026 - TCC 0.9.24 */
    int saved_nocode_wanted = nocode_wanted;
    nocode_wanted = 0;
    /* ...... */
    ind = cur_text_section->data_offset;
    /* NOTE: we patch the symbol size later */
    put_extern_sym(sym, cur_text_section, ind, 0);
    funcname = get_tok_str(sym->v, NULL);
    func_ind = ind;
    /* put debug symbol */
    // if (do_debug)
    //    put_func_debug(sym);
    /* push a dummy symbol to enable local sym storage */
    sym_push2(&local_stack, SYM_FIELD, 0, 0);
    gfunc_prolog(&sym->type);
    rsym = 0;
    block(NULL, NULL, NULL, NULL, 0, 0);
    gsym(rsym);
    gfunc_epilog();
    cur_text_section->data_offset = ind;
    label_pop(&global_label_stack, NULL);
    sym_pop(&local_stack, NULL); /* reset local stack */
    /* end of function */
    /* patch symbol size */
    ((Elf32_Sym *)symtab_section->data)[sym->c].st_size = 
        ind - func_ind;
    /* 29/07/2026 */
    // if (do_debug) {
    //    put_stabn(N_FUN, 0, 0, ind - func_ind);
    // }
    funcname = ""; /* for safety */
    func_vt.t = VT_VOID; /* for safety */
    ind = 0; /* for safety */

    /* 03/08/2026 - TCC 0.9.24 */
    nocode_wanted = saved_nocode_wanted;
}

/* 03/08/2026 - TCC 0.9.24 */
/* 29/07/2026 - TCC 0.9.23 */

static void gen_inline_functions(void)
{
    Sym *sym;
    CType *type;
    int *str, inline_generated;

    /* iterate while inline function are referenced */
    for(;;) {
        inline_generated = 0;
        for(sym = global_stack; sym != NULL; sym = sym->prev) {
            type = &sym->type;
            if (((type->t & VT_BTYPE) == VT_FUNC) &&
                (type->t & (VT_STATIC | VT_INLINE)) == 
                (VT_STATIC | VT_INLINE) &&
                sym->c != 0) {
                /* the function was used: generate its code and
                   convert it to a normal function */
                str = (int *)sym->r;
                sym->r = VT_SYM | VT_CONST;
                // type->t &= ~VT_INLINE;
                /* 03/08/2026 - TCC 0.9.24 */
                sym->type.t &= ~VT_INLINE;

                macro_ptr = str;
                next();
                cur_text_section = text_section;
                gen_function(sym);
                macro_ptr = NULL; /* fail safe */

                tok_str_free(str);
                inline_generated = 1;
            }
        }
        if (!inline_generated)
            break;
    }

    /* free all remaining inline function tokens */
    for(sym = global_stack; sym != NULL; sym = sym->prev) {
        type = &sym->type;
        if (((type->t & VT_BTYPE) == VT_FUNC) &&
            (type->t & (VT_STATIC | VT_INLINE)) == 
            (VT_STATIC | VT_INLINE)) {
            /* 03/08/2026 - TCC 0.9.24 */
            if (sym->r == (VT_SYM | VT_CONST)) // gr beware!
                continue;
            /* ...... */ 
            str = (int *)sym->r;
            tok_str_free(str);
            sym->r = 0; /* fail safe */
        }
    }
}

/* 04/08/2026 - TCC 0.9.24 */
/* 29/07/2026 - TCC 0.9.23 */

/* Parse a data declaration or a function definition context.
   Parameter 'l' acts as a bitmask identifying default storage bounds (VT_LOCAL or VT_CONST) */
static void decl(int l)
{
    int v, has_init, r;
    CType type, btype;
    Sym *sym;
    AttributeDef ad;

    while (1) {
        if (!parse_btype(&btype, &ad)) {
            /* Skip redundant semi-colon punctuation separators inside top-level layouts */
            if (tok == ';') {
                next();
                continue;
            }

            /* 28/07/2026 - TCC 0.9.23 */ 
            if (l == VT_CONST &&
                (tok == TOK_ASM1 || tok == TOK_ASM2 || tok == TOK_ASM3)) {
                /* global asm block */
                asm_global_instr();
                continue;
            }

            /* Legacy K&R fallback strategy: Tolerate missing explicit return type declarations for global structures */
            if (l == VT_LOCAL || tok < TOK_DEFINE)
                break;
            btype.t = VT_INT;
        }
        if (((btype.t & VT_BTYPE) == VT_ENUM || (btype.t & VT_BTYPE) == VT_STRUCT) && tok == ';') {
            /* Support language standard: Allow isolated structure or enumeration definitions missing variables */
            next();
            continue;
        }
        while (1) {
            type = btype;
            type_decl(&type, &ad, &v, TYPE_DIRECT);

            if ((type.t & VT_BTYPE) == VT_FUNC) {
                /* if old style function prototype, we accept a
                   declaration list */
                sym = type.ref;
                if (sym->c == FUNC_OLD)
                    func_decl_list(sym);
            }

            if (tok == '{') {
                /* Target validation: Reject invalid locally declared sub-function block statements */
                if (l == VT_LOCAL)
                    error("cannot use local functions");
                // if (!(type.t & VT_FUNC))
                /* 04/08/2026 - TCC 0.9.24 */
                if ((type.t & VT_BTYPE) != VT_FUNC)
                    expect("function definition");
 
                /* 28/07/2026 - TCC 0.9.23 */
                /* reject abstract declarators in function definition */
                sym = type.ref;
                while ((sym = sym->next) != NULL)
                    if (!(sym->v & ~SYM_FIELD))
                       expect("identifier");
                    
                /* Optimize structural linkages translating inline declarations into static symbols if needed */
                if ((type.t & (VT_EXTERN | VT_INLINE)) == (VT_EXTERN | VT_INLINE))
                    type.t = (type.t & ~VT_EXTERN) | VT_STATIC;

		/* 29/07/2026 - TCC 0.9.23 */
                sym = sym_find(v);
                if (sym) {
                    if ((sym->type.t & VT_BTYPE) != VT_FUNC)
                        goto func_error1;
                    /* specific case: if not func_call defined, we put
                       the one of the prototype */
                    /* XXX: should have default value */
                    if (sym->type.ref->r != FUNC_CDECL &&
                        type.ref->r == FUNC_CDECL)
                        type.ref->r = sym->type.ref->r;
                    if (!is_compatible_types(&sym->type, &type)) {
                    func_error1:
                        error("incompatible types for redefinition of '%s'", 
                              get_tok_str(v, NULL));
                    }
                    /* if symbol is already defined, then put complete type */
                    sym->type = type;
                } else {
                    /* put function symbol */
                    sym = global_identifier_push(v, type.t, 0);
                    sym->type.ref = type.ref;
                }

                /* static inline functions are just recorded as a kind
                   of macro. Their code will be emitted at the end of
                   the compilation unit only if they are used */
                if ((type.t & (VT_INLINE | VT_STATIC)) == 
                    (VT_INLINE | VT_STATIC)) {
                    TokenString func_str;
                    int block_level;
                           
                    tok_str_new(&func_str);
                    
                    block_level = 0;
                    for(;;) {
                        int t;
                        if (tok == TOK_EOF)
                            error("unexpected end of file");
                        tok_str_add_tok(&func_str);
                        t = tok;
                        next();
                        if (t == '{') {
                            block_level++;
                        } else if (t == '}') {
                            block_level--;
                            if (block_level == 0)
                                break;
                        }
                    }
                    tok_str_add(&func_str, -1);
                    tok_str_add(&func_str, 0);
                    sym->r = (int)func_str.str;
                } else {
                    /* compute text section */
                    cur_text_section = ad.section;
                    if (!cur_text_section)
                        cur_text_section = text_section;
                    sym->r = VT_SYM | VT_CONST;
                    gen_function(sym);
                }
                break;
            } else {
                if (btype.t & VT_TYPEDEF) {
                    /* Save custom user-defined type definitions via typedef map layout updates */
                    sym = sym_push(v, &type, 0, 0);
                    sym->type.t |= VT_TYPEDEF;
                } else if ((type.t & VT_BTYPE) == VT_FUNC) {
                    /* 29/07/2026 - TCC 0.9.23 */
                    /* external function definition */
                    /* specific case for func_call attribute */
                    if (ad.func_call)
                        type.ref->r = ad.func_call;
                    /* ..... */
                    /* Register references identifying external function linkage boundaries */
                    external_sym(v, &type, 0);
                } else {
                    r = 0;
                    if (!(type.t & VT_ARRAY))
                        r |= lvalue_type(type.t);
                    has_init = (tok == '=');
                    if ((btype.t & VT_EXTERN) ||
                        ((type.t & VT_ARRAY) && (type.t & VT_STATIC) && !has_init && l == VT_CONST && type.ref->c < 0)) {
                        /* External variable allocation path: Bind uninitialized null arrays as absolute external symbols */
                        external_sym(v, &type, r);
                    } else {
                        /* 04/08/2026 - TCC 0.9.24 */
                        type.t |= (btype.t & VT_STATIC); /* Retain "static". */
                        /* ....... */
                        if (type.t & VT_STATIC)
                            r |= VT_CONST;
                        else
                            r |= l;
                        if (has_init)
                            next();
                        /* Trigger explicit variable layout storage assignment and parse initializer chains */
                        decl_initializer_alloc(&type, &ad, r, has_init, v, l);
                    }
                }
                if (tok != ',') {
                    skip(';');
                    break;
                }
                next();
            }
        }
    }
}

/* Better than nothing, but needs extension to handle '-E' option correctly too */
static void preprocess_init(TCCState *s1)
{
    s1->include_stack_ptr = s1->include_stack;
    s1->ifdef_stack_ptr = s1->ifdef_stack;
    file->ifdef_stack_ptr = s1->ifdef_stack_ptr;

    /* Reset value stack tracking register boundaries to primary baseline entry */
    vtop = vstack - 1;
}

/* 04/08/2026 - TCC 0.9.24 */

/* Master Pipeline Entry: Compile the standalone C source file registered inside 'file' descriptor.
   Returns non-zero value if semantic or compilation errors are caught. */
/* 29/07/2026 - TCC 0.9.23 */
static int tcc_compile(TCCState *s1)
{
    Sym *define_start;
    char buf[512];
    volatile int section_sym;

    preprocess_init(s1);

    funcname = "";
    anon_sym = SYM_FIRST_ANOM;

    /* file info: full path + filename */
    section_sym = 0; /* avoid warning */

    /* 29/07/2026 */
    // if (do_debug) {
    //  section_sym = put_elf_sym(symtab_section, 0, 0,
    //                            ELF32_ST_INFO(STB_LOCAL, STT_SECTION), 0,
    //                            text_section->sh_num, NULL);
    //  getcwd(buf, sizeof(buf));
    //  pstrcat(buf, sizeof(buf), "/");
    //  put_stabs_r(buf, N_SO, 0, 0,
    //              text_section->data_offset, text_section, section_sym);
    //  put_stabs_r(file->filename, N_SO, 0, 0, 
    //              text_section->data_offset, text_section, section_sym);
    // }

    /* an elf symbol of type STT_FILE must be put so that STB_LOCAL
       symbols can be safely used */
    put_elf_sym(symtab_section, 0, 0,
                ELF32_ST_INFO(STB_LOCAL, STT_FILE), 0,
                SHN_ABS, file->filename);

    /* define some often used types */
    int_type.t = VT_INT;

    char_pointer_type.t = VT_BYTE;
    mk_pointer(&char_pointer_type);

    func_old_type.t = VT_FUNC;
    func_old_type.ref = sym_push(SYM_FIELD, &int_type, FUNC_CDECL, FUNC_OLD);

    define_start = define_stack;

    /* 04/08/2026 - TCC 0.9.24 */
    nocode_wanted = 1;

    /* 30/07/2026 */
    // if (setjmp(s1->error_jmp_buf) == 0) {
        s1->nb_errors = 0;
        // s1->error_set_jmp_enabled = 1;

        ch = file->buf_ptr[0];
        tok_flags = TOK_FLAG_BOL | TOK_FLAG_BOF;
        parse_flags = PARSE_FLAG_PREPROCESS | PARSE_FLAG_TOK_NUM;
        next();
        decl(VT_CONST);
        if (tok != TOK_EOF)
            expect("declaration");

        /* end of translation unit info */
        /* 29/07/2026 */
        // if (do_debug) {
        //    put_stabs_r(NULL, N_SO, 0, 0,
        //               text_section->data_offset, text_section, section_sym);
        // }
    // }
    // s1->error_set_jmp_enabled = 0;

    /* reset define stack, but leave -Dsymbols (may be incorrect if
       they are undefined) */
    free_defines(define_start);

    gen_inline_functions();

    sym_pop(&global_stack, NULL);

    return s1->nb_errors != 0 ? -1 : 0;
}

/* 02/08/2026 */
#undef fopen
extern int trdos_fopen(const char *filename, const char *mode);
#define fopen trdos_fopen
// #undef write
extern int write(int fd, const void *buf, unsigned int count);
#undef fclose
extern int trdos_fclose(int fd);
#define fclose trdos_fclose

/* 04/08/2026 - Google AI */

// /* TCC Preprocessor Çıktısını TRDOS'a Uyarlama Filtresi */
// void trdos_write_pp_out(const char *str, FILE *out_file) {
//    while (*str) {
//        if (*str == '\n') {
//            // Sadece \n gördüğünde TRDOS için \r\n yazdır
//            fputc('\r', out_file);
//            fputc('\n', out_file);
//        } else if (*str != '\r') { 
//            // Çift \r oluşmasını engellemek için koruma
//            fputc(*str, out_file);
//        }
//        str++;
//    }
// }

/* 09/08/2026 - Google AI */
/* TCC Preprocessor Çıktısını TRDOS'a Uyarlama Filtresi (Düşük Seviyeli Sürüm) */
void trdos_write_pp_out(const char *str, int fd) {
    char cr = '\r';
    char lf = '\n';
    while (*str) {
        if (*str == '\n') {
            // Sadece \n gördüğünde TRDOS için düşük seviyeli write ile \r\n yazdır
            write(fd, &cr, 1);
            write(fd, &lf, 1);
        } else if (*str != '\r') { 
            // Çift \r oluşmasını engellemek için koruma
            write(fd, str, 1);
        }
        str++;
    }
}

/* 01/08/2026 - Google AI */

/* 01/08/2026 - Global Output Filename Descriptor for TRDOS 386 Emission Writer */
// static const char *outfile = NULL;
/* 10/08/2026 -TCC.PRG 0.9.24 self-compiling */
const char *outfile = NULL;

/* 05/08/2026 */
/* 04/08/2026 */

/* Preprocess the current file standalone and handle output emissions via PURE UNREGISTERED WRITE CALLS */
/* 02/08/2026 - TCC 0.9.24 Preprocessor - Argument Alignment Defect Fixed */
/* 06/08/2026 - Google AI */
static int tcc_preprocess(TCCState *s1)
{
    Sym *define_start;
    int out_fd;
    int write_to_file;
    const char *tok_str;
    int last_is_space;

    /* =========================================================================
       TRDOS 386 SECTOR-BUFFERED EMISSION LAYER (512 Byte Zırhlı Disk Tamponu)
       ========================================================================= */
    static char pp_buffer[512];
    unsigned int pp_buf_idx = 0;

    preprocess_init(s1);
    define_start = define_stack;

    out_fd = 1;
    write_to_file = 0;

    if (outfile && outfile[0] != '\0') {

    /* TEST/DEBUG - 06/08/2026 */
    /* ====================================== */
    // unsigned int length;
    // out_fd = (int)fopen(outfile, "r"); // 'test.c' : "tcc -E cpptest.c -o test.c" 
    // if (out_fd <= 0) {
    //    error_noabort("preprocessor error: cannot open output file '%s'", outfile);
    //    free_defines(define_start);
    //    return -1;
    // } else {
    //    write_to_file = 1;
    // }
    // if (out_fd > 2) {
    //   char* buffer[33];
    //   while (length = read(out_fd, *buffer, 32)) {
    //          buffer[length]= '\0';
    //          trdos_write_pp_out(*buffer, stdout);
    //   }
    // }
    // return 0;
    /* ====================================== */

        out_fd = (int)fopen(outfile, "w");
        if (out_fd <= 0) {
            error_noabort("preprocessor error: cannot create output file '%s'", outfile);
            free_defines(define_start);
            return -1;
        }
        write_to_file = 1;
    }

    // Her preprocessor başlangıcında tamponu tamamen sıfırlıyoruz (Zero Fill)
    unsigned int z;
    for (z = 0; z < 512; z++) {
        pp_buffer[z] = '\0';
    }

    ch = file->buf_ptr[0];

    tok_flags = TOK_FLAG_BOL | TOK_FLAG_BOF;
    // parse_flags = PARSE_FLAG_PREPROCESS | PARSE_FLAG_TOK_NUM;
    /* 05/08/2026 - TCC 0.9.24 */
    parse_flags = PARSE_FLAG_ASM_COMMENTS | PARSE_FLAG_PREPROCESS | PARSE_FLAG_LINEFEED;

    last_is_space = 1;

    next();
    while (tok != TOK_EOF) {
        tok_str = get_tok_str(tok, &tokc);
        if (tok_str && tok_str[0] != '\0') {
            unsigned int len;

            /* 02/08/2026 */
            if (tok == TOK_LINEFEED) {
                last_is_space = 1;
            } else {
               /* 04/08/2026 - TCC 0.9.24 (Modified) */
               if (!last_is_space) {
                   /* BOŞLUK KARAKTERİNİ TAMPONA GÜVENLİ EKLEME */
                   /* 06/08/2026 */
                   if (out_fd > 2) {
                       pp_buffer[pp_buf_idx++] = ' ';
                       if (pp_buf_idx >= 512) {
                           write(out_fd, pp_buffer, 512);
                           for (z = 0; z < 512; z++) pp_buffer[z] = '\0';
                           pp_buf_idx = 0;
                       }
                   } else {
                       write(out_fd, " ", 1);
                   }
               }
            }

            len = 0;
            while (tok_str[len]) {
                len++;
            }

            /* 06/08/2026 - Google AI */
            if (len > 0) {
               if (out_fd > 2) {
                  /* TOKEN KARAKTERLERİNİ TAMPONA SIRAYLA DOLDURMA */
                  unsigned int i;
                  for (i = 0; i < len; i++) {
                      pp_buffer[pp_buf_idx++] = tok_str[i];
                      
                      // Tampon tam 512 bayt olunca (1 sektör) diske tek hamlede bas ve sıfırla
                      if (pp_buf_idx >= 512) {
                          write(out_fd, pp_buffer, 512);
                          for (z = 0; z < 512; z++) pp_buffer[z] = '\0'; // Zero fill
                          pp_buf_idx = 0;
                      }
                  }
               } else {
                  /* 04/08/2026 - Google AI */
                  // trdos_write_pp_out(tok_str, stdout);
                  /* 09/08/2026 - TCC.PRG 0.9.24 self-compiling */
                  trdos_write_pp_out(tok_str, 1);
               }
            }

            /* 04/08/2026 */
            last_is_space = 0;
        }
        next();
    }

    /* 06/08/2026 */
    /* =========================================================================
       FLUSH LAYER: Döngü bittiğinde tamponda kalan son kırıntıları diske mühürle
       ========================================================================= */
    if (write_to_file && pp_buf_idx > 0) {
        write(out_fd, pp_buffer, pp_buf_idx);
    }

    if (write_to_file) {
        fclose(out_fd);
    }

    free_defines(define_start); 
    return 0;
}

/* 23/07/2026 */
// #ifdef LIBTCC
// /* Compile a raw C code sequence directly out of a memory resident string wrapper */
// int tcc_compile_string(TCCState *s, const char *str)
// {
//    BufferedFile bf1, *bf = &bf1;
//    int ret, len;
//    char *buf;
//
//    bf->fd = -1;
//    len = strlen(str);
//    buf = tcc_malloc(len + 1);
//    if (!buf)
//        return -1;
//    memcpy(buf, str, len);
//    buf[len] = CH_EOB;
//    bf->buf_ptr = buf;
//    bf->buf_end = buf + len;
//    pstrcpy(bf->filename, sizeof(bf->filename), "<string>");
//    bf->line_num = 1;
//    file = bf;
//
//    ret = tcc_compile(s);
//    tcc_free(buf);
//
//    return ret;
// }
// #endif

/* 04/08/2026 - TCC 0.9.24 */

/* Define a preprocessor symbol map layout injecting explicit value parameters if assignment is requested */
void tcc_define_symbol(TCCState *s1, const char *sym, const char *value)
{
    BufferedFile bf1, *bf = &bf1;

    pstrcpy(bf->buffer, IO_BUF_SIZE, sym);
    pstrcat(bf->buffer, IO_BUF_SIZE, " ");

    if (!value) 
        value = "1";
    pstrcat(bf->buffer, IO_BUF_SIZE, value);

    bf->fd = -1;
    bf->buf_ptr = bf->buffer;
    bf->buf_end = bf->buffer + strlen(bf->buffer);
    *bf->buf_end = CH_EOB;
    bf->filename[0] = '\0';
    ch = file->buf_ptr[0];
    bf->line_num = 1;
    file = bf;

    s1->include_stack_ptr = s1->include_stack;

    // ch = (int)(intptr_t)file->buf_ptr;
    /* 04/08/2026 */
    ch = file->buf_ptr[0];
    next_nomacro();
    parse_define();
    file = NULL;
}

/* Undefine a registered preprocessor macro symbol dropping its link mapping entry from dictionary tables */
void tcc_undefine_symbol(TCCState *s1, const char *sym)
{
    TokenSym *ts;
    Sym *s;
    ts = tok_alloc(sym, strlen(sym));
    s = define_find(ts->tok);
    if (s)
        define_undef(s);
}

/* Native TRDOS i386 Inline Assembly and Object Generator Subsystems integration */
#include "i386-asm.c"
#include "tccasm.c"

/* Native Core ELF Executable Object Linker Subsystem integration */
#include "tccelf.c"

/* Position printing from stabs debug section bypassed under TRDOS flat paradigm */
// static void rt_printline(unsigned long wanted_pc)
// {
//    /* STABS debug interpretation architecture siphoned away to retain core minimalism */
// }

// #ifndef WIN32
/* Runtime caller PC lookup bypassed to drop external ucontext dependencies */
// static int rt_get_caller_pc(unsigned long *paddr, void *uc, int level)
// {
//    return -1;
// }

/* Emit runtime error notification tracking layers stubbed out cleanly */
// void rt_error(void *uc, const char *fmt, ...)
// {
    /* Fallback directly into our standard unified internal error trap */
//    error("Runtime error intercepted inside execution pipeline");
// }

/* Signal handling triggers safely redirected straight to native absolute execution exit shields */
// static void sig_error(int signum, void *siginf, void *puc)
// {
//    exit(255);
// }
// #endif

/* 04/08/2026 - TCC.PRG 0.9.24 */
/* 28/07/2026 - TCC.PRG 0.9.23 */

/* Execute all runtime or linkage relocations (mandatory before utilizing tcc_get_symbol() loops) */
int tcc_relocate(TCCState *s1)
{
    Section *s;
    int i;
    
    /* Fetch and resolve standard 32-bit section pointer descriptors using the core dictionary */
    unsigned int flat_current_offset = 0;
    Section *text_sec   = find_section(s1, ".text");
    Section *rodata_sec = find_section(s1, ".rodata");
    Section *data_sec   = find_section(s1, ".data");
    Section *bss_sec    = find_section(s1, ".bss");

    s1->nb_errors = 0;
    
    /* 17/07/2026 - Google AI */
    // tcc_add_runtime(s1);
    /* 
       Burada crt0.o ve main.c derlendi, tüm sembol açıkları olgunlaştı.
       Şimdi libc.a'yı tam bu satırda cımbızla taratıp eksikleri kapatıyoruz!
    */
    // tcc_link_libc_flat(s1);
    /* 28/07/2026 - TCC.PRG 0.9.23 */
    if (!s1->nostdlib)
       tcc_link_libc_flat(s1);

    relocate_common_syms();

    /* =========================================================================
       TRDOS-386 NATIVE FLAT ADDRESS ALIGNMENT ENGINE (OPTIMIZED RUNTIME)
       ========================================================================= */
    /* 1. Code section (.text) maps strictly to absolute base address 0x0 */
    if (text_sec) {
        text_sec->sh_addr = 0;
        flat_current_offset = text_sec->sh_addr + text_sec->data_offset;
    }

    /* 2. Read-only data (.rodata) appends sequentially directly behind the text milestone */
    if (rodata_sec) {
        rodata_sec->sh_addr = flat_current_offset;
        flat_current_offset += rodata_sec->data_offset;
    }

    /* 3. Initialized data (.data) chains immediately downstream following the rodata layer */
    if (data_sec) {
        data_sec->sh_addr = flat_current_offset;
        flat_current_offset += data_sec->data_offset;
    }

    /* 4. Uninitialized data (.bss) reserves zero-fill layout storage pointing to the trailing end */
    if (bss_sec) {
        if (bss_sec->data_offset > 0) {
            bss_sec->data = tcc_mallocz(bss_sec->data_offset);
        }
        bss_sec->sh_addr = flat_current_offset;
    }

    /* Process alternative allocatable sections ensuring standard baseline execution mappings */
    for(i = 1; i < s1->nb_sections; i++) {
        s = s1->sections[i];
        if (s->sh_flags & SHF_ALLOC) {
            if (s->sh_type == SHT_NOBITS && s != bss_sec) {
                s->data = tcc_mallocz(s->data_offset);
            }
            /* Do not alter base address configuration for our hand-aligned baseline flat quadrants */
            if (s != text_sec && s != rodata_sec && s != data_sec && s != bss_sec) {
                s->sh_addr = (unsigned long)s->data;
            }
        }
    }
    /* ========================================================================= */

    /* Resolve layout symbols based directly on the newly computed precise flat linear addresses */
    relocate_syms(s1, 1);

    if (s1->nb_errors != 0)
        return -1;

    /* Execute the sequential section relocation patch pipeline loops */
    for(i = 1; i < s1->nb_sections; i++) {
        s = s1->sections[i];
        if (s->reloc)
            relocate_section(s1, s);
    }
    return 0;
}

/* =========================================================================
   TRDOS-386 NATIVE STATE LIFE-CYCLE AND USER-INTERFACE ENGINE (FINAL)
   ========================================================================= */

int do_bench = 0;

/* Allocate and initialize a fresh TCC compiler state context instance mapping core registers */
TCCState *tcc_new(void)
{
    const char *p, *r;
    TCCState *s;
    TokenSym *ts;
    int i, c;

    s = tcc_mallocz(sizeof(TCCState));
    if (!s)
        return NULL;
    tcc_state = s;
    s->output_type = TCC_OUTPUT_MEMORY;

    /* Initialize core identifier character mapping tables loop */
    for(i = 0; i < 256; i++)
        isidnum_table[i] = isid(i) || isnum(i);

    /* Construct token tracking tables and clear continuous identifier hash buffers */
    table_ident = NULL;
    memset(hash_ident, 0, TOK_HASH_SIZE * sizeof(TokenSym *));
    
    tok_ident = TOK_IDENT;
    p = tcc_keywords;
    while (*p) {
        r = p;
        for(;;) {
            c = *r++;
            if (c == '\0')
                break;
        }
        ts = tok_alloc(p, r - p - 1);
        p = r;
    }

    /* Enqueue structural predefined tracking anchors to accelerate preprocessor tests */
    define_push(TOK___LINE__, MACRO_OBJ, NULL, NULL);
    define_push(TOK___FILE__, MACRO_OBJ, NULL, NULL);
    define_push(TOK___DATE__, MACRO_OBJ, NULL, NULL);
    define_push(TOK___TIME__, MACRO_OBJ, NULL, NULL);

    /* Instantiate standard baseline preprocessor system macro symbols */
    tcc_define_symbol(s, "__STDC__", NULL);
    tcc_define_symbol(s, "__i386__", NULL); 
    tcc_define_symbol(s, "__TINYC__", NULL);

    /* Inject universal standard size representation layout attributes */
    tcc_define_symbol(s, "__SIZE_TYPE__", "unsigned int");
    tcc_define_symbol(s, "__PTRDIFF_TYPE__", "int");
    tcc_define_symbol(s, "__WCHAR_TYPE__", "int");

    /* Skip and reserve slot zero to shield system against section null pointers */
    dynarray_add((void ***)&s->sections, &s->nb_sections, NULL);

    /* Allocate and register standard baseline ELF quadrants layouts */
    text_section = new_section(s, ".text", SHT_PROGBITS, SHF_ALLOC | SHF_EXECINSTR);
    data_section = new_section(s, ".data", SHT_PROGBITS, SHF_ALLOC | SHF_WRITE);
    bss_section = new_section(s, ".bss", SHT_NOBITS, SHF_ALLOC | SHF_WRITE);

    /* Construct primary standard linking stage ELF symbol tables maps */
    symtab_section = new_symtab(s, ".symtab", SHT_SYMTAB, 0, ".strtab", ".hashtab", SHF_PRIVATE);
    strtab_section = symtab_section->link;

   /* 29/07/2026 - TCC 0.9.23 */
#ifdef CHAR_IS_UNSIGNED
    s->char_is_unsigned = 1;
#endif
    
    return s;
}

/* Purge and release all allocated resources associated with the target TCC compiler state instance */
void tcc_delete(TCCState *s1)
{
    int i, n;

    /* Purge compile-time command line macro definitions from stack frames */
    free_defines(NULL);

    /* Release dynamic token dictionary identifier array storage maps */
    n = tok_ident - TOK_IDENT;
    for(i = 0; i < n; i++)
        tcc_free(table_ident[i]);
    tcc_free(table_ident);

    /* Release all allocated system sections and structural ELF tables from heap memory */
    free_section(symtab_section->hash);

    for(i = 1; i < s1->nb_sections; i++)
        free_section(s1->sections[i]);
    tcc_free(s1->sections);
    
    /* Release configured dynamic storage lookup string array entries sequential paths */
    for(i = 0; i < s1->nb_library_paths; i++)
        tcc_free(s1->library_paths[i]);
    tcc_free(s1->library_paths);

    for(i = 0; i < s1->nb_cached_includes; i++)
        tcc_free(s1->cached_includes[i]);
    tcc_free(s1->cached_includes);

    for(i = 0; i < s1->nb_include_paths; i++)
        tcc_free(s1->include_paths[i]);
    tcc_free(s1->include_paths);

    for(i = 0; i < s1->nb_sysinclude_paths; i++)
        tcc_free(s1->sysinclude_paths[i]);
    tcc_free(s1->sysinclude_paths);

    tcc_free(s1);
}

/* Register a localized preprocessor include directory string lookup target pathname */
int tcc_add_include_path(TCCState *s1, const char *pathname)
{
    char *pathname1;
    
    pathname1 = tcc_strdup(pathname);
    dynarray_add((void ***)&s1->include_paths, &s1->nb_include_paths, pathname1);
    return 0;
}

/* Register a system-level preprocessor header directory string lookup target pathname */
int tcc_add_sysinclude_path(TCCState *s1, const char *pathname)
{
    char *pathname1;
    
    pathname1 = tcc_strdup(pathname);
    dynarray_add((void ***)&s1->sysinclude_paths, &s1->nb_sysinclude_paths, pathname1);
    return 0;
}

/* 01/08/2026 - Google AI */

/* Find source file type by evaluating extensions and route parameters straight to corresponding modules */
/* 01/08/2026 - TCC 0.9.24 Preprocessor & FD Guard Integrated for TRDOS 386 */
static int tcc_add_file_internal(TCCState *s1, const char *filename, int flags)
{
    const char *ext, *filename1;
    Elf32_Ehdr ehdr;
    int fd, ret;
    BufferedFile *saved_file;

    filename1 = strrchr(filename, '/');
    if (filename1)
        filename1++;
    else
        filename1 = filename;
    ext = strrchr(filename1, '.');
    if (ext)
        ext++;

    saved_file = file;
    file = tcc_open(s1, filename);
    if (!file) {
        if (flags & AFF_PRINT_ERROR) {
            error_noabort("file '%s' not found", filename);
        }
        ret = -1;
        goto fail1;
    }

    /* =========================================================================
       CRITICAL PREPROCESSOR HOOK: Eğer -E bayrağı aktifse, uzantı ve ELF
       analizlerini tamamen bypass et ve LIBC/Kernel zırhlı motorunu tetikle.
       ========================================================================= */
    /* 06/08/2026 */
    if (s1->output_type == TCC_OUTPUT_PREPROCESS) {
        ret = tcc_preprocess(s1);
    /* 02/08/2026 */
    // if (flags & AFF_PREPROCESS) {
    //    ret = tcc_preprocess(s1);
    } else if (!ext || !strcmp(ext, "c")) {
        /* C file assumed */
        ret = tcc_compile(s1);
    } else if (!strcmp(ext, "S")) {
        /* preprocessed assembler */ 
        ret = tcc_assemble(s1, 1);
    } else if (!strcmp(ext, "s")) {
        /* non preprocessed assembler */
        ret = tcc_assemble(s1, 0);
    } else {
        fd = file->fd;
        if (read(fd, &ehdr, sizeof(ehdr)) != sizeof(ehdr)) {
            error_noabort("could not read header");
            goto fail;
        }
        lseek(fd, 0, SEEK_SET);

        if (ehdr.e_ident[0] == ELFMAG0 &&
            ehdr.e_ident[1] == ELFMAG1 &&
            ehdr.e_ident[2] == ELFMAG2 &&
            ehdr.e_ident[3] == ELFMAG3) {
            file->line_num = 0; 
            if (ehdr.e_type == ET_REL) {
                ret = tcc_load_object_file(s1, fd, 0);
            } else {
                error_noabort("unrecognized ELF file");
                goto fail;
            }
        } else if (memcmp((char *)&ehdr, ARMAG, 8) == 0) {
            file->line_num = 0; /* do not display line number if error */
            ret = tcc_load_archive(s1, fd);
        } else {
            ret = tcc_load_ldscript(s1);
            if (ret < 0) {
                /* 17/07/2026 - Google AI - DEBUG */
                /* CRITICAL DEBUG: Print the exact file name causing the type mismatch! */
                error_noabort("unrecognized file type for target: '%s'", filename);
                goto fail;
            }
        }
    }
 the_end:
    tcc_close(file);
 fail1:
    file = saved_file;
    return ret;
 fail:
    ret = -1;
    goto the_end;
}

/* Public API Entry: Add a standalone file to the current compiler instance state redirection map */
int tcc_add_file(TCCState *s, const char *filename)
{
    return tcc_add_file_internal(s, filename, AFF_PRINT_ERROR);
}

/* Public API Entry: Register a new library file searching directory path into storage lists */
int tcc_add_library_path(TCCState *s, const char *pathname)
{
    char *pathname1;
    
    pathname1 = tcc_strdup(pathname);
    dynarray_add((void ***)&s->library_paths, &s->nb_library_paths, pathname1);
    return 0;
}

/* Public API Entry: Resolve and append a library file utilizing short-hand token command markers (-l name) */
int tcc_add_library(TCCState *s, const char *libraryname)
{
    // char buf[1024];
    /* 29/07/2026 */
    char buf[256];
    int i;
    
    /* Dynamic shared object loading bypassed completely under TRDOS pure static link design rules */

    /* Evaluate and link static library archive files (.a) sequentially */
    for(i = 0; i < s->nb_library_paths; i++) {
        snprintf(buf, sizeof(buf), "%s/lib%s.a", s->library_paths[i], libraryname);
	/* 16/07/2026 - Google AI */
        if (tcc_add_file_internal(s, buf, 2) == 0) 
            return 0;
    }
    return -1;
}

/* Public API Entry: Inject an explicit global symbol reference descriptor with a customized absolute runtime address */
int tcc_add_symbol(TCCState *s, const char *name, unsigned long val)
{
    add_elf_sym(symtab_section, val, 0, ELF32_ST_INFO(STB_GLOBAL, STT_NOTYPE), SHN_ABS, name);
    return 0;
}

/* Configure the compilation output storage targets and map target system include directory trees */
int tcc_set_output_type(TCCState *s, int output_type)
{
    /* 29/07/2026 */
    // char buf[1024];

    s->output_type = output_type;

    if (!s->nostdinc) {
        char buf[256];  /* 29/07/2026 */
        snprintf(buf, sizeof(buf), "%s/include", tcc_lib_path);
        tcc_add_sysinclude_path(s, buf);
    }

    /* 04/08/2026 - TCC 0.9.24 tcc.c */ 
    if (s->char_is_unsigned) {
        tcc_define_symbol(s, "__CHAR_UNSIGNED__", NULL);
    }
    /* .......... */

    /* 17/07/2026 - Google AI */
    // tcc_add_runtime(s);
 
   /* 18/07/2026 - TRDOS 386 OUTPUT LAYER FIX */
    /* CRITICAL: Inject 'crt0.o' ONLY when generating a final standalone executable PRG flat binary! */
    /* Do NOT inject startup routines when compiling raw object files via 'tcc -c' (TCC_OUTPUT_OBJ) */
    if (output_type == TCC_OUTPUT_EXE) {
        tcc_add_crt0_flat(s);
    }

    return 0;
}

/* 29/07/2026 - TCC 0.9.23 */
#define WD_ALL    0x0001 /* warning is activated when using -Wall */
#define FD_INVERT 0x0002 /* invert value before storing */

typedef struct FlagDef {
    uint16_t offset;
    uint16_t flags;
    const char *name;
} FlagDef;

static const FlagDef warning_defs[] = {
    { offsetof(TCCState, warn_unsupported), 0, "unsupported" },
    { offsetof(TCCState, warn_write_strings), 0, "write-strings" },
    { offsetof(TCCState, warn_error), 0, "error" },
    { offsetof(TCCState, warn_implicit_function_declaration), WD_ALL,
      "implicit-function-declaration" },
};

static int set_flag(TCCState *s, const FlagDef *flags, int nb_flags,
                    const char *name, int value)
{
    int i;
    const FlagDef *p;
    const char *r;

    r = name;
    if (r[0] == 'n' && r[1] == 'o' && r[2] == '-') {
        r += 3;
        value = !value;
    }
    for(i = 0, p = flags; i < nb_flags; i++, p++) {
        if (!strcmp(r, p->name))
            goto found;
    }
    return -1;
 found:
    if (p->flags & FD_INVERT)
        value = !value;
    *(int *)((uint8_t *)s + p->offset) = value;
    return 0;
}

/* set/reset a warning */
int tcc_set_warning(TCCState *s, const char *warning_name, int value)
{
    int i;
    const FlagDef *p;

    if (!strcmp(warning_name, "all")) {
        for(i = 0, p = warning_defs; i < countof(warning_defs); i++, p++) {
            if (p->flags & WD_ALL)
                *(int *)((uint8_t *)s + p->offset) = 1;
        }
        return 0;
    } else {
        return set_flag(s, warning_defs, countof(warning_defs),
                        warning_name, value);
    }
}

static const FlagDef flag_defs[] = {
    { offsetof(TCCState, char_is_unsigned), 0, "unsigned-char" },
    { offsetof(TCCState, char_is_unsigned), FD_INVERT, "signed-char" },
    { offsetof(TCCState, nocommon), FD_INVERT, "common" },
    { offsetof(TCCState, leading_underscore), 0, "leading-underscore" },
};

/* set/reset a flag */
int tcc_set_flag(TCCState *s, const char *flag_name, int value)
{
    return set_flag(s, flag_defs, countof(flag_defs),
                    flag_name, value);
}
/* ..... */

/* 09/08/2026 - TCC 0.9.24 self-compiling */
#ifndef LIBTCC

/* Extract and return the localized chronological platform timer metric scaled in microseconds */
// static int64_t getclock_us(void)
/* 23/07/2026 */
static unsigned long getclock_us(void)
{
    // struct timeval tv;
    // tv.tv_sec = 0;
    // tv.tv_usec = 0;
    // return tv.tv_sec * 1000000LL + tv.tv_usec;

    /* 09/08/2026 */   
    /* TRDOS 386 v2.0.11 systime - get timer ticks (18.2 Hz) */
    unsigned long ticks = 0;
    __asm__ (
       "movl $13, %%eax\n\t"
       "movl $4, %%ebx\n\t"
       "int $0x40\n\t"
       "movl %%eax, %0"
       : "=r" (ticks)
       :
       : "eax"
    );
    return ticks;
}

/* 01/08/2026 - TCC 0.9.24 (Modified) */
/* 29/07/2026 */
/* Print the primary operational command line argument parameters documentation guide directly to stdout */
void help(void)
{
    printf("tcc version " TCC_VERSION " - Tiny C Compiler - Copyright (C) 2001-2006 Fabrice Bellard\n" 
           "usage: tcc [-v] [-c] [-o outfile] [-Bdir] [-bench] [-Idir] [-Dsym[=val]] [-Usym]\n"
           "           [-Wwarn] [-Ldir] [-llib] [infile1 infile2...]\n"
           "\n"
           "General options:\n"
           "  -v          display current version\n"
           "  -c          compile only - generate an object file\n"
           "  -o outfile  set output filename\n"
           "  -Bdir       set tcc internal library path\n"
           "  -bench      output compilation statistics\n"
           "  -fflag      set or reset (with 'no-' prefix) 'flag' (see man page)\n"
           "  -Wwarning   set or reset (with 'no-' prefix) 'warning' (see man page)\n"
           "  -w          disable all warnings\n"
           "Preprocessor options:\n"
           "  -E          preprocess only\n"
           "  -Idir       add include path 'dir'\n"
           "  -Dsym[=val] define 'sym' with value 'val'\n"
           "  -Usym       undefine 'sym'\n"
           "Linker options:\n"
           "  -Ldir       add library path 'dir'\n"
           "  -llib       link with static library 'lib'\n"
           "  -r          relocatable output\n"
           );
}
#endif

#define TCC_OPTION_HAS_ARG 0x0001
#define TCC_OPTION_NOSEP   0x0002 /* Enforce rule: Space is strictly forbidden between option and argument */

typedef struct TCCOption {
    const char *name;
    uint16_t index;
    uint16_t flags;
} TCCOption;

/* 01/08/2026 - TCC 0.9.24 */
/* 31/07/2026 */
/* 29/07/2026 */
/* 28/07/2026 - TCC 0.9.23 (Modified) */

enum {
    TCC_OPTION_HELP,
    TCC_OPTION_I,
    TCC_OPTION_D,
    TCC_OPTION_U,
    TCC_OPTION_L,
    TCC_OPTION_B,
    TCC_OPTION_l,
    TCC_OPTION_bench,
    TCC_OPTION_c,
    TCC_OPTION_o,
    TCC_OPTION_r,
    TCC_OPTION_W,
    TCC_OPTION_f,
    TCC_OPTION_nostdinc,
    TCC_OPTION_nostdlib,
    TCC_OPTION_print_search_dirs,
    TCC_OPTION_v,
    TCC_OPTION_w,
    TCC_OPTION_E, /* 01/08/2026 - TCC 0.9.24 Preprocessor Only bayrağı */
};

/* 04/08/2026 */
/* 01/08/2026 - TCC 0.9.24 */
/* 31/07/2026 */
/* 29/07/2026 */
/* 28/07/2026 - TCC 0.9.23 (Modified) */

/* Master operational command-line argument option matching lookup array matrix */
static const TCCOption tcc_options[] = {
    { "h", TCC_OPTION_HELP, 0 },
    { "?", TCC_OPTION_HELP, 0 },
    { "I", TCC_OPTION_I, TCC_OPTION_HAS_ARG },
    { "D", TCC_OPTION_D, TCC_OPTION_HAS_ARG },
    { "U", TCC_OPTION_U, TCC_OPTION_HAS_ARG },
    { "L", TCC_OPTION_L, TCC_OPTION_HAS_ARG },
    { "B", TCC_OPTION_B, TCC_OPTION_HAS_ARG },
    { "l", TCC_OPTION_l, TCC_OPTION_HAS_ARG | TCC_OPTION_NOSEP },
    { "bench", TCC_OPTION_bench, 0 },
    { "c", TCC_OPTION_c, 0 },
    { "o", TCC_OPTION_o, TCC_OPTION_HAS_ARG },
    { "r", TCC_OPTION_r, 0 },
    { "W", TCC_OPTION_W, TCC_OPTION_HAS_ARG | TCC_OPTION_NOSEP },
    { "f", TCC_OPTION_f, TCC_OPTION_HAS_ARG | TCC_OPTION_NOSEP },
    { "nostdinc", TCC_OPTION_nostdinc, 0 },
    { "nostdlib", TCC_OPTION_nostdlib, 0 },
    { "print-search-dirs", TCC_OPTION_print_search_dirs, 0 },
    { "v", TCC_OPTION_v, 0 },
    { "w", TCC_OPTION_w, 0 },
    { "E", TCC_OPTION_E, 0 }, /* 01/08/2026 - Saf Onislemci tetikleyicisi */
    { NULL },
};

/* 09/08/2026 - TCC 0.9.24 self-compiling */
/* 29/07/2026 */
void trdos_sys_exit(int exit_code) {
    __asm__ __volatile__ (
       "movl $1, %%eax\n\t"            /* TRDOS kernel service index: sys_exit */
       "int $0x40"                    /* Vector directly into Ring 0 */
       :
       : "b" (exit_code)              /* Exit parameter */
       : "eax"
    ); 
}

/* 20/07/2026 - Google AI */
/* =========================================================================
   GOOGLE AI & ERDOGAN TAN - GLOBAL UNDEFINED SYMBOL GUARD (REVISED)
   ========================================================================= */
/* Dosya diskete mühürlenmeden hemen önce çağrılmalıdır. */

void check_undefined_symbols(TCCState *s1) {
    Section *symtab = 0;
    Section *strtab = 0;
    Elf32_Sym *sym;
    const char *sym_name;
    int i, j, sym_count;

    if (!s1 || !s1->sections) return;
    
    /* 1. Seksiyondaki Sembol ve String Tablolarını Dinamik Olarak Bul */
    for (i = 0; i < s1->nb_sections; i++) {
        if (s1->sections[i]) {
            /* SHT_SYMTAB = 2 (Sembol Tablosu) */
            if (s1->sections[i]->sh_type == 2) {
                symtab = s1->sections[i];
            }
            /* SHT_STRTAB = 3 (String Tablosu) ve adı ".strtab" olan ana tablo */
            else if (s1->sections[i]->sh_type == 3) {
                strtab = s1->sections[i];
            }
        }
    }

    /* Eğer tablolar sistemde yoksa taramayı güvenle atla */
    if (!symtab || !symtab->data || !strtab || !strtab->data) return;

    sym_count = symtab->data_offset / sizeof(Elf32_Sym);
    sym = (Elf32_Sym *)symtab->data;

    /* 2. Tanımsız (SHN_UNDEF) Sembol Kaçaklarını Tara */
    for (j = 0; j < sym_count; j++) {
        /* SHN_UNDEF (0): Çözülmemiş harici referanslar */
        /* (sym[j].st_info >> 4) != 2 -> STB_WEAK (zayıf bağ) olmayan mutlak bağımlılıklar */
        if (sym[j].st_shndx == 0 && (sym[j].st_info >> 4) != 2) { 
            
            sym_name = (char *)strtab->data + sym[j].st_name;
            
            /* Boş veya dahili TCC sembollerini süz */
            if (sym_name && sym_name[0] != '\0') {
                /* TRDOS Terminaline hatayı açıkça bas */
                printf("\n-> [TRDOS LINKER ERROR]: Undefined reference to symbol '%s'\n", sym_name);
                printf("-> [TRDOS SHIELD]: Link aborted to prevent CPU Exception.\n");
                
                /* 09/08/2026 */ 
                /* Ring 0 sys_exit(1) donanım kalkanını tetikle ve üretimi durdur */
                // __asm__ (
                //    "movl $1, %%ebx\n\t"
                //    "movl $1, %%eax\n\t"
                //    "int $0x40"
                // );

                /* 31/07/2026 */
                exit(1);	/* trdos_sys_exit(int exit_code) */
            }
        }
    }
}

/* 02/08/2026 */
/* 01/08/2026 - TCC 0.9.24 (Modified) */
/* 31/07/2026 */
/* 29/07/2026 */
/* 28/07/2026 - TCC 0.9.23 (Modified) */
/* 24/07/2026 - TCC.PRG 0.9.18 */

/* Master Executable Entry Point: Orchestrates the command-line argument pipeline and triggers compiler stages */
int main(int argc, char **argv)
{
    char *r;
    // int optind, output_type, multiple_files, i, reloc_output;
    /* 02/08/2026 */
    int optind, output_type, i, reloc_output;
    TCCState *s;
    char **files;
    // int nb_files, nb_libraries, nb_objfiles, dminus, ret;
    /* 29/07/2026 */
    int nb_files, nb_libraries, nb_objfiles, ret;
    // char objfilename[1024];
    char objfilename[256];  /* 29/07/2026 */
    int64_t start_time = 0;
    const TCCOption *popt;
    // const char *optarg, *p1, *r1, *outfile;
    /* 01/08/2026 */
    const char *optarg, *p1, *r1;

    int print_search_dirs;

    if (argc == 1) {
        /* Direct system write calls to display quick usage information efficiently without buffer flushes */
        write(1, "Tiny C Compiler version 0.9.24 for TRDOS 386\r\n", 46);
        write(1, "Usage: tcc [options] [infile1] [infile2]...\r\n", 45);
        write(1, "Options:\r\n", 10);
        write(1, "  -c          compile only (produce .o object file)\r\n", 53);
        write(1, "  -o outfile  set output file name (.PRG default)\r\n", 51);
        write(1, "  -v          display tcc version\r\n", 35);

        /* 09/08/2026 */ 
        /* Forced Native TRDOS Exit Shield: Bypass terminal standard code returns via direct kernel interruption */
        // __asm__ (
        //    "movl $0, %%ebx\n\t"
        //    "movl $1, %%eax\n\t" /* sys_exit (1) vector invocation */
        //    "int $0x40"
        // );
        // return 0;

        /* 31/07/2026 */
        exit(0);	/* trdos_sys_exit(int exit_code) */

    }

    /* Instantiate a fresh standalone state registry context block mapping core operational allocations */
    s = tcc_new();
    if (!s) {
        return 1;
    }

    /* Dün yapılan cerrahi temizliğe sadık kalıyoruz: Sadece OBJ ve PRG (Yerel Flat Binary) hatları aktiftir */
    output_type = TCC_OUTPUT_EXE; 
    optind = 1;
    /* 01/08/2026 */
    // outfile = NULL;
    /* 02/08/2026 */
    // multiple_files = 1;
    /* 29/07/2026 */
    // dminus = 0;
    files = NULL;
    nb_files = 0;
    nb_libraries = 0;
    reloc_output = 0;
    print_search_dirs = 0;
    /* 02/08/2026 */
    ret = 0;

    while (1) {
        if (optind >= argc) {
            if (nb_files == 0 && !print_search_dirs)
                goto show_help;
            else
                break;
        }

        r = argv[optind++];
        if (r[0] != '-') {
            /* Enqueue input source file paths straight into the active compilation tracking array layout */
            dynarray_add((void ***)&files, &nb_files, r);

            /* 02/08/2026 */
            // if (!multiple_files) {
            //    optind--;
            //    /* Break immediately if sequential file scanning limits are constrained */
            //    break;
            // }
        } else {
            /* =========================================================================
               TRDOS NATIVE PURE FLAT COMMAND LINE ARGUMENT PARSING ENGINE
               ========================================================================= */
            popt = tcc_options;
            r1 = r + 1; /* Skip the loose hyphen identifier character to extract the pure option literal */

            for(;;) {
                p1 = popt->name;
                
                if (p1 == NULL) {
                    error("invalid option -- '%s'", r);
                }

                /* Execute direct memory-safe sequential string comparison loop without external str/libc overhead */
                char *s1 = (char *)p1;
                char *s2 = (char *)r1;
                
                while (*s1 && (*s1 == *s2)) {
                    s1++;
                    s2++;
                }

                if (*s1 == '\0') {
                    r1 = s2; /* Shift boundary pointers directly to extract parameters for contiguous args like -Ipath */
                    goto option_found;
                }

                popt++; /* Safely advance to the adjacent data cell structure inside lookup tables matrix */
            }

        option_found:
            if (popt->flags & TCC_OPTION_HAS_ARG) {
                if (*r1 != '\0' || (popt->flags & TCC_OPTION_NOSEP)) {
                    optarg = r1;
                } else {
                    if (optind >= argc)
                        error("argument to '%s' is missing", r);
                    optarg = argv[optind++];
                }
            } else {
                if (*r1 != '\0')
                    goto show_help;
                optarg = NULL;
            }

            /* 02/08/2026 - TCC 0.9.24 (Modified) */
            switch(popt->index) {
            case TCC_OPTION_HELP:
            show_help:
                help();
                return 1;
            case TCC_OPTION_I:
                if (tcc_add_include_path(s, optarg) < 0)
                    error("too many include paths");
                break;
            case TCC_OPTION_D:
                {
                    char *sym, *value;
                    sym = (char *)optarg;
                    value = strchr(sym, '=');
                    if (value) {
                        *value = '\0';
                        value++;
                    }
                    tcc_define_symbol(s, sym, value);
                }
                break;
            case TCC_OPTION_U:
                tcc_undefine_symbol(s, optarg);
                break;
            case TCC_OPTION_L:
                tcc_add_library_path(s, optarg);
                break;
            case TCC_OPTION_B:
                tcc_lib_path = optarg;
                break;
            case TCC_OPTION_l:
                dynarray_add((void ***)&files, &nb_files, r);
                nb_libraries++;
                break;
            case TCC_OPTION_bench:
                do_bench = 1;
                break;
            case TCC_OPTION_c:
                // multiple_files = 1;
                output_type = TCC_OUTPUT_OBJ;
                break;
            case TCC_OPTION_o:
                // multiple_files = 1;
                outfile = optarg; /* Kullanıcının belirlediği isim doğrudan yakalanır */
                break;
            case TCC_OPTION_r:
                /* generate a .o merging several output files */
                reloc_output = 1;
                output_type = TCC_OUTPUT_OBJ;
                break;
            case TCC_OPTION_nostdinc:
                s->nostdinc = 1;
                break;
            /* 28/07/2026 - TCC 0.9.23 */
            case TCC_OPTION_nostdlib:
                s->nostdlib = 1;
                break;
            case TCC_OPTION_print_search_dirs:
                print_search_dirs = 1;
                break;
            case TCC_OPTION_v:  /* 01/08/2026 */
                write(1, "Tiny C Compiler version 0.9.24 for TRDOS 386\r\n", 46);
                return 0;
            /* 31/07/2026 */
            case TCC_OPTION_f:
                if (tcc_set_flag(s, optarg, 1) < 0 && s->warn_unsupported)
                    goto unsupported_option;
                break;
            /* 29/07/2026 - TCC 0.9.23 */
            case TCC_OPTION_W:
                if (tcc_set_warning(s, optarg, 1) < 0 && s->warn_unsupported)
                    goto unsupported_option;
                break;
            /* 28/07/2026 - TCC 0.9.23 */
            case TCC_OPTION_w:
                s->warn_none = 1;
                break;
            /* 02/08/2026 */
            /* 01/08/2026 - TCC 0.9.24 Saf Preprocessor Modu */
            case TCC_OPTION_E:
                // multiple_files = 1;
                output_type = TCC_OUTPUT_PREPROCESS; 
                break;
            default:
                if (s->warn_unsupported) {
                unsupported_option:
                    warning("unsupported option '%s'", r);
                }
                break;
            }
        }
    }
    
    if (print_search_dirs) {
        printf("install: %s/\n", tcc_lib_path);
        return 0;
    }

    nb_objfiles = nb_files - nb_libraries;

    /* Verify -c argument constraints ensuring only isolated standalone objects are accepted */
    if (output_type == TCC_OUTPUT_OBJ && !reloc_output) {
        if (nb_objfiles != 1)
            error("cannot specify multiple files with -c");
        if (nb_libraries != 0)
            error("cannot specify libraries with -c");
    }

    /* 02/08/2026 - Google AI */
    /* =========================================================================
       TRDOS DİNAMİK OTOMATİK ADLANDIRMA KANCASI (BSS VE LINKER_END BAĞIMSIZ)
       ========================================================================= */
    /* FIX: Eğer -E modu aktifse, otomatik PRG adlandırma mekanizmasını tamamen bypass et! */

    // if (output_type == TCC_OUTPUT_PREPROCESS) {
       /* Preprocessor varsayılan olarak ekrana (NULL) basmalıdır,
          kullanıcı -o belirttiyse zaten parser tarafından doldurulmuştur. */
    // }
    // else if (!outfile && nb_files > 0) {
    /* 02/08/2026 */
    if (output_type != TCC_OUTPUT_PREPROCESS) {
       if (do_bench)
          start_time = getclock_us();

       if (!outfile && nb_files > 0) {
           char *ext;
           pstrcpy(objfilename, sizeof(objfilename) - 1, files[0]);
           ext = strrchr(objfilename, '.');

           if (ext) {
              /* Eğer sadece nesne dosyası isteniyorsa uzantıyı .o yap */
              if (output_type == TCC_OUTPUT_OBJ) {
                  strcpy(ext + 1, "o");
              } else {
                /* TRDOS 386 Flat Binary damgası için uzantıyı mutlak suretle PRG yapıyoruz */
                strcpy(ext + 1, "PRG");
              }
           } else {
              /* Eğer girdi dosyasının uzantısı yoksa sonuna doğrudan ekle */
              int len = strlen(objfilename);
              if (output_type == TCC_OUTPUT_OBJ) {
                 pstrcat(objfilename, sizeof(objfilename), ".o");
              } else {
                 pstrcat(objfilename, sizeof(objfilename), ".PRG");
              }
           }
           outfile = objfilename;
       }
    }

    // if (do_bench) {
    //    start_time = getclock_us();
    // }

    /* Configure compiler system state targets and load baseline symbol environments */
    tcc_set_output_type(s, output_type);

    /* Process, compile, and sequence every specified target input file or archive library */
    // for(i = 0; i < nb_files; i++) {
    for(i = 0; i < nb_files && ret == 0; i++) {
        const char *filename;
        filename = files[i];
        /* 02/08/2026 */
        /* 01/08/2026 - TCC 0.9.24 Saf Preprocessor Modu Yönlendirmesi */
        if (output_type == TCC_OUTPUT_PREPROCESS) {
           /* tcc_add_file yerine doğrudan zırhlı internal fonksiyonu çağırıyoruz */
           // if (tcc_add_file_internal(s, filename, 0) < 0) {
           //    ret = 1;
           //    goto the_end;
           // }
           if (tcc_add_file_internal(s, filename, AFF_PRINT_ERROR | AFF_PREPROCESS) < 0)
               ret = 1;
        } else if (filename[0] == '-') {
            if (tcc_add_library(s, filename + 2) < 0)
                error("cannot find %s", filename);
        } else {
            if (tcc_add_file(s, filename) < 0) {
                ret = 1;
                // goto the_end;
            }
        }
    }

    /* ELF nesne formatı için burası bir boş stub olarak çalışır, flat büyümede files güvenle korunur */
    tcc_free(files);

    /* 02/08/2026 */
    // if (ret)
    //    goto the_end;

    /* 01/08/2026 - Eğer -E modu çalıştıysa, binary linker ve sembol kontrol mekanizmalarını tamamen bypass et */
    // if (output_type == TCC_OUTPUT_PREPROCESS) {
    /* 02/08/2026 */
    if ((ret != 0) || (output_type == TCC_OUTPUT_PREPROCESS)) {
        goto the_end; /* Çıktı üretildi, derleyiciyi korumalı modda temizce sonlandır */
    }

    /* 19/07/2026 - Google AI */
    /* Resolve linear pointer references across newly initialized flat segments in RAM */
    /* LOKOMOTİF NEŞTERİ 1: -c modunda relocation kilitlenmesi atlanmalıdır! */
    if (output_type != TCC_OUTPUT_OBJ) {
        tcc_relocate(s);
        /* 29/07/2026 */
        check_undefined_symbols(s);
    }

    /* 20/07/2026 - Google AI */
    /* 0.9.18 uyumlu evrensel eksik fonksiyon avcısı devrede */
    // check_undefined_symbols(s);

    /* 19/07/2026 - Google AI - 22:16 - (0.9.18-0.9.27) */
    /* =========================================================================
       TRDOS 386 REFERANS TCC - OUTPUT WRITER PIPELINE (FIXED & SEALED)
       ========================================================================= */
    if (text_section && text_section->data_offset > 0) {
        unsigned char *text_ptr  = text_section->data;
        unsigned int   text_size = text_section->data_offset;
        int trdos_fd = -1;
        int c_fd = -1; /* Lseek.s (sub ebx,3) uyumluluğu için kilit değişken */

        /* 09/08/2026 */
        /* EXECUTE STEP A: Invoke TRDOS sys_create kernel vector interrupt (eax = 8) with dynamic outfile! */
        __asm__ __volatile__ (
            "pushl %%ebx\n\t"
            "movl %1, %%ebx\n\t"
            "movl $0, %%ecx\n\t"
            "movl $8, %%eax\n\t"
            "int $0x40\n\t"
            "jnc 1f\n\t"              /* Noktalı isim yerine ileriye doğru 1: etiketine atla (1 forward) */
            "movl $-1, %%eax\n"
        "1:\n\t"                      /* Noktasız saf sayısal yerel etiket */
            "popl %%ebx\n\t"
            "movl %%eax, %0"
            : "=r" (trdos_fd)
            : "g" (outfile)
            : "eax", "ecx"
        );

        if (trdos_fd >= 0) {
            /* 128-Byte / FD Çelişkisini Çözen Muazzam Klonlama */
            c_fd = trdos_fd + 3; 

            /* 20/07/2026 - Google AI - 00:28 */
            if (output_type == TCC_OUTPUT_OBJ) {
                /* =========================================================================
                   TRDOS 386 REFERANS TCC - 0.9.27 COMPLIANT ELF32 WRITER (596 BYTE FIX)
                   ========================================================================= */
                Elf32_Ehdr ehdr;
                Elf32_Shdr master_shdr;
                unsigned char shstrtab_payload[56]; // GCC UYUMU: Tam 56 Byte Genişliğinde Dizi

                unsigned int text_len = text_section->data_offset;
                unsigned int data_len = data_section ? data_section->data_offset : 0;
                unsigned int current_offset = 52;
                int out_fd = trdos_fd;

                /* TCC 0.9.18/0.9.27 dahili relocation verilerini doğrudan .text yatağından çekiyoruz */
                Section *actual_reloc_sec = text_section->reloc;
                unsigned int reloc_data_size = actual_reloc_sec ? actual_reloc_sec->data_offset : 0;

                memset(shstrtab_payload, 0, sizeof(shstrtab_payload));
                memset(&master_shdr, 0, sizeof(Elf32_Shdr));

                /* 1. LOKOMOTİF TAMİRİ: Orijinal TCC 0.9.27 İsim Havuzunun Harfi Harfine Enjeksiyonu */
                // Dizilim: "\0.text\0.data\0.bss\0.symtab\0.strtab\0.rel.text\0.shstrtab\0"
                memcpy(shstrtab_payload + 0,  "\0", 1);
                memcpy(shstrtab_payload + 1,  ".text\0", 6);
                memcpy(shstrtab_payload + 7,  ".data\0", 6);
                memcpy(shstrtab_payload + 13, ".bss\0", 5);
                memcpy(shstrtab_payload + 18, ".symtab\0", 8);
                memcpy(shstrtab_payload + 26, ".strtab\0", 8);
                memcpy(shstrtab_payload + 34, ".rel.text\0", 10); // .rel.text yerini buldu!
                memcpy(shstrtab_payload + 44, ".shstrtab\0", 10); // .shstrtab tablonun kendisi eklendi!
                unsigned int shstrtab_bytes = 54;

                /* 2. Kesin Ofset Koordinat Hesaplamaları */
                unsigned int text_off = current_offset;     current_offset += text_len;
                unsigned int data_off = current_offset;     current_offset += data_len;
                unsigned int symtab_off = current_offset;   current_offset += (symtab_section ? symtab_section->data_offset : 0);
                unsigned int strtab_off = current_offset;   current_offset += (strtab_section ? strtab_section->data_offset : 0);
                unsigned int rel_off = current_offset;      current_offset += reloc_data_size;
                unsigned int shstrtab_off = current_offset; current_offset += shstrtab_bytes;
                unsigned int shdr_table_off = current_offset;

                /* 3. Ana ELF Başlığını 8 Bölümlü Standarda Göre Düzenle */
                memset(&ehdr, 0, sizeof(Elf32_Ehdr));
                memcpy(ehdr.e_ident, "\x7f\x45\x4c\x46\x01\x01\x01\x00", 8);
                *(unsigned short *)(ehdr.e_ident + 16) = 1;  // ET_REL
                *(unsigned short *)(ehdr.e_ident + 18) = 3;  // EM_386
                *(unsigned int   *)(ehdr.e_ident + 20) = 1;  
                *(unsigned int   *)(ehdr.e_ident + 32) = shdr_table_off; // Tablo başlangıcı
                *(unsigned short *)(ehdr.e_ident + 40) = 52; 
                *(unsigned short *)(ehdr.e_ident + 46) = 40; 
                *(unsigned short *)(ehdr.e_ident + 48) = 8;  // 0.9.27 Standardı: Tam 8 Bölüm Var!
                *(unsigned short *)(ehdr.e_ident + 50) = 7;  // Bölüm isimleri Index 7'de! (.shstrtab)

                /* 09/08/2026 */ 
                /* 4. DISKE BLOK HALİNDE YAZMA AKIŞI */
                __asm__ __volatile__ (
                   "movl $4, %%eax\n\t"
                   "int $0x40\n\t"
                   :
                   : "b"(out_fd), "c"(&ehdr), "d"(52)
                   : "eax"
                );
                __asm__ __volatile__ (
                   "movl $4, %%eax\n\t"
                   "int $0x40\n\t"
                   :
                   : "b"(out_fd), "c"(text_section->data), "d"(text_len)
                   : "eax"
                );
                if (data_len > 0) 
                    __asm__ __volatile__ (
                       "movl $4, %%eax\n\t"
                       "int $0x40\n\t"
                       :
                       : "b"(out_fd), "c"(data_section->data), "d"(data_len)
                       : "eax"
                    );
                
                lseek(c_fd, symtab_off, SEEK_SET); 
                
                if (symtab_section) 
                    __asm__ __volatile__ (
                       "movl $4, %%eax\n\t"
                       "int $0x40\n\t"
                       :
                       : "b"(out_fd), "c"(symtab_section->data), "d"(symtab_section->data_offset)
                       : "eax"
                    );
                if (strtab_section)
                    __asm__ __volatile__ (
                       "movl $4, %%eax\n\t"
                       "int $0x40\n\t"
                       :
                       : "b"(out_fd), "c"(strtab_section->data), "d"(strtab_section->data_offset)
                       : "eax"
                    );
                if (actual_reloc_sec && reloc_data_size > 0) {
                    __asm__ __volatile__ (
                       "movl $4, %%eax\n\t"
                       "int $0x40\n\t"
                       :
                       : "b"(out_fd), "c"(actual_reloc_sec->data), "d"(reloc_data_size)
                       : "eax"
                    );
                }

                lseek(c_fd, shstrtab_off, SEEK_SET);

                __asm__ __volatile__ (
                   "movl $4, %%eax\n\t"
                   "int $0x40\n\t"
                   :
                   : "b"(out_fd), "c"(shstrtab_payload), "d"(shstrtab_bytes)
                   : "eax"
                );

                /* =========================================================================
                   5. GÜVENLİ 0.9.27 SECTION HEADER ENJEKSİYONU (8 KARTLI TAM ŞEMA)
                   ========================================================================= */
                lseek(c_fd, shdr_table_off, SEEK_SET);

                // KART 0: SHT_NULL
                memset(&master_shdr, 0, sizeof(Elf32_Shdr));
                __asm__ __volatile__ (
                   "movl $4, %%eax\n\t"
                   "int $0x40\n\t"
                   :
                   : "b"(out_fd), "c"(&master_shdr), "d"(40)
                   : "eax"
                );

                // KART 1: .text
                memset(&master_shdr, 0, sizeof(Elf32_Shdr));
                master_shdr.sh_name = 1;  master_shdr.sh_type = 1; master_shdr.sh_flags = 6;
                master_shdr.sh_addr = 0;  master_shdr.sh_offset = text_off; master_shdr.sh_size = text_len; master_shdr.sh_addralign = 4;
                __asm__ __volatile__ (
                   "movl $4, %%eax\n\t"
                   "int $0x40\n\t"
                   :
                   : "b"(out_fd), "c"(&master_shdr), "d"(40)
                   : "eax"
                );

                // KART 2: .data
                memset(&master_shdr, 0, sizeof(Elf32_Shdr));
                master_shdr.sh_name = 7;  master_shdr.sh_type = 1; master_shdr.sh_flags = 3;
                master_shdr.sh_addr = 0;  master_shdr.sh_offset = data_off; master_shdr.sh_size = data_len; master_shdr.sh_addralign = 4;
                __asm__ __volatile__ (
                   "movl $4, %%eax\n\t"
                   "int $0x40\n\t"
                   :
                   : "b"(out_fd), "c"(&master_shdr), "d"(40)
                   : "eax"
                );

                // KART 3: .bss
                memset(&master_shdr, 0, sizeof(Elf32_Shdr));
                master_shdr.sh_name = 13; master_shdr.sh_type = 8; master_shdr.sh_flags = 3;
                master_shdr.sh_addr = 0;  master_shdr.sh_offset = symtab_off; master_shdr.sh_size = bss_section ? bss_section->data_offset : 0; master_shdr.sh_addralign = 4;
                __asm__ __volatile__ (
                   "movl $4, %%eax\n\t"
                   "int $0x40\n\t"
                   :
                   : "b"(out_fd), "c"(&master_shdr), "d"(40)
                   : "eax"
                );

                // KART 4: .symtab
                memset(&master_shdr, 0, sizeof(Elf32_Shdr));
                master_shdr.sh_name = 18; master_shdr.sh_type = 2;
                master_shdr.sh_addr = 0;  master_shdr.sh_offset = symtab_off; master_shdr.sh_size = symtab_section ? symtab_section->data_offset : 0;
                master_shdr.sh_link = 5;  master_shdr.sh_info = 3; master_shdr.sh_entsize = sizeof(Elf32_Sym); master_shdr.sh_addralign = 4;
                __asm__ __volatile__ (
                   "movl $4, %%eax\n\t"
                   "int $0x40\n\t"
                   :
                   : "b"(out_fd), "c"(&master_shdr), "d"(40)
                   : "eax"
                );

                // KART 5: .strtab
                memset(&master_shdr, 0, sizeof(Elf32_Shdr));
                master_shdr.sh_name = 26; master_shdr.sh_type = 3;
                master_shdr.sh_addr = 0;  master_shdr.sh_offset = strtab_off; master_shdr.sh_size = strtab_section ? strtab_section->data_offset : 0; master_shdr.sh_addralign = 1;
                __asm__ __volatile__ (
                   "movl $4, %%eax\n\t"
                   "int $0x40\n\t"
                   :
                   : "b"(out_fd), "c"(&master_shdr), "d"(40)
                   : "eax"
                );

                // KART 6: .rel.text (Yer Değiştirme Başlık Kartı)
                memset(&master_shdr, 0, sizeof(Elf32_Shdr));
                master_shdr.sh_name = 34; master_shdr.sh_type = 9; // SHT_REL
                master_shdr.sh_addr = 0;  master_shdr.sh_offset = rel_off; master_shdr.sh_size = reloc_data_size;
                master_shdr.sh_link = 4;  master_shdr.sh_info = 1; master_shdr.sh_entsize = 8; master_shdr.sh_addralign = 4;
                __asm__ __volatile__ (
                   "movl $4, %%eax\n\t"
                   "int $0x40\n\t"
                   :
                   : "b"(out_fd), "c"(&master_shdr), "d"(40)
                   : "eax"
                );

                // KART 7: .shstrtab (Bölüm İsim Havuzu Kartı - İndeks 7!)
                memset(&master_shdr, 0, sizeof(Elf32_Shdr));
                master_shdr.sh_name = 44; master_shdr.sh_type = 3; // SHT_STRTAB
                master_shdr.sh_addr = 0;  master_shdr.sh_offset = shstrtab_off; master_shdr.sh_size = shstrtab_bytes; master_shdr.sh_addralign = 1;
                __asm__ __volatile__ (
                   "movl $4, %%eax\n\t"
                   "int $0x40\n\t"
                   :
                   : "b"(out_fd), "c"(&master_shdr), "d"(40)
                   : "eax"
                );
            }
            else {
                /* =========================================================================
                   ORİJİNAL TRDOS FLAT BINARY (.PRG) MOTORUNUZ (SAAT 21.18 REFERANSI)
                   ========================================================================= */
                /* 09/08/2026 */
                __asm__ __volatile__ (
                   "movl $4, %%eax\n\t"
                   "int $0x40\n\t"
                   :
                   : "b" (trdos_fd), "c" (text_ptr), "d" (text_size)
                   : "eax"
                );

                if (data_section && data_section->data_offset > 0) {
                    unsigned char *data_ptr = data_section->data;
                    unsigned int data_size = data_section->data_offset;

                    __asm__ __volatile__ (
                       "movl $4, %%eax\n\t"
                       "int $0x40\n\t"
                       :
                       : "b" (trdos_fd), "c" (data_ptr), "d" (data_size)
                       : "eax"
                    );
                } 
            }

	   /* 23/07/2026 */
	   if (do_bench)
              total_bytes = lseek(c_fd, 0, 1); // get file size

            /* EXECUTE STEP D: Safely finalize file transaction closing target handle (sys_close = 6) */
            /* 09/08/2026 */
            __asm__ __volatile__ (
               "mov $6, %%eax\n\t"
               "int $0x40"
               :
               : "b" (trdos_fd)
               : "eax"
            );

            /* 23/07/2026 */
   	    if (do_bench) {
               unsigned long total_time = (getclock_us() - start_time);
               // if (total_time < 1)
               //   total_time = 1;
               // if (total_bytes < 1)
               //    total_bytes = 1;
               printf("%d idents, %d lines, %d bytes in %d timer ticks (18.2 Hz)\n",
                      tok_ident - TOK_IDENT, total_lines, total_bytes, total_time);
            }

            /* EXECUTE STEP E: Force absolute process escape returning directly to the shell prompt (sys_exit = 1) */
            // __asm__ __volatile__ (
            //    "movl $0, %%ebx\n\t"
            //    "movl $1, %%eax\n\t"
            //    "int 0x40"
            // );

            /* 31/07/2026 */
            exit(0);	/* trdos_sys_exit(int exit_code) */
        }
    }

the_end:
    tcc_delete(s);
    return ret;
}
