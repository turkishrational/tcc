@echo off
setlocal enabledelayedexpansion

echo ====================================================
echo   TRDOS 386 - NATIVE NASM LIBC DERLEYICI
echo ====================================================

set BASE_DIR=C:\TDM-GCC-32\tinycc
set LIBC_SRC=%BASE_DIR%\libc
set LIBC_ASM=%BASE_DIR%\source
set OUT_DIR=%BASE_DIR%\tcclibc
set TCC_EXE=%BASE_DIR%\tcc.exe
set CUSTOM_AR=%BASE_DIR%\ar.exe
set NASM_EXE=C:\nasm\nasm.exe

if exist "%OUT_DIR%" rmdir /s /q "%OUT_DIR%"
mkdir "%OUT_DIR%"

if not exist "%NASM_EXE%" (
    echo [HATA] nasm.exe bulunamadi! C:\nasm klasorunu kontrol edin.
    pause
    exit /b 1
)

echo.
echo [1/2] C ve NASM Kodlari Saf ELF32 Object Formatinda Derleniyor...

rem --- C DOSYALARI (TCC Yerel Derleme) ---
for %%c in (libc_core libc_support) do (
    if exist "%LIBC_SRC%\%%c.c" (
        echo   [C] -^> %%c.c
        "%TCC_EXE%" -c "%LIBC_SRC%\%%c.c" -o "%OUT_DIR%\%%c.o"
    )
)

rem --- NASM ASSEMBLY DOSYALARI (.s) ---
for %%f in (memset memcpy strlen strcmp strcpy memcmp strchr strrchr memmove strncmp chkstk gcc_stubs strcat atoi strpbrk lseek tell open close read write math64 mingw_hack libc_printf libc_itoa malloc fstat strstr win32_stubs freeopen ldexp) do (
    if exist "%LIBC_ASM%\%%f.s" (
        echo   [NASM] -^> %%f.s
        "%NASM_EXE%" -f elf32 "%LIBC_ASM%\%%f.s" -o "%OUT_DIR%\%%f.o"
    )
)

echo.
echo [2/2] Saf nesne dosyalari Yerel C AR.EXE ile paketleniyor (libc.a)...
cd /d "%OUT_DIR%"
"%CUSTOM_AR%" libc.a *.o

echo ====================================================
echo   TAMAMLANDI: Saf NASM ve TCC uyumlu libc.a hazir!
echo ====================================================
pause
