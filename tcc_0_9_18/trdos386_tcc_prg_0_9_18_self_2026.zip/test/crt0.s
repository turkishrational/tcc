.intel_syntax noprefix
.global _start
.extern main

.text
.align 4                          /* FIX: Kod s�n�r�n� keskin 4-byte hizas�na zorluyoruz */

_start:
    jmp .L_START

    .ascii "CRT0"

.align 4                          /* FIX: At�� noktas�n� p�r�zs�zle�tiriyoruz */
.L_START:
    pop eax                         /* eax = argc */
    mov ebx, esp                    /* ebx = argv pointer */
    push ebx
    push eax
    call main                       /* TCC'nin urettigi saf mutlak 'main' sembolu */
    
    add esp, 8
    mov ebx, eax
    mov eax, 1                      /* sys_exit */
    int 0x40

    .byte 0
    .ascii "C Compiler v1.0 for TRDOS 386"
    .byte 0
    .ascii "Erdogan Tan - 2026"
    .byte 0
