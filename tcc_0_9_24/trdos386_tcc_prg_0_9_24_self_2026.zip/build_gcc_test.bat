@echo off
cls
echo ====================================================
echo   TRDOS 386 - MINI COMPILER LINKER TESTBENCH (FINAL)
echo ====================================================

set BASE_DIR=C:\TDM-GCC-32\tinycc
set OUT_DIR=%BASE_DIR%\tcclibc
set GCC_BIN=C:\TDM-GCC-32\bin

echo [1/3] GCC ile mini_compiler.c nesneye cevriliyor...
"%GCC_BIN%\gcc.exe" -m32 -c -nostdlib -fno-builtin -fno-stack-protector mini_compiler.c -o "%OUT_DIR%\mini_comp_gcc.o"
if errorlevel 1 ( echo [HATA] GCC Derlemesi Basarisiz! & pause & exit /b 1 )

echo [2/3] ld.exe ile tum nesneler ham PE arasina baglaniyor...
rem ld.exe artik _main sembolu uzerinden crt0.o ile kayipsiz birlesecek
"%GCC_BIN%\ld.exe" -m i386pe -Ttext 0x0 -s -o "%OUT_DIR%\mini_pe_tmp.exe" "%OUT_DIR%\crt0.o" "%OUT_DIR%\mini_comp_gcc.o" "%OUT_DIR%\write.o" "%OUT_DIR%\malloc.o" "%OUT_DIR%\memset.o" "%OUT_DIR%\strlen.o" "%OUT_DIR%\atoi.o"

if errorlevel 1 ( echo [HATA] Link Asamasi Basarisiz! & pause & exit /b 1 )

echo [3/3] objcopy ile saf TRDOS Flat Binary kirpiliyor...
"%GCC_BIN%\objcopy.exe" -O binary -S "%OUT_DIR%\mini_pe_tmp.exe" "%OUT_DIR%\MC_GCC.PRG"

if exist "%OUT_DIR%\mini_pe_tmp.exe" del "%OUT_DIR%\mini_pe_tmp.exe"

echo ====================================================
echo   TAMAMLANDI: Saf Flat Binary - %OUT_DIR%\MC_GCC.PRG
echo ====================================================
pause
