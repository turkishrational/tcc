/* =======================================================================
   TRDOS 386 - NATIVE RELOCATION LINKER TEST BENCH (COMPACT VERSION)
   Date: 12/08/2026 - Developer: Erdogan Tan & Google AI
   Standard: Pure C, No Header Includes, Nostdlib Armored
   ======================================================================= */

/* --- LIBC EXTERNAL FUNCTION DECLARATIONS (Your Custom Libc.a Map) --- */
extern int write(int fd, const void *buf, unsigned int count);
extern void *malloc(unsigned int size);
extern void *memset(void *s, int c, unsigned int n);
extern unsigned int strlen(const char *s);
extern int atoi(const char *nptr);

/* GCC'nin main() basinda aradigi sahte baslatma hucresi */
void __main(void) {
    return;
}

/* --- PREPROCESSOR EMULATION & CORE STRUCTURES --- */
#define TOK_IDENT   256
#define TOK_PRINT   257
#define TOK_ASSIGN  258
#define TOK_INT     259

typedef struct TokenNode {
    int type;
    int value;
    char name[16];      /* FIX: Karakter dizisi boyutu sabitlendi */
    struct TokenNode *next;
} TokenNode;

typedef struct CompilerState {
    TokenNode *token_list;
    unsigned int total_tokens;
    unsigned int memory_footprint;
    char current_lex[32]; /* FIX: Karakter dizisi boyutu sabitlendi */
} CompilerState;

/* --- GLOBAL VARIANCE VARIABLES (To Trigger Relocation Sections) --- */
CompilerState *global_state = 0;
unsigned char custom_id_table[256]; /* FIX: Dizi boyutu tam 256 byte yapildi */

/* =========================================================================
   1. CORE REGISTRY CONTEXT BLOCK INSTANTIATION (Simulating tcc_new)
   ========================================================================= */
CompilerState *compiler_state_new(void) {
    CompilerState *s;
    int i;

    write(1, "STUB: compiler_state_new entry\n", 31);

    /* Allocate continuous segment memory block tracking (malloc test) */
    s = (CompilerState *)malloc(sizeof(CompilerState));
    if (!s) return 0;

    global_state = s;
    s->total_tokens = 0;
    s->token_list = 0;

    write(1, "STUB: state allocated, initializing tables\n", 43);

    /* Fill global variable array context (Triggers global relocation mapping) */
    for (i = 0; i < 256; i++) {
        custom_id_table[i] = (i >= 'a' && i <= 'z') || (i >= '0' && i <= '9');
    }

    write(1, "STUB: table populated, calling memset\n", 38);

    /* Core string structure cleanup boundary constraint (memset test) */
    memset(s->current_lex, 0, 32);

    write(1, "STUB: compiler_state_new ok!\n", 29);
    return s;
}

/* =========================================================================
   2. TOKEN ENQUEUE REGISTRY ANCHOR (Simulating define_push)
   ========================================================================= */
void compiler_push_token(int type, const char *name, int val) {
    TokenNode *node;
    unsigned int name_len;
    unsigned int i;

    write(1, "STUB: push_token entering\n", 26);

    node = (TokenNode *)malloc(sizeof(TokenNode));
    if (!node) {
        write(1, "STUB: push_token allocation failed!\n", 36);
        /* Saf TRDOS sys_exit kesmesi (int 0x40, eax=1, ebx=1) */
        __asm__ __volatile__("movl $1, %%ebx\n\t"
                             "movl $1, %%eax\n\t"
                             "int $0x40" : : : "eax", "ebx");
    }

    node->type = type;
    node->value = val;
    node->next = 0;

    if (name) {
        name_len = strlen(name);
        if (name_len > 15) name_len = 15;
        memset(node->name, 0, 16);
        /* Pure char copy loops to mimic custom parsing without strcpy */
        for (i = 0; i < name_len; i++) {
            node->name[i] = name[i];
        }
    }

    /* Chain links upstream into global state tracker */
    if (global_state) {
        node->next = global_state->token_list;
        global_state->token_list = node;
        global_state->total_tokens++;
    }

    write(1, "STUB: push_token complete\n", 26);
}

/* =========================================================================
   3. STRUCTURAL PRECOMPILER INTERPRETER CYCLE (Simulating parsing)
   ========================================================================= */
void execute_mock_parser(void) {
    write(1, "STUB: executing mock parsing streams\n", 37);

    /* Enqueue structural anchor symbols to evaluate relational linking */
    compiler_push_token(TOK_IDENT, "variable_a", 0);
    compiler_push_token(TOK_ASSIGN, "=", 0);
    compiler_push_token(TOK_INT, "42", 42);
    compiler_push_token(TOK_PRINT, "print", 0);

    write(1, "STUB: parsing stage pipeline complete\n", 38);
}

/* =========================================================================
   4. MAIN CONTEXT MOTOR ENTRY POINT
   ========================================================================= */
int main(int argc, char **argv) {
    CompilerState *ctx;

    write(1, "========================================\n", 41);
    write(1, " TRDOS 386 MINI-COMPILER LINKER TESTER  \n", 41);
    write(1, "========================================\n", 41);

    /* Step A: Initialize State Context */
    ctx = compiler_state_new();
    if (!ctx) {
        write(1, "FATAL: Main context allocation abort!\n", 38);
        return 1;
    }

    /* Step B: Run Engine Parser */
    execute_mock_parser();

    /* Step C: Display Global Registry Summary Metrics */
    write(1, "SUCCESS: Executed instructions completely.\n", 43);
    return 0;
}
