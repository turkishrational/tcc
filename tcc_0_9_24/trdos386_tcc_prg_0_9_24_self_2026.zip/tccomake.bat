c:\tdm-gcc-32\bin\objcopy.exe -O elf32-i386 tcc.o tcc2.o
