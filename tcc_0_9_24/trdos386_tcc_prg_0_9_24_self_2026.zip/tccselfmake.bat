@echo off
cls
echo ====================================================
echo   TRDOS 386 - PE TO FLAT BINARY GENERATOR (FIXED)
echo ====================================================

rem Klasör Yolları Sabit Tanımlamaları
set BASE_DIR=C:\TDM-GCC-32\tinycc
set OUT_DIR=%BASE_DIR%\tcclibc
set TCC_EXE=%BASE_DIR%\tcc.exe
set OBJCOPY_EXE=C:\TDM-GCC-32\bin\objcopy.exe

rem Gerekli dosyaların varlığını kontrol et
if not exist "%OUT_DIR%\crt0.o" ( echo [HATA] crt0.o bulunamadi! & pause & exit /b 1 )
if not exist "%OUT_DIR%\tccself.o" ( echo [HATA] tccself.o bulunamadi! & pause & exit /b 1 )
if not exist "%OUT_DIR%\libc.a" ( echo [HATA] libc.a bulunamadi! & pause & exit /b 1 )

echo.
echo [1/2] Nesne dosyalari TCC ile PE Arasina Baglaniyor...
rem TCC'ye nesnelerin yerini acikca gosteriyoruz
"%TCC_EXE%" -nostdlib -static -Wl,-Ttext=0x0 -o "%OUT_DIR%\tcc_pe_tmp.exe" "%OUT_DIR%\crt0.o" "%OUT_DIR%\tccself.o" "%OUT_DIR%\libc.a"

echo.
echo [2/2] OBJCOPY ile PE basligi sokuluyor (Saf Flat Binary Yapiliyor)...
rem Orijinal binary ciktisini dogrudan Flat yapida diske basiyoruz
"%OBJCOPY_EXE%" -O binary -S "%OUT_DIR%\tcc_pe_tmp.exe" "%OUT_DIR%\TCCSELF.PRG"

rem Gecici PE dosyasini temizle
if exist "%OUT_DIR%\tcc_pe_tmp.exe" del "%OUT_DIR%\tcc_pe_tmp.exe"

echo ====================================================
echo   TAMAMLANDI: Saf Flat Binary %OUT_DIR%\TCCSELF.PRG
echo ====================================================
pause
